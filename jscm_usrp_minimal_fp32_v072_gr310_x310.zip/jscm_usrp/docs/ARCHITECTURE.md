# System Architecture

```text
Training/simulation:
Speech → FreqCodec-style Encoder → Continuous JSCM symbols
→ differentiable FM/AWGN → Decoder → Reconstructed speech

OTA prototype:
Speech → PyTorch Encoder → ZeroMQ → GNU Radio FM/GFSK
→ USRP TX → RF channel → USRP RX → GNU Radio demod/deframe
→ ZeroMQ → PyTorch Decoder → Speech
```

JSCM payload is continuous float32. SSCC and Opus payloads are binary/byte streams.
All training and profiling calculations use FP32.
