# v0.7.2 GNU Radio/X310 integration report

## Target environment

- Python 3.9
- GNU Radio 3.10.12.0
- USRP X310, UHD type `x300`
- FPGA image `HG`
- TX address `192.168.10.1`
- RX address `192.168.10.2`

## Added flowgraphs

- `gnuradio/grc/jscm_tx.grc`
- `gnuradio/grc/jscm_rx.grc`
- `gnuradio/grc/sscc_tx.grc`
- `gnuradio/grc/sscc_rx.grc`

## Added executable Python flowgraphs

- `gnuradio/python/common_fm_flowgraph.py`
- `gnuradio/python/jscm_tx_flowgraph.py`
- `gnuradio/python/jscm_rx_flowgraph.py`
- `gnuradio/python/sscc_tx_flowgraph.py`
- `gnuradio/python/sscc_rx_flowgraph.py`
- `gnuradio/python/opus_tx_flowgraph.py`
- `gnuradio/python/opus_rx_flowgraph.py`

## Added GNU Radio blocks

- `PacketFloatSource`: RadioPacket ZeroMQ to framed symbol stream.
- `PacketFloatSink`: symbol stream to RadioPacket ZeroMQ with synchronization, Header parsing, affine CFO-bias/amplitude correction, and continuous/digital payload handling.

## Validation in this environment

- Updated Python files compile successfully.
- All `.grc` and custom `.block.yml` files parse as valid YAML and contain GNU Radio file format version 1.
- ZeroMQ direction was checked:
  - TX GNU Radio binds port 5555; neural TX connects.
  - Neural RX binds port 5556; GNU Radio RX connects.
- Existing full model tests were not rerun to completion in this container because the suite exceeded the execution window.
- GNU Radio/UHD runtime compilation and X310 RF execution could not be performed because GNU Radio, UHD, and the two devices are not available in this environment.

## Required first hardware check

Run:

```bash
source gnuradio/scripts/setup_env.sh
python gnuradio/scripts/verify_x310.py
```

Then confirm daughterboard/subdevice and antenna names before RF transmission.
