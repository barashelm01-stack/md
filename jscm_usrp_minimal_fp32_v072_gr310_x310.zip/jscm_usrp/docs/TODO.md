# Remaining Work

1. Generate and verify GNU Radio flowgraphs on the actual GNU Radio/UHD host.
2. Fill in the two USRP serial numbers and RF settings.
3. Complete software loopback, cable loopback, then OTA tests.
4. Verify CFO correction, sample timing and long-duration stream stability.
5. Run real LibriSpeech training for JSCM and SSCC.
6. Perform repeated TX-gain sweeps and report measured Es/N0.
7. Produce final KPI, bandwidth, packet-success and latency results.
