# GNU Radio 3.10.12.0 + dual X310 implementation

## Files

- `gnuradio/grc/jscm_tx.grc`
- `gnuradio/grc/jscm_rx.grc`
- `gnuradio/grc/sscc_tx.grc`
- `gnuradio/grc/sscc_rx.grc`
- `gnuradio/python/common_fm_flowgraph.py`
- `gnuradio/python/*_flowgraph.py`
- `gnuradio/blocks/packet_blocks.py`

## TX chain

```text
RadioPacket ZeroMQ
→ BLE-like framing at symbol rate
→ Gaussian interpolation (SPS=4, BT=0.5)
→ frequency modulator (sensitivity=πh/SPS)
→ complex amplitude control
→ UHD USRP Sink
```

## RX chain

```text
UHD USRP Source
→ quadrature demodulator (gain=SPS/(πh))
→ timing phase skip
→ Gaussian matched filter and decimation
→ affine sync normalization
→ Header parse and payload extraction
→ RadioPacket ZeroMQ
```

The affine normalization estimates scale and DC bias from the 40 known preamble/access-address symbols. This compensates the principal discriminator bias caused by carrier-frequency offset. It is sufficient for the current JSCM prototype but is not a full carrier/timing recovery loop.

## Hardware defaults

```text
TX address       192.168.10.1
RX address       192.168.10.2
master clock     200 MHz
center frequency 2.45 GHz
sample rate      4 MHz
symbol rate      1 MHz
TX antenna       TX/RX
RX antenna       RX2
subdevice        A:0
```

The daughterboard mapping may differ on the actual units. Confirm `A:0`, `TX/RX`, and `RX2` using `uhd_usrp_probe` before transmitting.
