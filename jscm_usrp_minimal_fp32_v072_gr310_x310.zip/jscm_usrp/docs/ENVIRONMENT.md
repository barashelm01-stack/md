# Environment

The project is configured for:

- Python 3.9.x
- PyTorch 2.5.1
- NVIDIA driver / locally installed CUDA toolkit 13.0
- LibriSpeech root `/home/data`
- FP32 execution

PyTorch 2.5.1 official binaries were published for CUDA 11.8, 12.1, and 12.4, not CUDA 13.0. Use the existing working PyTorch installation or the official CUDA 12.4 wheel. A CUDA 13.0-capable NVIDIA driver can run the CUDA 12.4 PyTorch binary. The value printed by `torch.version.cuda` therefore normally reports the runtime used to build PyTorch rather than the locally installed toolkit.

Run:

```bash
python -m apps.check_environment
```

The data loader accepts either:

```text
/home/data/LibriSpeech/<subset>
```

or:

```text
/home/data/<subset>
```
