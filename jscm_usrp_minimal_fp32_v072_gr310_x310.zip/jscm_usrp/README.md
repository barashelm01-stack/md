# JSCM-USRP Minimal v0.7.1

面向两台USRP的JSCM语音通信原型。工程只保留五条主链路：

1. JSCM训练与仿真；
2. SSCC训练与仿真；
3. Opus-GFSK对比测试；
4. GNU Radio/ZeroMQ空口接口；
5. TX Gain控制下的SNR标定与KPI绘图。

本版统一使用 **FP32**，已移除AMP、autocast和GradScaler。

## 极简文件树

```text
jscm_usrp/
├── README.md
├── pyproject.toml
├── requirements.txt
├── requirements-radio.txt
├── requirements-opus.txt
├── configs/
│   ├── model/
│   ├── radio/
│   ├── ota/
│   └── evaluation/
├── src/jscm/                 # 模型、信道、指标、SNR与无线协议
├── apps/
│   ├── train/                # JSCM、SSCC训练
│   ├── evaluation/           # benchmark、绘图、profiling
│   ├── calibration/          # SNR、Gain扫点、带宽校准
│   ├── ota/                  # JSCM空口TX/RX
│   └── streaming/            # 20 ms流式推理
├── gnuradio/                 # GNU Radio块和流图Python骨架
├── tests/                    # 核心回归测试
└── docs/
    ├── ARCHITECTURE.md
    └── TODO.md
```

## 1. 固定环境与数据路径

本工程已按以下环境调整：

```text
Python       3.9.x
PyTorch      2.5.1
CUDA Driver/Toolkit 13.0
LibriSpeech  /home/data
训练精度     FP32
```

LibriSpeech目录可采用任一形式：

```text
/home/data/LibriSpeech/train-clean-100
/home/data/LibriSpeech/dev-clean
/home/data/LibriSpeech/test-clean
```

或：

```text
/home/data/train-clean-100
/home/data/dev-clean
/home/data/test-clean
```

创建环境：

```bash
cd jscm_usrp
python3.9 -m venv .venv
source .venv/bin/activate
pip install -U pip setuptools wheel
```

若系统中已经正确安装 `torch==2.5.1`，建议保留现有PyTorch，仅安装本工程及其他依赖：

```bash
pip install -r requirements.txt --no-deps
pip install numpy scipy soundfile pystoi matplotlib
pip install -e . --no-deps
```

也可以使用PyTorch官方2.5.1 CUDA 12.4二进制包。CUDA 13.0驱动可运行较旧CUDA运行时构建；`torch.version.cuda`通常会显示12.4而不是13.0，这是正常的。不要为torch 2.5.1寻找不存在的cu130官方wheel。

```bash
pip install torch==2.5.1 --index-url https://download.pytorch.org/whl/cu124
pip install -e .
```

检查环境和数据路径：

```bash
python -m apps.check_environment
```

附加依赖：

```bash
pip install -r requirements-radio.txt
pip install -r requirements-opus.txt
pip install pesq
```

GNU Radio、UHD需在连接USRP的主机上单独安装。

## 2. JSCM训练（FP32）

```bash
python -m apps.train.train_jscm \
  --data-root /home/data \
  --output-dir runs/jscm_6k \
  --epochs 100 \
  --batch-size 50 \
  --gradient-accumulation-steps 2 \
  --reference-bitrate 6000
```

说明：

- `batch-size`是物理batch；
- 梯度累积仅用于等效batch，不涉及混合精度；
- 全部模型、信道和损失计算均为FP32。

## 3. SSCC训练（FP32）

```bash
python -m apps.train.train_sscc \
  --data-root /home/data \
  --output-dir runs/sscc_6k \
  --epochs 100 \
  --batch-size 50 \
  --gradient-accumulation-steps 2 \
  --reference-bitrate 6000 \
  --quantizer-bits 6
```

## 4. 仿真Benchmark与绘图

```bash
python -m apps.evaluation.benchmark \
  --checkpoint runs/jscm_6k/best_fm.pt \
  --sscc-checkpoint runs/sscc_6k/best.pt \
  --data-root /home/data \
  --esn0-list 0 5 10 15 20 \
  --output-dir runs/benchmark
```

输出包括六项KPI：

- waveform distance；
- SegSNR；
- PESQ；
- SI-SDR；
- STFT distance；
- STOI。

并生成：

```text
runs/benchmark/figures/kpi_vs_snr_dashboard.png
```

总览图左侧为六个KPI vs SNR，右侧两行分别为：

- TX Gain vs sample-domain SNR；
- TX Gain vs symbol-domain Es/N0。

## 5. 运行时间Profiling（FP32）

```bash
python -m apps.evaluation.profile_runtime \
  --checkpoint runs/jscm_6k/best_fm.pt \
  --batch-size 50 \
  --iterations 100 \
  --output runs/profile.json
```

## 6. 20 ms流式推理

```bash
python -m apps.streaming.stream_infer \
  --checkpoint runs/jscm_6k/best_fm.pt \
  --input input.wav \
  --output recovered.wav \
  --esn0-db 10
```

## 7. GNU Radio / 两台USRP连接

发送端：

```text
音频 → JSCM Encoder → float32连续符号 → ZeroMQ
→ GNU Radio组帧/FM → UHD Sink → USRP TX
```

接收端：

```text
USRP RX → UHD Source → GNU Radio FM解调/解帧
→ ZeroMQ连续符号 → JSCM Decoder → 音频
```

JSCM发送程序：

```bash
python -m apps.ota.ota_jscm_tx \
  --checkpoint runs/jscm_6k/best_fm.pt \
  --input input.wav \
  --endpoint tcp://127.0.0.1:5555
```

JSCM接收程序：

```bash
python -m apps.ota.ota_jscm_rx \
  --checkpoint runs/jscm_6k/best_fm.pt \
  --output recovered.wav \
  --endpoint tcp://0.0.0.0:5556 \
  --frames 500
```

GNU Radio骨架位于`gnuradio/`。UHD设备序列号、中心频率、TX/RX gain和采样率在`configs/radio/`中填写。

## 8. 通过TX Gain控制并实测SNR

固定RX gain、带宽、采样率、距离和AGC状态，只改变TX gain。

单次记录计算：

```bash
python -m apps.calibration.estimate_usrp_snr \
  --active-iq runs/gain_10/active_iq.npy \
  --noise-iq runs/gain_10/noise_iq.npy \
  --reference-symbols runs/gain_10/reference_symbols.npy \
  --received-symbols runs/gain_10/received_symbols.npy \
  --tx-gain-db 10 \
  --output runs/gain_10/snr_estimate.json
```

采用：

```text
SNR = 10 log10((P_signal+noise - P_noise) / P_noise)
```

符号域Es/N0通过已知训练符号最小二乘估计复增益后，用残差功率计算。

多Gain自动汇总：

```bash
python -m apps.calibration.aggregate_gain_sweep \
  --root runs/gain_sweep \
  --output-dir runs/gain_sweep/summary \
  --fit-snr-column symbol_esn0_db \
  --target-snr-db 0 5 10 15 20
```

随后让Benchmark读取标定结果：

```bash
python -m apps.evaluation.benchmark \
  --checkpoint runs/jscm_6k/best_fm.pt \
  --data-root /home/data \
  --gain-snr-file runs/gain_sweep/summary/gain_sweep.csv \
  --output-dir runs/benchmark
```

## 9. 测试

```bash
python -m unittest discover -s tests -v
```

## 当前边界

- GNU Radio调制解调运行在连接USRP的主机侧；
- USRP负责基带采样、上下变频和射频收发；
- 帧结构是BLE-like原型，不是标准BLE协议栈；
- 当前未包含真实训练权重和实机USRP结果；
- 空口主横轴应使用实测Es/N0，而不是直接使用TX Gain。

## 9. GNU Radio 3.10.12.0与X310流图

本版本已经写入以下固定设备配置：

```text
GNU Radio  3.10.12.0
TX X310 IP 192.168.10.1
RX X310 IP 192.168.10.2
FPGA       HG
UHD type   x300
master clock 200 MHz
sample rate  4 MS/s
symbol rate  1 Msymbol/s
SPS          4
```

先检查设备：

```bash
source gnuradio/scripts/setup_env.sh
python gnuradio/scripts/verify_x310.py
```

可编辑GRC流图：

```text
gnuradio/grc/jscm_tx.grc
gnuradio/grc/jscm_rx.grc
gnuradio/grc/sscc_tx.grc
gnuradio/grc/sscc_rx.grc
```

打开前必须设置自定义块路径：

```bash
source gnuradio/scripts/setup_env.sh
gnuradio-companion gnuradio/grc/jscm_tx.grc
```

### JSCM空口运行顺序

接收主机先启动神经解码器：

```bash
python -m apps.ota.ota_jscm_rx \
  --checkpoint runs/jscm_6k/best_fm.pt \
  --output runs/recovered.wav \
  --endpoint tcp://0.0.0.0:5556 \
  --frames 500
```

再启动RX GNU Radio流图：

```bash
gnuradio/scripts/run_jscm_rx.sh \
  --device-ip 192.168.10.2 \
  --center-freq 2.45e9 \
  --rx-gain 20 \
  --timing-phase 0 \
  --iq-record-path runs/jscm_rx.c64
```

发送主机启动TX GNU Radio流图：

```bash
gnuradio/scripts/run_jscm_tx.sh \
  --device-ip 192.168.10.1 \
  --center-freq 2.45e9 \
  --tx-gain 10
```

最后启动神经编码器：

```bash
python -m apps.ota.ota_jscm_tx \
  --checkpoint runs/jscm_6k/best_fm.pt \
  --input input.wav \
  --endpoint tcp://127.0.0.1:5555
```

### SSCC空口流图

```bash
gnuradio/scripts/run_sscc_rx.sh --device-ip 192.168.10.2 --rx-gain 20
gnuradio/scripts/run_sscc_tx.sh --device-ip 192.168.10.1 --tx-gain 10
```

JSCM和SSCC共用相同高斯成形FM物理链路。区别是：

- JSCM payload为连续浮点符号，接收端不做硬判决；
- SSCC payload为二进制符号，接收端恢复为bitstream，因此等价于GFSK。

更详细说明见：

```text
gnuradio/README.md
```

注意：若两台X310连接到同一台主机，主机网卡地址不能占用`192.168.10.1`或`192.168.10.2`。由于这里按你提供的信息把二者视为USRP设备地址，主机应使用同子网内不冲突的其他地址；若`192.168.10.1`实际是主机网卡地址，应修改TX设备IP后再运行。
