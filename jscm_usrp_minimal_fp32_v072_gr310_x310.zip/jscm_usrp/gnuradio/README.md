# GNU Radio 3.10.12 / USRP X310 flowgraphs

## Fixed hardware mapping

- TX X310: `addr=192.168.10.1`, FPGA image `HG`
- RX X310: `addr=192.168.10.2`, FPGA image `HG`
- Device type reported by UHD: `x300`
- Master clock: 200 MHz
- RF sample rate: 4 MS/s
- Symbol rate: 1 Msymbol/s
- SPS: 4
- BT: 0.5
- modulation index: 0.5

The Python flowgraphs are the executable reference. The `.grc` files are editable GNU Radio Companion versions using the two custom block definitions in `grc_blocks/`.

## Environment

```bash
cd /path/to/jscm_usrp
source gnuradio/scripts/setup_env.sh
uhd_find_devices
uhd_usrp_probe --args addr=192.168.10.1
uhd_usrp_probe --args addr=192.168.10.2
```

Open GRC after sourcing the environment:

```bash
gnuradio-companion gnuradio/grc/jscm_tx.grc
```

## JSCM

RX host/process first:

```bash
gnuradio/scripts/run_jscm_rx.sh \
  --device-ip 192.168.10.2 \
  --center-freq 2.45e9 \
  --rx-gain 20 \
  --timing-phase 0 \
  --iq-record-path runs/rx_jscm.c64
```

Start the neural receiver:

```bash
python -m apps.ota.ota_jscm_rx \
  --checkpoint runs/jscm_6k/best_fm.pt \
  --output runs/jscm_ota.wav \
  --endpoint tcp://0.0.0.0:5556 \
  --frames 500
```

TX GNU Radio process:

```bash
gnuradio/scripts/run_jscm_tx.sh \
  --device-ip 192.168.10.1 \
  --center-freq 2.45e9 \
  --tx-gain 10
```

Start the neural transmitter:

```bash
python -m apps.ota.ota_jscm_tx \
  --checkpoint runs/jscm_6k/best_fm.pt \
  --input input.wav \
  --endpoint tcp://127.0.0.1:5555
```

## SSCC

Use `run_sscc_rx.sh` and `run_sscc_tx.sh`. The physical chain is the same Gaussian-shaped FM implementation, but SSCC payload symbols are binary `-1/+1`, hence GFSK. The receiver hard-decides only SSCC payloads; JSCM payloads remain continuous.

## Parameter alignment

TX sensitivity:

```text
pi * h / SPS = pi * 0.5 / 4
```

RX quadrature-demod gain:

```text
SPS / (pi * h)
```

The packet sink estimates an affine correction from the 40-symbol preamble/access-address field. This compensates the main quadrature-demod DC offset caused by CFO and restores payload amplitude before parsing.

## Timing phase

Start with `--timing-phase 0`. If synchronization fails in cable loopback, try `0,1,2,3` and keep the phase with the highest frame success rate. This is the initial integer-SPS timing search; it is not a full timing-recovery loop.

## Safety

For cabled loopback, insert sufficient RF attenuation and ensure the X310 RX input is not overdriven. Start from low TX gain and inspect the recorded IQ amplitude before increasing power.
