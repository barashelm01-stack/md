"""GNU Radio custom stream blocks bridging RadioPacket ZeroMQ messages and symbol streams.

Compatible with GNU Radio 3.10 and Python 3.9.
"""
from __future__ import annotations

import time
from pathlib import Path
import sys
from typing import Optional

import numpy as np
from gnuradio import gr

_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(_ROOT / "src"))

from jscm.radio_ipc import PacketReceiver, PacketSender
from jscm.radio_protocol import RadioMode, RadioPacket
from jscm.ble_like import (
    ACCESS_ADDRESS,
    PREAMBLE,
    bits_to_bipolar,
    build_header,
    find_sync,
    frame_bits,
    frame_continuous,
    parse_header,
)


def _parse_mode(mode: str) -> RadioMode:
    normalized = str(mode).strip().lower()
    table = {
        "jscm": RadioMode.JSCM_CONTINUOUS,
        "jscm_continuous": RadioMode.JSCM_CONTINUOUS,
        "sscc": RadioMode.SSCC_BITS,
        "sscc_bits": RadioMode.SSCC_BITS,
        "opus": RadioMode.OPUS_BYTES,
        "opus_bytes": RadioMode.OPUS_BYTES,
    }
    if normalized not in table:
        raise ValueError("unsupported radio mode: %s" % mode)
    return table[normalized]


class PacketFloatSource(gr.sync_block):
    """Receive RadioPacket messages and emit framed symbol-rate float samples."""

    def __init__(
        self,
        endpoint: str = "tcp://127.0.0.1:5555",
        bind: bool = True,
        mode: str = "jscm",
        idle_symbols: int = 64,
    ) -> None:
        gr.sync_block.__init__(self, name="Packet Float Source", in_sig=None, out_sig=[np.float32])
        self.mode = _parse_mode(mode)
        self.receiver = PacketReceiver(endpoint=endpoint, bind=bool(bind), high_water_mark=1000)
        self.idle_symbols = max(int(idle_symbols), 0)
        self._queue = np.zeros(self.idle_symbols, dtype=np.float32)
        self._offset = 0

    def _load_packet(self) -> bool:
        packet = self.receiver.recv_nonblocking()
        if packet is None:
            return False
        if packet.mode != self.mode:
            return False
        if self.mode == RadioMode.JSCM_CONTINUOUS:
            framed = frame_continuous(packet.payload, packet.sequence_id)
        else:
            framed = frame_bits(packet.payload, self.mode, packet.sequence_id)
        if self.idle_symbols:
            self._queue = np.concatenate(
                [framed.symbols.astype(np.float32, copy=False), np.zeros(self.idle_symbols, dtype=np.float32)]
            )
        else:
            self._queue = framed.symbols.astype(np.float32, copy=False)
        self._offset = 0
        return True

    def work(self, input_items, output_items):
        output = output_items[0]
        produced = 0
        while produced < output.size:
            if self._offset >= self._queue.size:
                if not self._load_packet():
                    output[produced:] = 0.0
                    return output.size
            available = self._queue.size - self._offset
            count = min(output.size - produced, available)
            output[produced:produced + count] = self._queue[self._offset:self._offset + count]
            produced += count
            self._offset += count
        return produced

    def stop(self) -> bool:
        self.receiver.close()
        return True


class PacketFloatSink(gr.sync_block):
    """Detect BLE-like frames in a symbol-rate float stream and publish RadioPackets.

    The synchronisation field is used to estimate an affine correction y = a*x+b.
    This removes the quadrature-demodulator DC offset caused by CFO and restores
    payload scaling before Header parsing and JSCM continuous-symbol delivery.
    """

    def __init__(
        self,
        endpoint: str = "tcp://0.0.0.0:5556",
        bind: bool = True,
        expected_mode: str = "jscm",
        max_sync_errors: int = 4,
        max_buffer_symbols: int = 65536,
        sample_rate: int = 16000,
    ) -> None:
        gr.sync_block.__init__(self, name="Packet Float Sink", in_sig=[np.float32], out_sig=None)
        self.expected_mode = _parse_mode(expected_mode)
        self.sender = PacketSender(endpoint=endpoint, bind=bool(bind), high_water_mark=1000)
        self.max_sync_errors = max(int(max_sync_errors), 0)
        self.max_buffer_symbols = max(int(max_buffer_symbols), 512)
        self.sample_rate = int(sample_rate)
        self._buffer = np.empty(0, dtype=np.float32)
        self._sync_reference = bits_to_bipolar(np.concatenate([PREAMBLE, ACCESS_ADDRESS]))
        self.frames_ok = 0
        self.frames_rejected = 0

    def _affine_normalize(self, frame: np.ndarray) -> np.ndarray:
        observed = frame[: self._sync_reference.size].astype(np.float64)
        reference = self._sync_reference.astype(np.float64)
        matrix = np.column_stack([reference, np.ones(reference.size, dtype=np.float64)])
        scale, bias = np.linalg.lstsq(matrix, observed, rcond=None)[0]
        if abs(scale) < 1e-6:
            raise ValueError("invalid synchronization scale")
        return ((frame.astype(np.float64) - bias) / scale).astype(np.float32)

    def _consume_frames(self) -> None:
        sync_len = self._sync_reference.size
        header_len = 32
        while True:
            start = find_sync(self._buffer, self.max_sync_errors)
            if start is None:
                keep = min(self._buffer.size, sync_len - 1)
                self._buffer = self._buffer[-keep:] if keep else np.empty(0, dtype=np.float32)
                return
            if start > 0:
                self._buffer = self._buffer[start:]
            if self._buffer.size < sync_len + header_len:
                return

            prefix = self._buffer[: sync_len + header_len]
            try:
                normalized_prefix = self._affine_normalize(prefix)
                mode, sequence_id, payload_length = parse_header(
                    normalized_prefix[sync_len:sync_len + header_len]
                )
            except Exception:
                self.frames_rejected += 1
                self._buffer = self._buffer[1:]
                continue

            frame_length = sync_len + header_len + int(payload_length)
            if frame_length <= sync_len + header_len or frame_length > self.max_buffer_symbols:
                self.frames_rejected += 1
                self._buffer = self._buffer[1:]
                continue
            if self._buffer.size < frame_length:
                return

            raw_frame = self._buffer[:frame_length]
            self._buffer = self._buffer[frame_length:]
            try:
                normalized = self._affine_normalize(raw_frame)
                payload = normalized[sync_len + header_len:].copy()
                if mode != RadioMode.JSCM_CONTINUOUS:
                    payload = (payload >= 0.0).astype(np.uint8)
                if mode != self.expected_mode:
                    self.frames_rejected += 1
                    continue
                packet = RadioPacket(
                    mode=mode,
                    sequence_id=int(sequence_id),
                    payload=payload,
                    sample_rate=self.sample_rate,
                    timestamp_ns=time.time_ns(),
                    metadata={
                        "receiver": "gnu_radio_3.10",
                        "sync_errors_allowed": self.max_sync_errors,
                    },
                )
                self.sender.send(packet)
                self.frames_ok += 1
            except Exception:
                self.frames_rejected += 1

    def work(self, input_items, output_items):
        incoming = np.asarray(input_items[0], dtype=np.float32)
        if incoming.size:
            self._buffer = np.concatenate([self._buffer, incoming])
            if self._buffer.size > self.max_buffer_symbols:
                self._buffer = self._buffer[-self.max_buffer_symbols:]
            self._consume_frames()
        return incoming.size

    def stop(self) -> bool:
        self.sender.close()
        return True
