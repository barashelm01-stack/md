#!/usr/bin/env python3
"""Verify GNU Radio/UHD and probe the configured X310 devices."""
from __future__ import annotations

import argparse
import shutil
import subprocess
import sys


def run(command):
    print("$ " + " ".join(command))
    result = subprocess.run(command, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    print(result.stdout)
    return result.returncode


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--tx-ip", default="192.168.10.1")
    parser.add_argument("--rx-ip", default="192.168.10.2")
    args = parser.parse_args()

    required = ["gnuradio-config-info", "uhd_find_devices", "uhd_usrp_probe"]
    missing = [name for name in required if shutil.which(name) is None]
    if missing:
        raise SystemExit("Missing commands: " + ", ".join(missing))

    status = 0
    status |= run(["gnuradio-config-info", "--version"])
    status |= run(["uhd_find_devices"])
    status |= run(["uhd_usrp_probe", "--args", "addr=" + args.tx_ip])
    status |= run(["uhd_usrp_probe", "--args", "addr=" + args.rx_ip])
    raise SystemExit(1 if status else 0)


if __name__ == "__main__":
    main()
