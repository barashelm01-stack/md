#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
export PYTHONPATH="$ROOT/src:$ROOT/gnuradio/blocks:$ROOT/gnuradio/python:${PYTHONPATH:-}"
export GRC_BLOCKS_PATH="$ROOT/gnuradio/grc_blocks:${GRC_BLOCKS_PATH:-}"
echo "PYTHONPATH=$PYTHONPATH"
echo "GRC_BLOCKS_PATH=$GRC_BLOCKS_PATH"
