#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
source "$ROOT/gnuradio/scripts/setup_env.sh"
python3 "$ROOT/gnuradio/python/jscm_tx_flowgraph.py" "$@"
