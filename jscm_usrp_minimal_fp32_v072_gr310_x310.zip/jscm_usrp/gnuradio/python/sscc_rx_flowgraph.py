#!/usr/bin/env python3
from __future__ import annotations
import argparse
from common_fm_flowgraph import FMX310Receiver, add_common_rx_args, run_flowgraph

def main() -> None:
    parser = argparse.ArgumentParser(description="SSCC GFSK receiver for X310")
    add_common_rx_args(parser, "sscc")
    args = parser.parse_args()
    tb = FMX310Receiver(
        endpoint=args.endpoint, mode="sscc", device_ip=args.device_ip,
        center_freq=args.center_freq, sample_rate=args.sample_rate,
        symbol_rate=args.symbol_rate, rx_gain=args.rx_gain,
        rf_bandwidth=args.rf_bandwidth, antenna=args.antenna,
        subdev=args.subdev, master_clock_rate=args.master_clock_rate,
        bt=args.bt, modulation_index=args.modulation_index,
        timing_phase=args.timing_phase, rx_scale=args.rx_scale,
        max_sync_errors=args.max_sync_errors,
        zmq_bind=args.zmq_bind, iq_record_path=args.iq_record_path,
    )
    run_flowgraph(tb)

if __name__ == "__main__":
    main()
