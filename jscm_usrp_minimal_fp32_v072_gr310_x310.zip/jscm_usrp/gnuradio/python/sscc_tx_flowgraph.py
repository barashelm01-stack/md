#!/usr/bin/env python3
from __future__ import annotations
import argparse
from common_fm_flowgraph import FMX310Transmitter, add_common_tx_args, run_flowgraph

def main() -> None:
    parser = argparse.ArgumentParser(description="SSCC GFSK transmitter for X310")
    add_common_tx_args(parser, "sscc")
    args = parser.parse_args()
    tb = FMX310Transmitter(
        endpoint=args.endpoint, mode="sscc", device_ip=args.device_ip,
        center_freq=args.center_freq, sample_rate=args.sample_rate,
        symbol_rate=args.symbol_rate, tx_gain=args.tx_gain,
        rf_bandwidth=args.rf_bandwidth, antenna=args.antenna,
        subdev=args.subdev, master_clock_rate=args.master_clock_rate,
        bt=args.bt, modulation_index=args.modulation_index,
        tx_amplitude=args.tx_amplitude, idle_symbols=args.idle_symbols,
        zmq_bind=not args.zmq_connect,
    )
    run_flowgraph(tb)

if __name__ == "__main__":
    main()
