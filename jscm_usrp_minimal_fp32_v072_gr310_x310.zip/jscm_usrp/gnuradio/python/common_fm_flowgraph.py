"""Shared GNU Radio 3.10.12 FM/GFSK flowgraphs for USRP X310 devices."""
from __future__ import annotations

import argparse
import signal
import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(_ROOT / "src"))
sys.path.insert(0, str(_ROOT / "gnuradio" / "blocks"))

from gnuradio import analog, blocks, filter, gr, uhd
from gnuradio.filter import firdes

from packet_blocks import PacketFloatSink, PacketFloatSource


DEFAULT_TX_IP = "192.168.10.1"
DEFAULT_RX_IP = "192.168.10.2"
DEFAULT_CENTER_FREQ = 2.45e9
DEFAULT_SAMPLE_RATE = 4.0e6
DEFAULT_SYMBOL_RATE = 1.0e6
DEFAULT_SPS = 4
DEFAULT_BT = 0.5
DEFAULT_H = 0.5
DEFAULT_MASTER_CLOCK = 200.0e6


def gaussian_taps(sps: int, bt: float, span_symbols: int = 4):
    ntaps = int(span_symbols * sps + 1)
    if ntaps % 2 == 0:
        ntaps += 1
    taps = firdes.gaussian(1.0, int(sps), float(bt), ntaps)
    total = sum(taps)
    if abs(total) < 1e-12:
        raise RuntimeError("invalid Gaussian taps")
    return [float(value / total) for value in taps]


class FMX310Transmitter(gr.top_block):
    def __init__(
        self,
        endpoint: str,
        mode: str,
        device_ip: str = DEFAULT_TX_IP,
        center_freq: float = DEFAULT_CENTER_FREQ,
        sample_rate: float = DEFAULT_SAMPLE_RATE,
        symbol_rate: float = DEFAULT_SYMBOL_RATE,
        tx_gain: float = 10.0,
        rf_bandwidth: float = 4.0e6,
        antenna: str = "TX/RX",
        subdev: str = "A:0",
        master_clock_rate: float = DEFAULT_MASTER_CLOCK,
        bt: float = DEFAULT_BT,
        modulation_index: float = DEFAULT_H,
        tx_amplitude: float = 0.5,
        idle_symbols: int = 64,
        zmq_bind: bool = True,
    ) -> None:
        gr.top_block.__init__(self, "JSCM X310 Transmitter", catch_exceptions=True)
        ratio = float(sample_rate) / float(symbol_rate)
        sps = int(round(ratio))
        if sps <= 0 or abs(ratio - sps) > 1e-9:
            raise ValueError("sample_rate/symbol_rate must be a positive integer")
        sensitivity = 3.141592653589793 * float(modulation_index) / float(sps)
        taps = gaussian_taps(sps, bt)

        self.packet_source = PacketFloatSource(
            endpoint=endpoint,
            bind=zmq_bind,
            mode=mode,
            idle_symbols=idle_symbols,
        )
        self.gaussian_interp = filter.interp_fir_filter_fff(sps, taps)
        self.fm_mod = analog.frequency_modulator_fc(sensitivity)
        self.amplitude = blocks.multiply_const_cc(float(tx_amplitude))

        device_args = "addr=%s,master_clock_rate=%g" % (device_ip, master_clock_rate)
        self.usrp_sink = uhd.usrp_sink(
            device_args,
            uhd.stream_args(cpu_format="fc32", otw_format="sc16", channels=[0]),
            "",
        )
        self.usrp_sink.set_subdev_spec(subdev, 0)
        self.usrp_sink.set_samp_rate(sample_rate)
        self.usrp_sink.set_center_freq(uhd.tune_request(center_freq), 0)
        self.usrp_sink.set_gain(tx_gain, 0)
        self.usrp_sink.set_bandwidth(rf_bandwidth, 0)
        self.usrp_sink.set_antenna(antenna, 0)

        self.connect(self.packet_source, self.gaussian_interp)
        self.connect(self.gaussian_interp, self.fm_mod)
        self.connect(self.fm_mod, self.amplitude)
        self.connect(self.amplitude, self.usrp_sink)


class FMX310Receiver(gr.top_block):
    def __init__(
        self,
        endpoint: str,
        mode: str,
        device_ip: str = DEFAULT_RX_IP,
        center_freq: float = DEFAULT_CENTER_FREQ,
        sample_rate: float = DEFAULT_SAMPLE_RATE,
        symbol_rate: float = DEFAULT_SYMBOL_RATE,
        rx_gain: float = 20.0,
        rf_bandwidth: float = 4.0e6,
        antenna: str = "RX2",
        subdev: str = "A:0",
        master_clock_rate: float = DEFAULT_MASTER_CLOCK,
        bt: float = DEFAULT_BT,
        modulation_index: float = DEFAULT_H,
        timing_phase: int = 0,
        rx_scale: float = 1.0,
        max_sync_errors: int = 4,
        zmq_bind: bool = True,
        iq_record_path: str = "",
    ) -> None:
        gr.top_block.__init__(self, "JSCM X310 Receiver", catch_exceptions=True)
        ratio = float(sample_rate) / float(symbol_rate)
        sps = int(round(ratio))
        if sps <= 0 or abs(ratio - sps) > 1e-9:
            raise ValueError("sample_rate/symbol_rate must be a positive integer")
        if timing_phase < 0 or timing_phase >= sps:
            raise ValueError("timing_phase must be in [0, sps-1]")
        sensitivity = 3.141592653589793 * float(modulation_index) / float(sps)
        demod_gain = 1.0 / sensitivity
        taps = gaussian_taps(sps, bt)

        device_args = "addr=%s,master_clock_rate=%g" % (device_ip, master_clock_rate)
        self.usrp_source = uhd.usrp_source(
            device_args,
            uhd.stream_args(cpu_format="fc32", otw_format="sc16", channels=[0]),
            "",
        )
        self.usrp_source.set_subdev_spec(subdev, 0)
        self.usrp_source.set_samp_rate(sample_rate)
        self.usrp_source.set_center_freq(uhd.tune_request(center_freq), 0)
        self.usrp_source.set_gain(rx_gain, 0)
        self.usrp_source.set_bandwidth(rf_bandwidth, 0)
        self.usrp_source.set_antenna(antenna, 0)

        self.quad_demod = analog.quadrature_demod_cf(demod_gain)
        self.skip_phase = blocks.skiphead(gr.sizeof_float, int(timing_phase))
        self.matched_decim = filter.fir_filter_fff(sps, taps)
        self.scale = blocks.multiply_const_ff(float(rx_scale))
        self.packet_sink = PacketFloatSink(
            endpoint=endpoint,
            bind=zmq_bind,
            expected_mode=mode,
            max_sync_errors=max_sync_errors,
            sample_rate=16000,
        )

        self.connect(self.usrp_source, self.quad_demod)
        self.connect(self.quad_demod, self.skip_phase)
        self.connect(self.skip_phase, self.matched_decim)
        self.connect(self.matched_decim, self.scale)
        self.connect(self.scale, self.packet_sink)

        self.iq_file_sink = None
        if iq_record_path:
            self.iq_file_sink = blocks.file_sink(gr.sizeof_gr_complex, iq_record_path, False)
            self.iq_file_sink.set_unbuffered(False)
            self.connect(self.usrp_source, self.iq_file_sink)


def add_common_tx_args(parser: argparse.ArgumentParser, default_mode: str) -> None:
    parser.add_argument("--endpoint", default="tcp://127.0.0.1:5555")
    parser.add_argument("--mode", default=default_mode, choices=["jscm", "sscc", "opus"])
    parser.add_argument("--device-ip", default=DEFAULT_TX_IP)
    parser.add_argument("--center-freq", type=float, default=DEFAULT_CENTER_FREQ)
    parser.add_argument("--sample-rate", type=float, default=DEFAULT_SAMPLE_RATE)
    parser.add_argument("--symbol-rate", type=float, default=DEFAULT_SYMBOL_RATE)
    parser.add_argument("--tx-gain", type=float, default=10.0)
    parser.add_argument("--rf-bandwidth", type=float, default=4.0e6)
    parser.add_argument("--antenna", default="TX/RX")
    parser.add_argument("--subdev", default="A:0")
    parser.add_argument("--master-clock-rate", type=float, default=DEFAULT_MASTER_CLOCK)
    parser.add_argument("--bt", type=float, default=DEFAULT_BT)
    parser.add_argument("--modulation-index", type=float, default=DEFAULT_H)
    parser.add_argument("--tx-amplitude", type=float, default=0.5)
    parser.add_argument("--idle-symbols", type=int, default=64)
    parser.add_argument("--zmq-connect", action="store_true", help="Connect instead of bind on the GNU Radio side")


def add_common_rx_args(parser: argparse.ArgumentParser, default_mode: str) -> None:
    parser.add_argument("--endpoint", default="tcp://127.0.0.1:5556")
    parser.add_argument("--mode", default=default_mode, choices=["jscm", "sscc", "opus"])
    parser.add_argument("--device-ip", default=DEFAULT_RX_IP)
    parser.add_argument("--center-freq", type=float, default=DEFAULT_CENTER_FREQ)
    parser.add_argument("--sample-rate", type=float, default=DEFAULT_SAMPLE_RATE)
    parser.add_argument("--symbol-rate", type=float, default=DEFAULT_SYMBOL_RATE)
    parser.add_argument("--rx-gain", type=float, default=20.0)
    parser.add_argument("--rf-bandwidth", type=float, default=4.0e6)
    parser.add_argument("--antenna", default="RX2")
    parser.add_argument("--subdev", default="A:0")
    parser.add_argument("--master-clock-rate", type=float, default=DEFAULT_MASTER_CLOCK)
    parser.add_argument("--bt", type=float, default=DEFAULT_BT)
    parser.add_argument("--modulation-index", type=float, default=DEFAULT_H)
    parser.add_argument("--timing-phase", type=int, default=0)
    parser.add_argument("--rx-scale", type=float, default=1.0)
    parser.add_argument("--max-sync-errors", type=int, default=4)
    parser.add_argument("--iq-record-path", default="")
    parser.add_argument("--zmq-bind", action="store_true", help="Bind instead of connect on the GNU Radio RX side")


def run_flowgraph(top_block: gr.top_block) -> None:
    def stop_handler(signum=None, frame=None):
        top_block.stop()
        top_block.wait()
        raise SystemExit(0)

    signal.signal(signal.SIGINT, stop_handler)
    signal.signal(signal.SIGTERM, stop_handler)
    top_block.start()
    top_block.wait()
