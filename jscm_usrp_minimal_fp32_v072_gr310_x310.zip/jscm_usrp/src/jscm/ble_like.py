from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence, Union

import numpy as np
import torch


BLE_LIKE_PREAMBLE = 0xAA
BLE_LIKE_ACCESS_ADDRESS = 0x8E89BED6
BLE_LIKE_SYNC_BITS = 40
BLE_LIKE_HEADER_BITS = 16
BLE_LIKE_OVERHEAD_BITS = BLE_LIKE_SYNC_BITS + BLE_LIKE_HEADER_BITS


def bytes_to_bits_lsb(data: Union[bytes, bytearray, np.ndarray]) -> np.ndarray:
    array = np.frombuffer(bytes(data), dtype=np.uint8)
    if array.size == 0:
        return np.empty(0, dtype=np.uint8)
    return np.unpackbits(array, bitorder="little").astype(np.uint8, copy=False)


def bits_to_bytes_lsb(bits: Union[Sequence[int], np.ndarray]) -> bytes:
    array = np.asarray(bits, dtype=np.uint8).reshape(-1)
    if array.size % 8:
        raise ValueError("bit count must be a multiple of 8")
    return np.packbits(array, bitorder="little").tobytes()


def uint16_to_bits_lsb(value: int) -> np.ndarray:
    if not 0 <= value <= 0xFFFF:
        raise ValueError("value must fit in uint16")
    return bytes_to_bits_lsb(int(value).to_bytes(2, byteorder="little", signed=False))


def bits_lsb_to_uint16(bits: Union[Sequence[int], np.ndarray]) -> int:
    raw = bits_to_bytes_lsb(bits)
    if len(raw) != 2:
        raise ValueError("expected exactly 16 bits")
    return int.from_bytes(raw, byteorder="little", signed=False)


def sync_bits(
    preamble: int = BLE_LIKE_PREAMBLE,
    access_address: int = BLE_LIKE_ACCESS_ADDRESS,
) -> np.ndarray:
    return np.concatenate(
        [
            bytes_to_bits_lsb(bytes([preamble])),
            bytes_to_bits_lsb(access_address.to_bytes(4, "little")),
        ]
    )


@dataclass(frozen=True)
class BLELikeDecodeResult:
    success: bool
    packet_start: int
    payload_start: int
    payload_length: int
    sync_errors: int
    reason: str
    payload_bits: np.ndarray


class BLELikeBitFramer:
    """BLE-inspired preamble/access/header framing without whitening or CRC.

    The 16-bit header stores payload length in bits as an unsigned little-endian
    integer. This is intentionally BLE-like rather than standards-compliant BLE.
    Unlike the previous oracle framing path, the receiver searches the sync word,
    parses the header, validates the recovered length, and can report packet loss.
    """

    def __init__(
        self,
        preamble: int = BLE_LIKE_PREAMBLE,
        access_address: int = BLE_LIKE_ACCESS_ADDRESS,
        max_sync_errors: int = 0,
        max_payload_bits: int = 0xFFFF,
    ) -> None:
        self.preamble = int(preamble)
        self.access_address = int(access_address)
        self.max_sync_errors = int(max_sync_errors)
        self.max_payload_bits = int(max_payload_bits)
        self.sync = sync_bits(self.preamble, self.access_address)

    @property
    def overhead_bits(self) -> int:
        return BLE_LIKE_OVERHEAD_BITS

    def frame_bits(self, payload_bits: Union[Sequence[int], np.ndarray]) -> np.ndarray:
        payload = np.asarray(payload_bits, dtype=np.uint8).reshape(-1)
        if payload.size > self.max_payload_bits:
            raise ValueError(f"payload has {payload.size} bits, max is {self.max_payload_bits}")
        if np.any((payload != 0) & (payload != 1)):
            raise ValueError("payload_bits must contain only 0/1")
        header = uint16_to_bits_lsb(int(payload.size))
        return np.concatenate([self.sync, header, payload])

    def deframe_bits(self, received_bits: Union[Sequence[int], np.ndarray]) -> BLELikeDecodeResult:
        bits = np.asarray(received_bits, dtype=np.uint8).reshape(-1)
        minimum = BLE_LIKE_OVERHEAD_BITS
        if bits.size < minimum:
            return BLELikeDecodeResult(False, -1, -1, 0, -1, "too_short", np.empty(0, np.uint8))
        best_start = -1
        best_errors = self.sync.size + 1
        final_start = bits.size - minimum
        for start in range(final_start + 1):
            errors = int(np.count_nonzero(bits[start : start + self.sync.size] != self.sync))
            if errors < best_errors:
                best_errors = errors
                best_start = start
                if errors == 0:
                    break
        if best_start < 0 or best_errors > self.max_sync_errors:
            return BLELikeDecodeResult(False, best_start, -1, 0, best_errors, "sync_not_found", np.empty(0, np.uint8))
        header_start = best_start + self.sync.size
        payload_start = header_start + BLE_LIKE_HEADER_BITS
        payload_length = bits_lsb_to_uint16(bits[header_start:payload_start])
        if payload_length > self.max_payload_bits:
            return BLELikeDecodeResult(False, best_start, payload_start, payload_length, best_errors, "invalid_length", np.empty(0, np.uint8))
        payload_end = payload_start + payload_length
        if payload_end > bits.size:
            return BLELikeDecodeResult(False, best_start, payload_start, payload_length, best_errors, "truncated_payload", np.empty(0, np.uint8))
        return BLELikeDecodeResult(
            True,
            best_start,
            payload_start,
            payload_length,
            best_errors,
            "ok",
            bits[payload_start:payload_end].copy(),
        )


@dataclass(frozen=True)
class BLELikeSymbolDecodeResult:
    success: torch.Tensor
    packet_start: torch.Tensor
    payload_start: torch.Tensor
    payload_length: torch.Tensor
    sync_errors: torch.Tensor
    payload: torch.Tensor


class BLELikeSymbolFramer:
    """Frame continuous symbols and recover them using a hard-decoded BLE-like header.

    Header bits are mapped to +/- ``header_amplitude``. The continuous payload is
    not quantized. Deframing uses the header only to find packet start and recover
    the declared symbol count. This mode is intended for evaluation because sync
    search and hard header decisions are non-differentiable.
    """

    def __init__(
        self,
        header_amplitude: float = 0.95,
        max_sync_errors: int = 0,
        max_payload_symbols: int = 0xFFFF,
    ) -> None:
        self.header_amplitude = float(header_amplitude)
        self.bit_framer = BLELikeBitFramer(
            max_sync_errors=max_sync_errors,
            max_payload_bits=max_payload_symbols,
        )

    @property
    def overhead_symbols(self) -> int:
        return self.bit_framer.overhead_bits

    def frame(self, payload: torch.Tensor) -> torch.Tensor:
        if payload.ndim != 3:
            raise ValueError(f"Expected [B,F,K], got {tuple(payload.shape)}")
        batch, frames, symbols = payload.shape
        header_bits = np.concatenate([self.bit_framer.sync, uint16_to_bits_lsb(symbols)])
        header_bipolar = header_bits.astype(np.float32) * 2.0 - 1.0
        header = torch.as_tensor(header_bipolar, device=payload.device, dtype=payload.dtype)
        header = header.mul(self.header_amplitude).view(1, 1, -1).expand(batch, frames, -1)
        return torch.cat([header, payload], dim=-1)

    def deframe(self, recovered_symbols: torch.Tensor, expected_payload_symbols: int) -> BLELikeSymbolDecodeResult:
        if recovered_symbols.ndim != 3:
            raise ValueError(f"Expected [B,F,N], got {tuple(recovered_symbols.shape)}")
        batch, frames, total = recovered_symbols.shape
        flat = recovered_symbols.reshape(batch * frames, total)
        payloads = recovered_symbols.new_zeros(batch * frames, expected_payload_symbols)
        success = torch.zeros(batch * frames, dtype=torch.bool, device=recovered_symbols.device)
        packet_start = torch.full((batch * frames,), -1, dtype=torch.long, device=recovered_symbols.device)
        payload_start = torch.full_like(packet_start, -1)
        payload_length = torch.zeros_like(packet_start)
        sync_errors = torch.full_like(packet_start, -1)
        sync = torch.as_tensor(self.bit_framer.sync, device=recovered_symbols.device, dtype=torch.uint8)
        sync_len = int(sync.numel())
        for index in range(flat.shape[0]):
            hard = (flat[index] >= 0).to(torch.uint8)
            best_start = -1
            best_errors = sync_len + 1
            max_start = total - BLE_LIKE_OVERHEAD_BITS
            for start in range(max_start + 1):
                errors = int((hard[start : start + sync_len] != sync).sum().item())
                if errors < best_errors:
                    best_errors = errors
                    best_start = start
                    if errors == 0:
                        break
            packet_start[index] = best_start
            sync_errors[index] = best_errors
            if best_start < 0 or best_errors > self.bit_framer.max_sync_errors:
                continue
            header_start = best_start + sync_len
            pstart = header_start + BLE_LIKE_HEADER_BITS
            length_bits = hard[header_start:pstart].detach().cpu().numpy()
            length = bits_lsb_to_uint16(length_bits)
            payload_start[index] = pstart
            payload_length[index] = length
            if length != expected_payload_symbols or pstart + length > total:
                continue
            payloads[index] = flat[index, pstart : pstart + length]
            success[index] = True
        return BLELikeSymbolDecodeResult(
            success=success.reshape(batch, frames),
            packet_start=packet_start.reshape(batch, frames),
            payload_start=payload_start.reshape(batch, frames),
            payload_length=payload_length.reshape(batch, frames),
            sync_errors=sync_errors.reshape(batch, frames),
            payload=payloads.reshape(batch, frames, expected_payload_symbols),
        )
