from __future__ import annotations

import math
from typing import Any, Optional, Union

import torch
import torch.nn as nn
import torch.nn.functional as F

from .ble_like import BLELikeSymbolFramer


def _bytes_to_bipolar(data: bytes) -> torch.Tensor:
    values: list[float] = []
    for byte in data:
        for shift in range(7, -1, -1):
            values.append(1.0 if ((byte >> shift) & 1) else -1.0)
    return torch.tensor(values, dtype=torch.float32)


def make_ble_like_header() -> torch.Tensor:
    """Return 56 bipolar symbols: preamble + access address + fixed header."""
    preamble = bytes([0xAA])
    access_address = int(0x8E89BED6).to_bytes(4, byteorder="big", signed=False)
    fixed_header = bytes([0x00, 0x00])
    return _bytes_to_bipolar(preamble + access_address + fixed_header)


def gaussian_pulse_kernel(bt: float, samples_per_symbol: int, span_symbols: int) -> torch.Tensor:
    """Generate a unit-DC-gain discrete Gaussian pulse-shaping kernel."""
    if bt <= 0:
        raise ValueError("bt must be positive")
    if samples_per_symbol < 1:
        raise ValueError("samples_per_symbol must be >= 1")
    if span_symbols < 1:
        raise ValueError("span_symbols must be >= 1")

    half = span_symbols * samples_per_symbol / 2.0
    t = torch.arange(-half, half + 1.0, dtype=torch.float64) / samples_per_symbol
    kernel = torch.exp(-2.0 * (math.pi * bt * t).square() / math.log(2.0))
    kernel = kernel / kernel.sum()
    return kernel.to(torch.float32)


def _design_symbol_equalizer(
    pulse: torch.Tensor,
    samples_per_symbol: int,
    equalizer_taps: int,
    regularization: float,
) -> torch.Tensor:
    """Design a fixed symbol-rate zero-forcing FIR for the pulse/average chain."""
    if equalizer_taps < 1 or equalizer_taps % 2 == 0:
        raise ValueError("equalizer_taps must be a positive odd integer")

    impulse_length = 65
    center = impulse_length // 2
    impulse = torch.zeros(1, 1, impulse_length, dtype=torch.float64)
    impulse[..., center] = 1.0
    upsampled = impulse.repeat_interleave(samples_per_symbol, dim=-1)
    kernel = pulse.to(torch.float64).view(1, 1, -1)
    shaped = F.conv1d(upsampled, kernel, padding=kernel.shape[-1] // 2)
    shaped = shaped[..., : upsampled.shape[-1]]
    symbol_response = F.avg_pool1d(
        shaped,
        kernel_size=samples_per_symbol,
        stride=samples_per_symbol,
    ).flatten()

    # BT=0.5 and the selected span produce an effectively five-tap symbol response.
    channel = symbol_response[center - 2 : center + 3]
    convolution_length = channel.numel() + equalizer_taps - 1
    matrix = torch.zeros(convolution_length, equalizer_taps, dtype=torch.float64)
    for column in range(equalizer_taps):
        matrix[column : column + channel.numel(), column] = channel

    target = torch.zeros(convolution_length, dtype=torch.float64)
    target[convolution_length // 2] = 1.0
    gram = matrix.T @ matrix
    rhs = matrix.T @ target
    equalizer = torch.linalg.solve(
        gram + regularization * torch.eye(equalizer_taps, dtype=torch.float64),
        rhs,
    )
    # The target channel is symmetric. Enforcing symmetry reduces numerical drift.
    equalizer = 0.5 * (equalizer + equalizer.flip(0))
    return equalizer.to(torch.float32)


def expand_packet_esn0(
    esn0_db: Union[torch.Tensor, float],
    batch: int,
    frames: int,
    device: torch.device,
) -> torch.Tensor:
    value = torch.as_tensor(esn0_db, dtype=torch.float32, device=device)
    if value.ndim == 0:
        return value.expand(batch, frames)
    if value.shape == (batch,):
        return value[:, None].expand(batch, frames)
    if value.shape == (batch, frames):
        return value
    raise ValueError(
        f"esn0_db must be scalar, [B], or [B,F]; got {tuple(value.shape)} "
        f"for B={batch}, F={frames}"
    )


class DifferentiableFMAWGN(nn.Module):
    """Packet-wise Gaussian-shaped FM over complex AWGN.

    ``framing_mode='oracle'`` is differentiable and used for training.
    ``framing_mode='detected'`` performs hard sync search and header parsing and
    is intended for evaluation. Both modes omit whitening and CRC by design.
    """

    def __init__(
        self,
        bt: float = 0.5,
        modulation_index: float = 0.5,
        samples_per_symbol: int = 4,
        span_symbols: int = 4,
        payload_peak: float = 0.95,
        equalizer_taps: int = 7,
        equalizer_regularization: float = 1e-8,
        max_sync_errors: int = 0,
    ) -> None:
        super().__init__()
        if modulation_index <= 0:
            raise ValueError("modulation_index must be positive")
        if not 0 < payload_peak <= 1:
            raise ValueError("payload_peak must be in (0, 1]")
        self.bt = float(bt)
        self.modulation_index = float(modulation_index)
        self.samples_per_symbol = int(samples_per_symbol)
        self.span_symbols = int(span_symbols)
        self.payload_peak = float(payload_peak)
        self.equalizer_taps = int(equalizer_taps)
        self.symbol_framer = BLELikeSymbolFramer(
            header_amplitude=payload_peak,
            max_sync_errors=max_sync_errors,
        )
        pulse = gaussian_pulse_kernel(bt, samples_per_symbol, span_symbols)
        equalizer = _design_symbol_equalizer(
            pulse, samples_per_symbol, equalizer_taps, equalizer_regularization
        )
        self.register_buffer("pulse", pulse.view(1, 1, -1), persistent=False)
        self.register_buffer("equalizer", equalizer.view(1, 1, -1), persistent=False)

    @property
    def header_symbols(self) -> int:
        return self.symbol_framer.overhead_symbols

    def bound_payload(self, payload: torch.Tensor) -> torch.Tensor:
        return self.payload_peak * torch.tanh(payload)

    def frame_payload(self, bounded_payload: torch.Tensor) -> torch.Tensor:
        return self.symbol_framer.frame(bounded_payload)

    def modulate_packets(
        self, framed_symbols: torch.Tensor, return_phase_increment: bool = False
    ) -> Union[torch.Tensor, tuple[torch.Tensor, torch.Tensor]]:
        if framed_symbols.ndim != 3:
            raise ValueError(f"Expected [B,F,N], got {tuple(framed_symbols.shape)}")
        batch, frames, symbols_per_frame = framed_symbols.shape
        packets = framed_symbols.reshape(batch * frames, 1, symbols_per_frame)
        upsampled = packets.repeat_interleave(self.samples_per_symbol, dim=-1)
        pulse = self.pulse.to(dtype=upsampled.dtype)
        shaped = F.conv1d(upsampled, pulse, padding=pulse.shape[-1] // 2)
        shaped = shaped[..., : upsampled.shape[-1]]
        phase_step = math.pi * self.modulation_index / self.samples_per_symbol
        phase_increment = phase_step * shaped
        phase = torch.cumsum(phase_increment, dim=-1)
        amplitude = 1.0 / math.sqrt(self.samples_per_symbol)
        tx = amplitude * torch.complex(torch.cos(phase), torch.sin(phase))
        if return_phase_increment:
            return tx, phase_increment.abs().amax()
        return tx

    def add_awgn(
        self,
        tx: torch.Tensor,
        esn0_db: Optional[Union[torch.Tensor, float]],
        batch: int,
        frames: int,
    ) -> torch.Tensor:
        if esn0_db is None:
            return tx
        packet_esn0 = expand_packet_esn0(esn0_db, batch, frames, tx.device).reshape(-1, 1, 1)
        noise_power = torch.pow(10.0, -packet_esn0 / 10.0) / self.samples_per_symbol
        noise_std = torch.sqrt(noise_power / 2.0)
        real = torch.randn(tx.shape, dtype=tx.real.dtype, device=tx.device)
        imag = torch.randn(tx.shape, dtype=tx.real.dtype, device=tx.device)
        return tx + torch.complex(real, imag) * noise_std

    def demodulate_packets(self, rx: torch.Tensor, num_symbols: int) -> torch.Tensor:
        if rx.ndim != 3 or rx.shape[1] != 1:
            raise ValueError(f"Expected packet waveform [P,1,T], got {tuple(rx.shape)}")
        product = rx[..., 1:] * torch.conj(rx[..., :-1])
        dphase = torch.atan2(product.imag, product.real)
        dphase = torch.cat([dphase[..., :1], dphase], dim=-1)
        demodulated = dphase * self.samples_per_symbol / (math.pi * self.modulation_index)
        demodulated = demodulated[..., : num_symbols * self.samples_per_symbol]
        symbol_estimate = F.avg_pool1d(
            demodulated, kernel_size=self.samples_per_symbol, stride=self.samples_per_symbol
        )
        equalizer = self.equalizer.to(dtype=symbol_estimate.dtype)
        return F.conv1d(
            symbol_estimate, equalizer, padding=equalizer.shape[-1] // 2
        )[..., :num_symbols]

    def forward(
        self,
        payload: torch.Tensor,
        esn0_db: Optional[Union[torch.Tensor, float]],
        return_aux: bool = False,
        framing_mode: str = "oracle",
        leading_idle_symbols: int = 0,
    ) -> Union[torch.Tensor, tuple[torch.Tensor, dict[str, Any]]]:
        if payload.ndim != 3:
            raise ValueError(f"Expected [B,F,K], got {tuple(payload.shape)}")
        if framing_mode not in {"oracle", "detected"}:
            raise ValueError("framing_mode must be 'oracle' or 'detected'")
        if framing_mode == "detected" and self.training:
            raise RuntimeError("detected framing is non-differentiable and evaluation-only")
        original_dtype = payload.dtype
        batch, frames, payload_symbols = payload.shape
        raw = payload.float()
        bounded = self.bound_payload(raw)
        framed = self.frame_payload(bounded)
        if leading_idle_symbols:
            idle = framed.new_full((batch, frames, int(leading_idle_symbols)), -self.payload_peak)
            framed = torch.cat([idle, framed], dim=-1)
        symbols_per_frame = framed.shape[-1]
        tx, phase_increment_max = self.modulate_packets(framed, return_phase_increment=True)
        rx = self.add_awgn(tx, esn0_db, batch, frames)
        recovered = self.demodulate_packets(rx, symbols_per_frame).reshape(batch, frames, symbols_per_frame)
        if framing_mode == "oracle":
            start = int(leading_idle_symbols) + self.header_symbols
            recovered_payload = recovered[..., start : start + payload_symbols]
            frame_success = torch.ones(batch, frames, dtype=torch.bool, device=payload.device)
            sync_errors = torch.zeros(batch, frames, dtype=torch.long, device=payload.device)
        else:
            result = self.symbol_framer.deframe(recovered, payload_symbols)
            recovered_payload = result.payload
            frame_success = result.success
            sync_errors = result.sync_errors
        recovered_payload = recovered_payload.to(dtype=original_dtype)
        if not return_aux:
            return recovered_payload
        aux: dict[str, Any] = {
            "raw_payload": raw,
            "bounded_payload": bounded,
            "tx_symbol_energy": tx.abs().square().sum() / (batch * frames * symbols_per_frame),
            "phase_increment_max": phase_increment_max,
            "phase_increment_limit": math.pi * self.modulation_index * self.payload_peak / self.samples_per_symbol,
            "frame_success": frame_success,
            "frame_success_rate": frame_success.float().mean(),
            "sync_errors": sync_errors,
            "framing_mode": framing_mode,
            "tx_waveform": tx,
        }
        return recovered_payload, aux
