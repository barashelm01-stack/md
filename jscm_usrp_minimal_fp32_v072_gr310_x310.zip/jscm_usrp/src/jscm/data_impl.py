from __future__ import annotations

import random
from pathlib import Path
from typing import TypedDict, Optional, Union

import numpy as np
import soundfile as sf
import torch
from scipy.signal import resample_poly
from torch.utils.data import Dataset

from .manifest import ManifestEntry, read_manifest


class SpeechSample(TypedDict):
    waveform: torch.Tensor
    valid_samples: torch.Tensor
    utterance_id: str
    start_sample: torch.Tensor


def find_librispeech_subset(root: Union[str, Path], subset: str) -> Path:
    """Resolve either ``<root>/<subset>`` or ``<root>/LibriSpeech/<subset>``."""
    root = Path(root).expanduser().resolve()
    candidates = [root / subset, root / "LibriSpeech" / subset]
    if root.name == subset:
        candidates.insert(0, root)
    for candidate in candidates:
        if candidate.is_dir():
            return candidate
    raise FileNotFoundError(
        f"Cannot find subset '{subset}' under {root}. Expected either "
        f"'{root / subset}' or '{root / 'LibriSpeech' / subset}'."
    )


def list_audio_files(folder: Path) -> list[Path]:
    files = sorted(folder.rglob("*.flac"))
    if not files:
        files = sorted(folder.rglob("*.wav"))
    if not files:
        raise FileNotFoundError(f"No FLAC/WAV files found under {folder}")
    return files


def load_mono(path: Path, target_sr: int = 16_000) -> np.ndarray:
    wav, sr = sf.read(path, dtype="float32", always_2d=True)
    wav = wav.mean(axis=1)
    if sr != target_sr:
        gcd = np.gcd(sr, target_sr)
        wav = resample_poly(wav, target_sr // gcd, sr // gcd).astype(np.float32)
    if not np.isfinite(wav).all():
        raise ValueError(f"Non-finite samples found in {path}")
    return wav.astype(np.float32, copy=False)


def crop_or_pad(wav: np.ndarray, start: int, num_samples: int) -> tuple[np.ndarray, int]:
    if start < 0:
        raise ValueError("start must be non-negative")
    chunk = wav[start : start + num_samples]
    valid_samples = int(chunk.shape[0])
    if valid_samples < num_samples:
        chunk = np.pad(chunk, (0, num_samples - valid_samples))
    return chunk.astype(np.float32, copy=False), valid_samples


def apply_random_gain(chunk: np.ndarray, random_gain_db: float, rng: Optional[random.Random] = None) -> np.ndarray:
    if random_gain_db <= 0:
        return chunk
    source = rng if rng is not None else random
    gain_db = source.uniform(-random_gain_db, random_gain_db)
    chunk = chunk * (10.0 ** (gain_db / 20.0))
    peak = float(np.max(np.abs(chunk))) if chunk.size else 0.0
    if peak > 0.99:
        chunk = chunk * (0.99 / peak)
    return chunk.astype(np.float32, copy=False)


class ManifestSpeechDataset(Dataset[SpeechSample]):
    """Dataset backed by a v0.3.1 JSONL manifest.

    Entries with an integer ``start_sample`` are deterministic and may be used
    for training, validation, or test. Legacy entries with ``start_sample=null``
    remain supported for random-crop training only.
    """

    def __init__(
        self,
        manifest_path: Union[str, Path],
        sample_rate: int = 16_000,
        seconds: float = 1.0,
        training: bool = False,
        crops_per_entry: int = 1,
        random_gain_db: float = 6.0,
        max_entries: Optional[int] = None,
        seed: int = 2026,
    ) -> None:
        super().__init__()
        self.entries = read_manifest(manifest_path)
        if max_entries is not None:
            if max_entries <= 0:
                raise ValueError("max_entries must be positive")
            self.entries = self.entries[:max_entries]
        self.sample_rate = int(sample_rate)
        self.num_samples = int(round(sample_rate * seconds))
        self.training = bool(training)
        self.crops_per_entry = max(1, int(crops_per_entry))
        self.random_gain_db = float(random_gain_db)
        self.seed = int(seed)
        self.epoch = 0
        fixed_flags = [entry.get("start_sample") is not None for entry in self.entries]
        self.has_fixed_entries = any(fixed_flags)
        self.has_random_entries = not all(fixed_flags)
        if self.training and self.has_fixed_entries and self.crops_per_entry != 1:
            raise ValueError(
                "Fixed training manifests require crops_per_entry=1 so the declared "
                "dataset size remains exact"
            )

        for index, entry in enumerate(self.entries):
            requested = int(entry.get("num_samples", self.num_samples))
            if requested != self.num_samples:
                raise ValueError(
                    f"Entry {index} requests {requested} samples, expected {self.num_samples}"
                )
            if not Path(entry["path"]).is_file():
                raise FileNotFoundError(f"Audio file in manifest does not exist: {entry['path']}")
            fixed = entry.get("start_sample") is not None
            if not self.training and not fixed:
                raise ValueError("Validation/test manifest entries require a fixed start_sample")

    def set_epoch(self, epoch: int) -> None:
        self.epoch = int(epoch)

    def _rng_for_index(self, index: int) -> random.Random:
        return random.Random(self.seed + 1_000_003 * self.epoch + int(index))

    def __len__(self) -> int:
        multiplier = self.crops_per_entry if self.training else 1
        return len(self.entries) * multiplier

    def __getitem__(self, index: int) -> SpeechSample:
        entry: ManifestEntry = self.entries[index % len(self.entries)]
        local_rng = self._rng_for_index(index)
        path = Path(entry["path"])
        wav = load_mono(path, self.sample_rate)
        raw_start = entry.get("start_sample")
        if raw_start is None:
            if not self.training:
                raise RuntimeError("Fixed dataset received a random-crop entry")
            max_start = max(0, wav.shape[0] - self.num_samples)
            start = local_rng.randint(0, max_start) if max_start > 0 else 0
        else:
            start = int(raw_start)

        chunk, actual_valid = crop_or_pad(wav, start, self.num_samples)
        if "valid_samples" in entry:
            declared_valid = int(entry["valid_samples"])
            if declared_valid != actual_valid:
                raise ValueError(
                    f"Manifest valid_samples mismatch for {path}: "
                    f"declared {declared_valid}, observed {actual_valid}"
                )
        if self.training:
            chunk = apply_random_gain(chunk, self.random_gain_db, local_rng)

        return {
            "waveform": torch.from_numpy(chunk).unsqueeze(0),
            "valid_samples": torch.tensor(actual_valid, dtype=torch.long),
            "utterance_id": str(entry["utterance_id"]),
            "start_sample": torch.tensor(start, dtype=torch.long),
        }


class LibriSpeechOneSecond(Dataset[SpeechSample]):
    """Backward-compatible direct LibriSpeech reader.

    Prefer :class:`ManifestSpeechDataset` for v0.3.1 experiments because fixed
    manifests guarantee identical validation/test segments between runs.
    """

    def __init__(
        self,
        root: Union[str, Path],
        subset: str,
        sample_rate: int = 16_000,
        seconds: float = 1.0,
        training: bool = False,
        crops_per_file: int = 1,
        max_segments: Optional[int] = None,
        random_gain_db: float = 6.0,
        seed: int = 2026,
    ) -> None:
        super().__init__()
        self.folder = find_librispeech_subset(root, subset)
        self.files = list_audio_files(self.folder)
        self.sample_rate = int(sample_rate)
        self.num_samples = int(round(sample_rate * seconds))
        self.training = bool(training)
        self.crops_per_file = max(1, int(crops_per_file))
        self.random_gain_db = float(random_gain_db)
        self.seed = int(seed)
        self.epoch = 0

        self.segments: list[tuple[Path, int]] = []
        if not self.training:
            for path in self.files:
                info = sf.info(path)
                if info.samplerate == self.sample_rate:
                    length = int(info.frames)
                else:
                    length = int(round(info.frames * self.sample_rate / info.samplerate))
                for start in range(0, max(length, 1), self.num_samples):
                    self.segments.append((path, start))
                    if max_segments is not None and len(self.segments) >= max_segments:
                        break
                if max_segments is not None and len(self.segments) >= max_segments:
                    break

    def set_epoch(self, epoch: int) -> None:
        self.epoch = int(epoch)

    def _rng_for_index(self, index: int) -> random.Random:
        return random.Random(self.seed + 1_000_003 * self.epoch + int(index))

    def __len__(self) -> int:
        if self.training:
            return len(self.files) * self.crops_per_file
        return len(self.segments)

    def __getitem__(self, index: int) -> SpeechSample:
        if self.training:
            local_rng = self._rng_for_index(index)
            path = self.files[index % len(self.files)]
            wav = load_mono(path, self.sample_rate)
            max_start = max(0, wav.shape[0] - self.num_samples)
            start = local_rng.randint(0, max_start) if max_start > 0 else 0
            chunk, valid_samples = crop_or_pad(wav, start, self.num_samples)
            chunk = apply_random_gain(chunk, self.random_gain_db, local_rng)
        else:
            path, start = self.segments[index]
            wav = load_mono(path, self.sample_rate)
            chunk, valid_samples = crop_or_pad(wav, start, self.num_samples)

        return {
            "waveform": torch.from_numpy(chunk).unsqueeze(0),
            "valid_samples": torch.tensor(valid_samples, dtype=torch.long),
            "utterance_id": path.stem,
            "start_sample": torch.tensor(start, dtype=torch.long),
        }
