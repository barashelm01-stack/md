from __future__ import annotations
from typing import Union

import math
from dataclasses import dataclass, field

import numpy as np

try:
    from pesq import pesq as _pesq
except Exception:  # Optional compiled dependency.
    _pesq = None

try:
    from pystoi import stoi as _stoi
except Exception:  # Optional dependency.
    _stoi = None


def _paired_waveforms(estimate: np.ndarray, target: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    estimate = np.asarray(estimate, dtype=np.float64).reshape(-1)
    target = np.asarray(target, dtype=np.float64).reshape(-1)
    if estimate.shape != target.shape:
        raise ValueError(f"Shape mismatch: {estimate.shape} vs {target.shape}")
    return estimate, target


def waveform_distance_np(estimate: np.ndarray, target: np.ndarray) -> float:
    """Mean absolute waveform distance over valid samples."""
    estimate, target = _paired_waveforms(estimate, target)
    if estimate.size == 0:
        return float("nan")
    return float(np.mean(np.abs(estimate - target)))


def segmental_snr_np(
    estimate: np.ndarray,
    target: np.ndarray,
    sample_rate: int = 16_000,
    frame_ms: float = 20.0,
    min_db: float = -10.0,
    max_db: float = 35.0,
    eps: float = 1e-12,
) -> float:
    """Segmental SNR using non-overlapping 20 ms frames.

    Silent reference frames are excluded. Each valid frame SNR is clipped to
    [min_db, max_db] before averaging, which is the conventional robust SegSNR
    definition used for speech quality evaluation.
    """
    estimate, target = _paired_waveforms(estimate, target)
    frame_length = int(round(sample_rate * frame_ms / 1000.0))
    if frame_length <= 0 or estimate.size < frame_length:
        return float("nan")
    frame_count = estimate.size // frame_length
    estimate = estimate[: frame_count * frame_length].reshape(frame_count, frame_length)
    target = target[: frame_count * frame_length].reshape(frame_count, frame_length)
    signal_energy = np.sum(target * target, axis=1)
    noise_energy = np.sum((target - estimate) ** 2, axis=1)
    active = signal_energy > eps
    if not np.any(active):
        return float("nan")
    frame_snr = 10.0 * np.log10((signal_energy[active] + eps) / (noise_energy[active] + eps))
    return float(np.mean(np.clip(frame_snr, min_db, max_db)))


def _frame_signal(x: np.ndarray, frame_length: int, hop_length: int) -> np.ndarray:
    if x.size < frame_length:
        x = np.pad(x, (0, frame_length - x.size))
    remainder = (x.size - frame_length) % hop_length
    if remainder:
        x = np.pad(x, (0, hop_length - remainder))
    count = 1 + (x.size - frame_length) // hop_length
    shape = (count, frame_length)
    strides = (x.strides[0] * hop_length, x.strides[0])
    return np.lib.stride_tricks.as_strided(x, shape=shape, strides=strides).copy()


def stft_distance_np(estimate: np.ndarray, target: np.ndarray, eps: float = 1e-7) -> float:
    """Three-resolution spectral-convergence plus log-magnitude distance."""
    estimate, target = _paired_waveforms(estimate, target)
    if estimate.size == 0:
        return float("nan")
    configs = ((256, 64), (512, 128), (1024, 256))
    distances: list[float] = []
    for n_fft, hop_length in configs:
        window = np.hanning(n_fft).astype(np.float64)
        est_frames = _frame_signal(estimate, n_fft, hop_length) * window[None, :]
        tgt_frames = _frame_signal(target, n_fft, hop_length) * window[None, :]
        est_mag = np.maximum(np.abs(np.fft.rfft(est_frames, n=n_fft, axis=1)), eps)
        tgt_mag = np.maximum(np.abs(np.fft.rfft(tgt_frames, n=n_fft, axis=1)), eps)
        spectral_convergence = np.linalg.norm(tgt_mag - est_mag) / (np.linalg.norm(tgt_mag) + eps)
        log_magnitude = np.mean(np.abs(np.log(est_mag) - np.log(tgt_mag)))
        distances.append(float(spectral_convergence + log_magnitude))
    return float(np.mean(distances))


def si_sdr_np(estimate: np.ndarray, target: np.ndarray, eps: float = 1e-12) -> float:
    estimate, target = _paired_waveforms(estimate, target)
    if estimate.size == 0:
        return float("nan")
    estimate = estimate - float(np.mean(estimate))
    target = target - float(np.mean(target))
    target_energy = float(np.dot(target, target))
    if target_energy <= eps:
        return float("nan")
    projection = np.dot(estimate, target) * target / (target_energy + eps)
    noise = estimate - projection
    ratio = (np.dot(projection, projection) + eps) / (np.dot(noise, noise) + eps)
    return float(10.0 * np.log10(ratio))


def pesq_wb_np(estimate: np.ndarray, target: np.ndarray, sample_rate: int = 16_000) -> float:
    if _pesq is None:
        return float("nan")
    if sample_rate != 16_000:
        raise ValueError("PESQ-WB requires 16 kHz audio")
    estimate = np.asarray(estimate, dtype=np.float32).reshape(-1)
    target = np.asarray(target, dtype=np.float32).reshape(-1)
    if estimate.shape != target.shape or estimate.size < sample_rate // 4:
        return float("nan")
    try:
        return float(_pesq(sample_rate, target, estimate, "wb"))
    except Exception:
        return float("nan")


def stoi_np(estimate: np.ndarray, target: np.ndarray, sample_rate: int = 16_000) -> float:
    if _stoi is None:
        return float("nan")
    estimate = np.asarray(estimate, dtype=np.float64).reshape(-1)
    target = np.asarray(target, dtype=np.float64).reshape(-1)
    if estimate.shape != target.shape or estimate.size < 256:
        return float("nan")
    try:
        return float(_stoi(target, estimate, sample_rate, extended=False))
    except Exception:
        return float("nan")


def waveform_rms(x: np.ndarray, eps: float = 1e-12) -> float:
    x = np.asarray(x, dtype=np.float64).reshape(-1)
    if x.size == 0:
        return float("nan")
    return float(math.sqrt(float(np.mean(x * x)) + eps))


def compute_objective_metrics(
    estimate: np.ndarray,
    target: np.ndarray,
    sample_rate: int = 16_000,
) -> dict[str, float]:
    estimate = np.asarray(estimate, dtype=np.float32).reshape(-1)
    target = np.asarray(target, dtype=np.float32).reshape(-1)
    if estimate.shape != target.shape:
        raise ValueError(f"Shape mismatch: {estimate.shape} vs {target.shape}")
    input_rms = waveform_rms(target)
    output_rms = waveform_rms(estimate)
    waveform_distance = waveform_distance_np(estimate, target)
    segsnr_value = segmental_snr_np(estimate, target, sample_rate)
    pesq_value = pesq_wb_np(estimate, target, sample_rate)
    sisdr_value = si_sdr_np(estimate, target)
    stft_value = stft_distance_np(estimate, target)
    stoi_value = stoi_np(estimate, target, sample_rate)
    return {
        "waveform_distance": waveform_distance,
        "waveform_distance_valid": float(math.isfinite(waveform_distance)),
        "segsnr_db": segsnr_value,
        "segsnr_valid": float(math.isfinite(segsnr_value)),
        "pesq_wb": pesq_value,
        "pesq_wb_valid": float(math.isfinite(pesq_value)),
        "si_sdr_db": sisdr_value,
        "si_sdr_valid": float(math.isfinite(sisdr_value)),
        "stft_distance": stft_value,
        "stft_distance_valid": float(math.isfinite(stft_value)),
        "stoi": stoi_value,
        "stoi_valid": float(math.isfinite(stoi_value)),
        "input_rms": input_rms,
        "output_rms": output_rms,
        "output_input_rms_ratio": output_rms / max(input_rms, 1e-8),
    }


@dataclass
class MetricAccumulator:
    sums: dict[str, float] = field(default_factory=dict)
    counts: dict[str, int] = field(default_factory=dict)
    seen_keys: set[str] = field(default_factory=set)

    def update(self, metrics: dict[str, float]) -> None:
        for key, value in metrics.items():
            self.seen_keys.add(key)
            value = float(value)
            if not math.isfinite(value):
                continue
            self.sums[key] = self.sums.get(key, 0.0) + value
            self.counts[key] = self.counts.get(key, 0) + 1

    def mean(self) -> dict[str, Union[float, int]]:
        result: dict[str, Union[float, int]] = {}
        for key in sorted(self.seen_keys):
            count = self.counts.get(key, 0)
            result[key] = self.sums.get(key, 0.0) / count if count else float("nan")
            result[f"{key}_count"] = count
        return result


def dependency_status() -> dict[str, bool]:
    return {"pesq": _pesq is not None, "pystoi": _stoi is not None}
