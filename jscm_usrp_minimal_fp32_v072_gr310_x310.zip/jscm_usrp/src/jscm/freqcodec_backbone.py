from __future__ import annotations

import math
from typing import Any
import torch
import torch.nn as nn
import torch.nn.functional as F


class CausalFFTAnalysis(nn.Module):
    """20-ms causal block FFT: each frame uses past context plus the current hop."""

    def __init__(self, fft_size: int = 512, hop_size: int = 320) -> None:
        super().__init__()
        if fft_size < hop_size:
            raise ValueError("fft_size must be >= hop_size")
        self.fft_size = int(fft_size)
        self.hop_size = int(hop_size)
        self.left_context = self.fft_size - self.hop_size
        self.freq_bins = self.fft_size // 2 + 1

    def forward(self, waveform: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        if waveform.ndim != 3 or waveform.shape[1] != 1:
            raise ValueError(f"Expected [B,1,T], got {tuple(waveform.shape)}")
        padded = F.pad(waveform, (self.left_context, 0))
        frames = padded.unfold(-1, self.fft_size, self.hop_size).squeeze(1)
        spectrum = torch.fft.rfft(frames, n=self.fft_size, dim=-1)
        magnitude = spectrum.abs().clamp_min(1e-7)
        phase = torch.angle(spectrum)
        features = torch.stack((torch.log1p(magnitude), torch.cos(phase), torch.sin(phase)), dim=1)
        features = features.permute(0, 1, 3, 2).contiguous()  # [B,3,F,T]
        return features, spectrum

    def stream_analyze(self, frame: torch.Tensor, context: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        if frame.ndim != 3 or frame.shape[1] != 1 or frame.shape[-1] != self.hop_size:
            raise ValueError(f"Expected frame [B,1,{self.hop_size}], got {tuple(frame.shape)}")
        if context.shape != (frame.shape[0], 1, self.left_context):
            raise ValueError(f"Expected context {(frame.shape[0],1,self.left_context)}, got {tuple(context.shape)}")
        block = torch.cat([context, frame], dim=-1)
        spectrum = torch.fft.rfft(block.squeeze(1), n=self.fft_size, dim=-1)
        magnitude = spectrum.abs().clamp_min(1e-7)
        phase = torch.angle(spectrum)
        features = torch.stack((torch.log1p(magnitude), torch.cos(phase), torch.sin(phase)), dim=1)
        features = features.unsqueeze(-1)  # [B,3,F,1]
        new_context = block[..., -self.left_context:].detach()
        return features, new_context

    def synthesize_frame(self, spectrum: torch.Tensor) -> torch.Tensor:
        if spectrum.ndim == 3 and spectrum.shape[1] == 1:
            spectrum = spectrum[:, 0]
        if spectrum.ndim != 2 or not torch.is_complex(spectrum):
            raise ValueError("Expected complex spectrum [B,F] or [B,1,F]")
        block = torch.fft.irfft(spectrum, n=self.fft_size, dim=-1)
        return block[..., -self.hop_size:].unsqueeze(1)

    def synthesize(self, spectrum: torch.Tensor, length: int) -> torch.Tensor:
        if not torch.is_complex(spectrum):
            raise ValueError("spectrum must be complex")
        blocks = torch.fft.irfft(spectrum, n=self.fft_size, dim=-1)
        hops = blocks[..., -self.hop_size:]
        waveform = hops.reshape(hops.shape[0], 1, -1)
        return waveform[..., :length]


class FrequencyResidualBlock(nn.Module):
    def __init__(self, channels: int, dilation: int = 1) -> None:
        super().__init__()
        self.norm = nn.GroupNorm(1, channels)
        self.depthwise = nn.Conv1d(
            channels, channels, kernel_size=5, padding=2 * dilation,
            dilation=dilation, groups=channels
        )
        self.pointwise = nn.Sequential(
            nn.Conv1d(channels, channels * 2, 1),
            nn.GLU(dim=1),
            nn.Conv1d(channels, channels, 1),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x + self.pointwise(F.silu(self.depthwise(self.norm(x))))


class FrequencyEncoder(nn.Module):
    """FreqCodec-style magnitude/phase encoder operating independently per 20-ms frame."""

    def __init__(self, model_dim: int, base_channels: int = 32) -> None:
        super().__init__()
        channels = [3, base_channels, base_channels * 2, base_channels * 3, base_channels * 3]
        stages: list[nn.Module] = []
        for index in range(4):
            stages += [
                nn.Conv1d(channels[index], channels[index + 1], 5, stride=2, padding=2),
                nn.GroupNorm(1, channels[index + 1]),
                nn.SiLU(),
                FrequencyResidualBlock(channels[index + 1], dilation=1),
                FrequencyResidualBlock(channels[index + 1], dilation=2),
            ]
        self.network = nn.Sequential(*stages)
        self.projection = nn.Linear(channels[-1] * 17, model_dim)

    def forward(self, features: torch.Tensor) -> torch.Tensor:
        # [B,3,F,T] -> [B*T,3,F]
        batch, _, _, frames = features.shape
        x = features.permute(0, 3, 1, 2).reshape(batch * frames, 3, -1)
        x = self.network(x)
        if x.shape[-1] != 17:
            x = F.adaptive_avg_pool1d(x, 17)
        x = self.projection(x.flatten(1))
        return x.reshape(batch, frames, -1)


class CausalTemporalBlock(nn.Module):
    def __init__(self, channels: int, expansion: int = 2, dilation: int = 1) -> None:
        super().__init__()
        self.norm = nn.LayerNorm(channels)
        self.depthwise = nn.Conv1d(
            channels, channels, kernel_size=5, dilation=dilation,
            groups=channels, padding=0
        )
        self.left_pad = 4 * dilation
        self.ffn = nn.Sequential(
            nn.Linear(channels, channels * expansion * 2),
            nn.GLU(dim=-1),
            nn.SiLU(),
            nn.Linear(channels * expansion, channels),
        )
        self.scale = nn.Parameter(torch.full((channels,), 1e-2))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = x
        y = self.norm(x).transpose(1, 2)
        y = self.depthwise(F.pad(y, (self.left_pad, 0))).transpose(1, 2)
        y = self.ffn(y)
        return residual + y * self.scale

    def init_stream_state(self, batch_size: int, device: torch.device, dtype: torch.dtype) -> torch.Tensor:
        return torch.zeros(batch_size, self.left_pad, self.norm.normalized_shape[0], device=device, dtype=dtype)

    def stream_step(self, x: torch.Tensor, state: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        if x.ndim != 3 or x.shape[1] != 1:
            raise ValueError(f"Expected [B,1,C], got {tuple(x.shape)}")
        normalized = self.norm(x)
        history = torch.cat([state, normalized], dim=1)
        y = self.depthwise(history.transpose(1, 2)).transpose(1, 2)
        y = self.ffn(y)
        output = x + y * self.scale
        new_state = history[:, -self.left_pad:].detach()
        return output, new_state


class TemporalConvGRU(nn.Module):
    """Causal convolution + GRU sequence model; avoids a plain Transformer bottleneck."""

    def __init__(self, model_dim: int, num_layers: int) -> None:
        super().__init__()
        self.blocks = nn.ModuleList([
            CausalTemporalBlock(model_dim, dilation=2 ** (i % 4)) for i in range(max(num_layers, 1))
        ])
        self.gru = nn.GRU(model_dim, model_dim, num_layers=1, batch_first=True)
        self.norm = nn.LayerNorm(model_dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        for block in self.blocks:
            x = block(x)
        recurrent, _ = self.gru(x)
        return self.norm(x + recurrent)

    def init_stream_state(self, batch_size: int, device: torch.device, dtype: torch.dtype) -> dict[str, Any]:
        return {
            "conv": [block.init_stream_state(batch_size, device, dtype) for block in self.blocks],
            "gru": torch.zeros(1, batch_size, self.gru.hidden_size, device=device, dtype=dtype),
        }

    def stream_step(self, x: torch.Tensor, state: dict[str, Any]) -> tuple[torch.Tensor, dict[str, Any]]:
        new_conv = []
        for block, block_state in zip(self.blocks, state["conv"]):
            x, block_state = block.stream_step(x, block_state)
            new_conv.append(block_state)
        recurrent, hidden = self.gru(x, state["gru"])
        return self.norm(x + recurrent), {"conv": new_conv, "gru": hidden.detach()}


class FrequencyDecoder(nn.Module):
    def __init__(self, model_dim: int, base_channels: int = 32, freq_bins: int = 257) -> None:
        super().__init__()
        hidden = base_channels * 3
        self.freq_bins = int(freq_bins)
        self.seed = nn.Linear(model_dim, hidden * 17)
        channels = [hidden, hidden, base_channels * 2, base_channels, base_channels]
        stages: list[nn.Module] = []
        for index in range(4):
            stages += [
                FrequencyResidualBlock(channels[index], dilation=2),
                nn.ConvTranspose1d(
                    channels[index], channels[index + 1], kernel_size=4,
                    stride=2, padding=1
                ),
                nn.GroupNorm(1, channels[index + 1]),
                nn.SiLU(),
            ]
        self.network = nn.Sequential(*stages)
        self.head = nn.Conv1d(channels[-1], 3, 3, padding=1)

    def forward(self, tokens: torch.Tensor) -> torch.Tensor:
        batch, frames, _ = tokens.shape
        x = self.seed(tokens).reshape(batch * frames, -1, 17)
        x = self.network(x)
        x = F.interpolate(x, size=self.freq_bins, mode="linear", align_corners=False)
        outputs = self.head(x).reshape(batch, frames, 3, self.freq_bins)
        log_magnitude = outputs[:, :, 0].clamp(-8.0, 8.0)
        magnitude = torch.expm1(F.softplus(log_magnitude)).clamp_min(1e-7)
        phase_pair = F.normalize(outputs[:, :, 1:3], dim=2, eps=1e-6)
        real = magnitude * phase_pair[:, :, 0]
        imag = magnitude * phase_pair[:, :, 1]
        return torch.complex(real, imag)


class FreqCodecBackbone(nn.Module):
    """Editable PyTorch frequency-domain codec backbone inspired by FunCodec/FreqCodec."""

    def __init__(
        self,
        sample_rate: int = 16_000,
        frame_ms: int = 20,
        model_dim: int = 96,
        encoder_layers: int = 2,
        decoder_layers: int = 3,
        use_sequence_model: bool = True,
        fft_size: int = 512,
    ) -> None:
        super().__init__()
        hop = sample_rate * frame_ms // 1000
        self.analysis = CausalFFTAnalysis(fft_size=fft_size, hop_size=hop)
        self.encoder = FrequencyEncoder(model_dim)
        self.tx_sequence = TemporalConvGRU(model_dim, encoder_layers) if use_sequence_model else nn.Identity()
        self.rx_sequence = TemporalConvGRU(model_dim, decoder_layers) if use_sequence_model else nn.Identity()
        self.decoder = FrequencyDecoder(model_dim, freq_bins=self.analysis.freq_bins)
        self.model_dim = int(model_dim)

    def encode(self, waveform: torch.Tensor) -> torch.Tensor:
        features, _ = self.analysis(waveform)
        return self.tx_sequence(self.encoder(features))

    def decode(self, tokens: torch.Tensor, length: int) -> torch.Tensor:
        spectrum = self.decoder(self.rx_sequence(tokens))
        waveform = self.analysis.synthesize(spectrum, length)
        return torch.tanh(waveform)

    def init_stream_state(self, batch_size: int, device: torch.device, dtype: torch.dtype) -> dict[str, Any]:
        tx_state = self.tx_sequence.init_stream_state(batch_size, device, dtype) if isinstance(self.tx_sequence, TemporalConvGRU) else None
        rx_state = self.rx_sequence.init_stream_state(batch_size, device, dtype) if isinstance(self.rx_sequence, TemporalConvGRU) else None
        return {
            "analysis_context": torch.zeros(batch_size, 1, self.analysis.left_context, device=device, dtype=dtype),
            "tx": tx_state,
            "rx": rx_state,
        }

    def stream_encode(self, frame: torch.Tensor, state: dict[str, Any]) -> tuple[torch.Tensor, dict[str, Any]]:
        features, context = self.analysis.stream_analyze(frame, state["analysis_context"])
        token = self.encoder(features)
        tx_state = state["tx"]
        if isinstance(self.tx_sequence, TemporalConvGRU):
            token, tx_state = self.tx_sequence.stream_step(token, tx_state)
        return token, {**state, "analysis_context": context, "tx": tx_state}

    def stream_decode(self, token: torch.Tensor, state: dict[str, Any]) -> tuple[torch.Tensor, dict[str, Any]]:
        rx_state = state["rx"]
        if isinstance(self.rx_sequence, TemporalConvGRU):
            token, rx_state = self.rx_sequence.stream_step(token, rx_state)
        spectrum = self.decoder(token)
        frame = torch.tanh(self.analysis.synthesize_frame(spectrum))
        return frame, {**state, "rx": rx_state}
