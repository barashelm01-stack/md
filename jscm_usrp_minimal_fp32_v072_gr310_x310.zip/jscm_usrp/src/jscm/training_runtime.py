"""FP32 training helpers."""
from __future__ import annotations


def accumulation_group_size(step: int, total_steps: int, accumulation_steps: int) -> int:
    if accumulation_steps < 1:
        raise ValueError("accumulation_steps must be >= 1")
    group_start = (step // accumulation_steps) * accumulation_steps
    return min(accumulation_steps, total_steps - group_start)


def is_optimizer_step(step: int, total_steps: int, accumulation_steps: int) -> bool:
    return ((step + 1) % accumulation_steps == 0) or (step + 1 == total_steps)
