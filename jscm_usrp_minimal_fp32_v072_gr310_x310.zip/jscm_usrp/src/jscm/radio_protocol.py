from __future__ import annotations

import enum
import json
import struct
from dataclasses import dataclass
from typing import Any, Optional

import numpy as np

MAGIC = b"JSCM"
VERSION = 1
_HEADER = struct.Struct("<4sBBHIIQ")


class RadioMode(enum.IntEnum):
    JSCM_CONTINUOUS = 0
    SSCC_BITS = 1
    OPUS_BYTES = 2


@dataclass(frozen=True)
class RadioPacket:
    mode: RadioMode
    sequence_id: int
    payload: np.ndarray
    sample_rate: int = 0
    timestamp_ns: int = 0
    metadata: Optional[dict[str, Any]] = None

    def normalized_payload(self) -> np.ndarray:
        if self.mode == RadioMode.JSCM_CONTINUOUS:
            return np.ascontiguousarray(self.payload, dtype=np.float32).reshape(-1)
        return np.ascontiguousarray(self.payload, dtype=np.uint8).reshape(-1)


def serialize_packet(packet: RadioPacket) -> bytes:
    payload = packet.normalized_payload()
    metadata = json.dumps(packet.metadata or {}, separators=(",", ":")).encode("utf-8")
    if len(metadata) > 65535:
        raise ValueError("metadata is too large")
    header = _HEADER.pack(
        MAGIC, VERSION, int(packet.mode), len(metadata), payload.size,
        int(packet.sequence_id), int(packet.timestamp_ns),
    )
    sample_rate = struct.pack("<I", int(packet.sample_rate))
    return header + sample_rate + metadata + payload.tobytes(order="C")


def deserialize_packet(data: bytes) -> RadioPacket:
    minimum = _HEADER.size + 4
    if len(data) < minimum:
        raise ValueError("packet is truncated")
    magic, version, mode_value, metadata_len, payload_count, sequence_id, timestamp_ns = _HEADER.unpack_from(data)
    if magic != MAGIC:
        raise ValueError("invalid radio packet magic")
    if version != VERSION:
        raise ValueError(f"unsupported radio packet version {version}")
    sample_rate = struct.unpack_from("<I", data, _HEADER.size)[0]
    offset = minimum
    metadata_end = offset + metadata_len
    if metadata_end > len(data):
        raise ValueError("metadata is truncated")
    metadata = json.loads(data[offset:metadata_end].decode("utf-8")) if metadata_len else {}
    mode = RadioMode(mode_value)
    dtype = np.float32 if mode == RadioMode.JSCM_CONTINUOUS else np.uint8
    expected_bytes = int(payload_count) * np.dtype(dtype).itemsize
    if len(data) - metadata_end != expected_bytes:
        raise ValueError("payload byte count does not match header")
    payload = np.frombuffer(data, dtype=dtype, offset=metadata_end, count=payload_count).copy()
    return RadioPacket(mode, sequence_id, payload, sample_rate, timestamp_ns, metadata)
