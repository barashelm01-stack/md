from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from .radio_protocol import RadioPacket, deserialize_packet, serialize_packet


def _zmq():
    try:
        import zmq
    except ImportError as exc:
        raise RuntimeError("ZeroMQ support requires: pip install pyzmq") from exc
    return zmq


@dataclass
class PacketSender:
    endpoint: str
    bind: bool = False
    high_water_mark: int = 100

    def __post_init__(self) -> None:
        zmq = _zmq()
        self._context = zmq.Context.instance()
        self._socket = self._context.socket(zmq.PUSH)
        self._socket.setsockopt(zmq.SNDHWM, int(self.high_water_mark))
        (self._socket.bind if self.bind else self._socket.connect)(self.endpoint)

    def send(self, packet: RadioPacket) -> None:
        self._socket.send(serialize_packet(packet), copy=False)

    def close(self) -> None:
        self._socket.close(linger=0)


@dataclass
class PacketReceiver:
    endpoint: str
    bind: bool = True
    high_water_mark: int = 100

    def __post_init__(self) -> None:
        zmq = _zmq()
        self._context = zmq.Context.instance()
        self._socket = self._context.socket(zmq.PULL)
        self._socket.setsockopt(zmq.RCVHWM, int(self.high_water_mark))
        (self._socket.bind if self.bind else self._socket.connect)(self.endpoint)

    def recv(self) -> RadioPacket:
        return deserialize_packet(self._socket.recv())

    def recv_nonblocking(self) -> Optional[RadioPacket]:
        zmq = _zmq()
        try:
            data = self._socket.recv(flags=zmq.NOBLOCK)
        except zmq.Again:
            return None
        return deserialize_packet(data)

    def close(self) -> None:
        self._socket.close(linger=0)
