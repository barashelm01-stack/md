"""Fit and use a measured TX-gain-to-SNR calibration curve."""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Iterable

import numpy as np


@dataclass(frozen=True)
class GainCalibration:
    slope_db_per_gain_db: float
    intercept_db: float
    r_squared: float
    min_gain_db: float
    max_gain_db: float
    points_used: int

    def predict_snr_db(self, tx_gain_db: float) -> float:
        return self.slope_db_per_gain_db * float(tx_gain_db) + self.intercept_db

    def gain_for_target_snr_db(self, target_snr_db: float) -> float:
        if abs(self.slope_db_per_gain_db) < 1e-12:
            raise ValueError("calibration slope is zero")
        gain = (float(target_snr_db) - self.intercept_db) / self.slope_db_per_gain_db
        return float(np.clip(gain, self.min_gain_db, self.max_gain_db))

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def fit_gain_calibration(
    tx_gain_db: Iterable[float],
    measured_snr_db: Iterable[float],
) -> GainCalibration:
    gains = np.asarray(list(tx_gain_db), dtype=np.float64)
    snrs = np.asarray(list(measured_snr_db), dtype=np.float64)
    if gains.shape != snrs.shape or gains.ndim != 1:
        raise ValueError("tx_gain_db and measured_snr_db must be equal-length vectors")
    mask = np.isfinite(gains) & np.isfinite(snrs)
    gains = gains[mask]
    snrs = snrs[mask]
    if gains.size < 2:
        raise ValueError("at least two finite calibration points are required")
    if np.unique(gains).size < 2:
        raise ValueError("calibration requires at least two distinct gain values")

    slope, intercept = np.polyfit(gains, snrs, deg=1)
    predicted = slope * gains + intercept
    residual = float(np.sum((snrs - predicted) ** 2))
    total = float(np.sum((snrs - np.mean(snrs)) ** 2))
    r_squared = 1.0 if total <= 1e-15 else 1.0 - residual / total
    return GainCalibration(
        slope_db_per_gain_db=float(slope),
        intercept_db=float(intercept),
        r_squared=float(r_squared),
        min_gain_db=float(np.min(gains)),
        max_gain_db=float(np.max(gains)),
        points_used=int(gains.size),
    )
