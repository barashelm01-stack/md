"""Receiver-side SNR and Es/N0 estimators for the two-USRP prototype.

All powers are computed in the linear domain.  A USRP gain setting is never
interpreted as an SNR value; the effective link quality is estimated from the
captured samples for every run.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

import numpy as np


@dataclass(frozen=True)
class SampleSnrEstimate:
    total_power: float
    noise_power: float
    signal_power: float
    snr_linear: float
    snr_db: float
    valid: bool
    signal_samples: int
    noise_samples: int

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class SymbolEsN0Estimate:
    channel_gain_real: float
    channel_gain_imag: float
    signal_energy: float
    error_energy: float
    esn0_linear: float
    esn0_db: float
    evm_rms: float
    valid: bool
    symbol_count: int

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _as_complex_vector(values: np.ndarray, name: str) -> np.ndarray:
    array = np.asarray(values)
    if array.ndim != 1:
        array = array.reshape(-1)
    if array.size == 0:
        raise ValueError(f"{name} must contain at least one sample")
    if not np.all(np.isfinite(array)):
        raise ValueError(f"{name} contains NaN or Inf")
    return array.astype(np.complex128, copy=False)


def estimate_sample_snr(
    signal_plus_noise: np.ndarray,
    noise_only: np.ndarray,
    *,
    eps: float = 1e-15,
) -> SampleSnrEstimate:
    """Estimate sample-domain SNR from an active region and a silent region.

    ``signal_plus_noise`` contains the received waveform while the transmitter
    is active. ``noise_only`` must be captured with the same RX gain, RF
    bandwidth and sample rate while no wanted waveform is present.
    """
    if eps <= 0.0:
        raise ValueError("eps must be positive")
    active = _as_complex_vector(signal_plus_noise, "signal_plus_noise")
    quiet = _as_complex_vector(noise_only, "noise_only")

    total_power = float(np.mean(np.abs(active) ** 2, dtype=np.float64))
    noise_power = float(np.mean(np.abs(quiet) ** 2, dtype=np.float64))
    raw_signal_power = total_power - noise_power
    valid = bool(noise_power > eps and raw_signal_power > eps)
    signal_power = max(raw_signal_power, eps)
    safe_noise = max(noise_power, eps)
    snr_linear = signal_power / safe_noise
    snr_db = float(10.0 * np.log10(snr_linear))

    return SampleSnrEstimate(
        total_power=total_power,
        noise_power=noise_power,
        signal_power=signal_power,
        snr_linear=float(snr_linear),
        snr_db=snr_db,
        valid=valid,
        signal_samples=int(active.size),
        noise_samples=int(quiet.size),
    )


def estimate_symbol_esn0(
    reference_symbols: np.ndarray,
    received_symbols: np.ndarray,
    *,
    remove_dc: bool = True,
    eps: float = 1e-15,
) -> SymbolEsN0Estimate:
    """Estimate Es/N0 from known training symbols after matched filtering.

    A single complex least-squares channel coefficient is estimated as
    ``h = <x,y>/<x,x>``. Residual timing, CFO, RF distortion and noise that are
    not represented by that scalar coefficient contribute to the error term.
    This makes the estimate appropriate for comparing simulation and OTA runs.
    """
    if eps <= 0.0:
        raise ValueError("eps must be positive")
    x = _as_complex_vector(reference_symbols, "reference_symbols")
    y = _as_complex_vector(received_symbols, "received_symbols")
    if x.size != y.size:
        raise ValueError(f"reference and received lengths differ: {x.size} != {y.size}")

    if remove_dc:
        y = y - np.mean(y)
        # Preserve the intentional mean of the reference sequence only when it
        # is non-zero. Balanced training sequences normally have zero mean.
        x_mean = np.mean(x)
        if abs(x_mean) < 1e-12:
            x = x - x_mean

    denominator = np.vdot(x, x)
    if abs(denominator) <= eps:
        raise ValueError("reference_symbols have zero energy")
    h = np.vdot(x, y) / denominator
    fitted = h * x
    error = y - fitted

    signal_energy = float(np.mean(np.abs(fitted) ** 2, dtype=np.float64))
    error_energy = float(np.mean(np.abs(error) ** 2, dtype=np.float64))
    valid = bool(signal_energy > eps and error_energy > eps)
    safe_signal = max(signal_energy, eps)
    safe_error = max(error_energy, eps)
    esn0_linear = safe_signal / safe_error
    esn0_db = float(10.0 * np.log10(esn0_linear))
    evm_rms = float(np.sqrt(safe_error / safe_signal))

    return SymbolEsN0Estimate(
        channel_gain_real=float(np.real(h)),
        channel_gain_imag=float(np.imag(h)),
        signal_energy=signal_energy,
        error_energy=error_energy,
        esn0_linear=float(esn0_linear),
        esn0_db=esn0_db,
        evm_rms=evm_rms,
        valid=valid,
        symbol_count=int(x.size),
    )


def dbfs(power: float, *, eps: float = 1e-15) -> float:
    """Convert normalized complex-sample power to dBFS."""
    return float(10.0 * np.log10(max(float(power), eps)))
