from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

import numpy as np
import torch

from jscm.calibration import estimate_sample_snr, estimate_symbol_esn0
from jscm.models import JSCMSystem
from jscm.radio_protocol import RadioMode, RadioPacket, serialize_packet, deserialize_packet
from jscm.training_runtime import accumulation_group_size, is_optimizer_step


class CoreTests(unittest.TestCase):
    def test_jscm_shape(self) -> None:
        model = JSCMSystem(model_dim=32, encoder_layers=1, decoder_layers=1)
        x = torch.randn(1, 1, 16000)
        with torch.no_grad():
            y = model(x, 10.0, channel_mode="bypass")
        self.assertEqual(tuple(y.shape), (1, 1, 16000))

    def test_radio_packet_roundtrip(self) -> None:
        payload = np.linspace(-1, 1, 120, dtype=np.float32)
        packet = RadioPacket(RadioMode.JSCM_CONTINUOUS, 7, payload)
        restored = deserialize_packet(serialize_packet(packet))
        np.testing.assert_allclose(restored.payload, payload)

    def test_snr_estimators(self) -> None:
        rng = np.random.default_rng(3)
        noise = (rng.normal(size=200000) + 1j * rng.normal(size=200000)) * np.sqrt(0.01 / 2)
        signal = np.ones(200000, dtype=np.complex128)
        estimate = estimate_sample_snr(signal + noise, noise)
        self.assertAlmostEqual(estimate.snr_db, 20.0, delta=0.25)

        x = np.where(np.arange(10000) % 2 == 0, 1.0, -1.0).astype(np.complex128)
        n = (rng.normal(size=x.size) + 1j * rng.normal(size=x.size)) * np.sqrt(0.1 / 2)
        y = (0.8 + 0.3j) * x + n
        esn0 = estimate_symbol_esn0(x, y)
        self.assertTrue(np.isfinite(esn0.esn0_db))

    def test_accumulation_helpers(self) -> None:
        self.assertEqual(accumulation_group_size(4, 5, 2), 1)
        self.assertTrue(is_optimizer_step(4, 5, 2))


if __name__ == "__main__":
    unittest.main()
