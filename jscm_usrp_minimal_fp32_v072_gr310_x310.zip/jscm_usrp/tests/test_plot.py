from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from apps.evaluation.plot_metric_curves import METRICS, plot_metric_curves


class PlotTest(unittest.TestCase):
    def test_dashboard(self) -> None:
        rows = []
        for method in ("jscm_fm", "opus_gfsk"):
            for snr in (0.0, 5.0, 10.0):
                row = {"method": method, "esn0_db": snr}
                for i, metric in enumerate(METRICS):
                    row[metric] = snr + i
                rows.append(row)
        gain_rows = [
            {"tx_gain_db": 0.0, "sample_snr_db": 1.0, "symbol_esn0_db": 0.5},
            {"tx_gain_db": 5.0, "sample_snr_db": 6.0, "symbol_esn0_db": 5.5},
        ]
        with tempfile.TemporaryDirectory() as directory:
            paths = plot_metric_curves(rows, directory, gain_snr_rows=gain_rows)
            self.assertEqual(len(paths), len(METRICS) + 1)
            self.assertTrue((Path(directory) / "kpi_vs_snr_dashboard.png").is_file())


if __name__ == "__main__":
    unittest.main()
