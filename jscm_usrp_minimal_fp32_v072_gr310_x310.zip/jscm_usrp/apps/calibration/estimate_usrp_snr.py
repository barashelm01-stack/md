#!/usr/bin/env python3
"""Estimate OTA SNR/EsN0 from recorded NumPy arrays."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from jscm.calibration import dbfs, estimate_sample_snr, estimate_symbol_esn0


def _load(path: str) -> np.ndarray:
    value = np.load(path)
    return np.asarray(value).reshape(-1)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--active-iq", required=True, help=".npy IQ samples from training/active region")
    parser.add_argument("--noise-iq", required=True, help=".npy IQ samples from silent region")
    parser.add_argument("--reference-symbols", help="optional known matched-filter training symbols (.npy)")
    parser.add_argument("--received-symbols", help="optional matched-filter received training symbols (.npy)")
    parser.add_argument("--tx-gain-db", type=float)
    parser.add_argument("--clipping-threshold", type=float, default=0.95)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    active_iq = _load(args.active_iq)
    noise_iq = _load(args.noise_iq)
    sample = estimate_sample_snr(active_iq, noise_iq)
    result = {
        "tx_gain_db": args.tx_gain_db,
        "sample_snr": sample.to_dict(),
        "total_power_dbfs": dbfs(sample.total_power),
        "noise_power_dbfs": dbfs(sample.noise_power),
        "signal_power_dbfs": dbfs(sample.signal_power),
        "clipping_threshold": args.clipping_threshold,
        "clipping_rate": float(np.mean(np.abs(active_iq) >= args.clipping_threshold)),
    }
    if bool(args.reference_symbols) != bool(args.received_symbols):
        parser.error("--reference-symbols and --received-symbols must be supplied together")
    if args.reference_symbols:
        result["symbol_esn0"] = estimate_symbol_esn0(
            _load(args.reference_symbols), _load(args.received_symbols)
        ).to_dict()

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
