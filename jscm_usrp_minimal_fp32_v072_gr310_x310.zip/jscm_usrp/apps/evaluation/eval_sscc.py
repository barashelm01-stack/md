from __future__ import annotations
from pathlib import Path
import sys
_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(_ROOT / "src"))

from pathlib import Path
from typing import Any, Optional

import numpy as np
import soundfile as sf
import torch
from torch.utils.data import DataLoader

from jscm.sscc import SSCCSystem
from jscm.objective_metrics import MetricAccumulator, compute_objective_metrics


def build_sscc_from_checkpoint(checkpoint: dict[str, Any], device: torch.device) -> SSCCSystem:
    config = checkpoint.get("args", {})
    model = SSCCSystem(
        reference_bitrate=int(config.get("reference_bitrate", 6000)),
        quantizer_bits=int(config.get("quantizer_bits", 6)),
        model_dim=int(config.get("model_dim", 64)),
        ff_dim=int(config.get("ff_dim", 128)),
        num_heads=int(config.get("num_heads", 4)),
        encoder_layers=int(config.get("encoder_layers", 2)),
        decoder_layers=int(config.get("decoder_layers", 2)),
        use_transformer=not bool(config.get("disable_transformer", False)),
    )
    model.load_state_dict(checkpoint["model"])
    return model.to(device).eval()


def evaluate_sscc(
    model: SSCCSystem,
    loader: DataLoader,
    output_dir: Path,
    esn0_db: Optional[float],
    samples_per_symbol: int,
    seed: int,
    save_examples: int,
    framing_mode: str = "detected",
    max_sync_errors: int = 0,
    leading_idle_bits: int = 0,
) -> dict[str, Any]:
    objective = MetricAccumulator()
    rng = np.random.default_rng(seed)
    total_errors = 0.0
    total_bits = 0.0
    energies: list[float] = []
    frame_failures = 0.0
    channel_frames = 0.0
    segment_count = 0
    saved = 0
    device = next(model.parameters()).device
    with torch.no_grad():
        for batch in loader:
            clean = batch["waveform"].to(device)
            valid = batch["valid_samples"].cpu().numpy()
            if esn0_db is None:
                estimate = model(clean)
                channel_stats = None
            else:
                estimate, channel_stats = model.transmit_gfsk(
                    clean,
                    float(esn0_db),
                    rng,
                    samples_per_symbol=samples_per_symbol,
                    framing_mode=framing_mode,
                    max_sync_errors=max_sync_errors,
                    leading_idle_bits=leading_idle_bits,
                )
                total_errors += channel_stats["bit_errors"]
                total_bits += channel_stats["total_bits"]
                energies.append(channel_stats["tx_symbol_energy"])
                frame_failures += channel_stats.get("frame_failures", 0.0)
                channel_frames += channel_stats.get("total_frames", 0.0)
            clean_np = clean.cpu().numpy()
            estimate_np = estimate.cpu().numpy()
            for clean_item, estimate_item, valid_length in zip(
                clean_np, estimate_np, valid
            ):
                length = int(valid_length)
                reference = clean_item[0, :length]
                reconstructed = estimate_item[0, :length]
                objective.update(compute_objective_metrics(reconstructed, reference))
                if saved < save_examples:
                    suffix = "only" if esn0_db is None else f"gfsk_esn0_{esn0_db:g}"
                    path = output_dir / "examples" / f"sscc_{suffix}_{saved:03d}.wav"
                    path.parent.mkdir(parents=True, exist_ok=True)
                    sf.write(path, reconstructed, 16_000)
                    saved += 1
                segment_count += 1
    payload_bits = model.used_payload_bits_per_frame
    channel_applied = esn0_db is not None
    total_frame_bits = payload_bits + 56 if channel_applied else None
    return {
        "method": "sscc_no_channel" if esn0_db is None else "sscc_gfsk",
        "channel_applied": channel_applied,
        "framing_mode": framing_mode if channel_applied else "none",
        "reference_bitrate": model.reference_bitrate,
        "quantizer_bits": model.quantizer_bits,
        "latent_symbols_per_frame": model.latent_symbols_per_frame,
        "unused_payload_bits_per_frame": model.unused_payload_bits_per_frame,
        "esn0_db": esn0_db,
        "samples_per_symbol": samples_per_symbol if channel_applied else None,
        "segments": segment_count,
        "payload_channel_uses_per_frame": payload_bits if channel_applied else None,
        "total_channel_uses_per_frame": total_frame_bits,
        "payload_channel_uses_per_second": payload_bits * 50 if channel_applied else None,
        "total_channel_uses_per_second": total_frame_bits * 50 if channel_applied else None,
        "source_payload_bits_per_frame": payload_bits,
        **objective.mean(),
        "ber": total_errors / max(total_bits, 1.0) if esn0_db is not None else float("nan"),
        "decode_failure_rate": frame_failures / max(channel_frames, 1.0) if channel_applied else 0.0,
        "tx_symbol_energy": float(np.mean(energies)) if energies else float("nan"),
    }
