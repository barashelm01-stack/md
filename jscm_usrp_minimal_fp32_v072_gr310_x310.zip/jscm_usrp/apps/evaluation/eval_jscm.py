from __future__ import annotations
from pathlib import Path
import sys
_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(_ROOT / "src"))

import argparse
from pathlib import Path

import torch
from torch.utils.data import DataLoader

from apps.evaluation.benchmark import evaluate_jscm
from jscm.experiment_utils import (
    build_model_from_checkpoint,
    build_speech_dataset,
    set_seed,
    write_csv_rows,
)
from jscm.objective_metrics import dependency_status
from jscm.resource_report import jscm_resource_report, write_resource_report


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Evaluate JSCM bypass and FM chains")
    parser.add_argument("--data-root", default="/home/data")
    parser.add_argument("--test-manifest", default="")
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--output-dir", default="runs/jscm_eval_v03")
    parser.add_argument("--esn0-list", nargs="+", type=float, default=[0, 5, 10, 15, 20])
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--num-workers", type=int, default=4)
    parser.add_argument("--max-segments", type=int, default=1000)
    parser.add_argument("--save-examples", type=int, default=3)
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--framing-mode", choices=["oracle", "detected"], default="detected")
    parser.add_argument("--allow-non-fm-checkpoint", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    print(f"objective metric dependencies={dependency_status()}")
    output_dir = Path(args.output_dir).expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    checkpoint = torch.load(args.checkpoint, map_location=device, weights_only=False)
    if checkpoint.get("stage") == "bypass" and not args.allow_non_fm_checkpoint:
        raise RuntimeError("Use best_fm.pt or pass --allow-non-fm-checkpoint intentionally")
    model = build_model_from_checkpoint(checkpoint, device)
    dataset = build_speech_dataset(
        manifest_path=args.test_manifest or None,
        data_root=args.data_root or None,
        subset="test-clean",
        training=False,
        max_segments=args.max_segments,
        random_gain_db=0.0,
    )
    loader = DataLoader(
        dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,
        pin_memory=device.type == "cuda",
        persistent_workers=args.num_workers > 0,
    )

    rows = [
        evaluate_jscm(
            model, loader, output_dir, "bypass", None, args.seed, args.save_examples
        )
    ]
    for esn0_db in args.esn0_list:
        rows.append(
            evaluate_jscm(
                model,
                loader,
                output_dir,
                "fm",
                float(esn0_db),
                args.seed,
                args.save_examples,
                framing_mode=args.framing_mode,
            )
        )
    write_csv_rows(rows, output_dir / "metrics.csv")
    write_resource_report(jscm_resource_report(model), output_dir / "resource_report.json")


if __name__ == "__main__":
    main()
