from __future__ import annotations
from pathlib import Path
import sys
_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(_ROOT / "src"))

import argparse
import csv
import json
import math
from pathlib import Path
from typing import Any, Optional, Union

import matplotlib.pyplot as plt


METRICS: dict[str, tuple[str, str]] = {
    "waveform_distance": ("Waveform Distance", "Mean absolute waveform distance"),
    "segsnr_db": ("Segmental SNR", "SegSNR (dB)"),
    "pesq_wb": ("PESQ-WB", "PESQ-WB"),
    "si_sdr_db": ("SI-SDR", "SI-SDR (dB)"),
    "stft_distance": ("STFT Distance", "Multi-resolution STFT distance"),
    "stoi": ("STOI", "STOI"),
}

METHODS: dict[str, str] = {
    "jscm_fm": "Proposed JSCM-FM",
    "opus_gfsk": "Opus-GFSK",
}


def _to_float(value: Any) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return float("nan")


def read_rows(csv_path: Union[str, Path]) -> list[dict[str, str]]:
    with Path(csv_path).open("r", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def read_gain_snr_rows(path: Optional[Union[str, Path]]) -> list[dict[str, float]]:
    if path is None:
        return []
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(path)

    if path.suffix.lower() == ".csv":
        with path.open("r", encoding="utf-8", newline="") as handle:
            return [
                {
                    key: _to_float(value)
                    for key, value in row.items()
                }
                for row in csv.DictReader(handle)
            ]

    if path.suffix.lower() == ".json":
        data = json.loads(path.read_text(encoding="utf-8"))
        rows: list[dict[str, float]] = []
        raw_points = data.get("measured_points") or data.get("points") or []
        if isinstance(raw_points, list):
            for row in raw_points:
                if isinstance(row, dict):
                    rows.append({key: _to_float(value) for key, value in row.items()})
        target_table = data.get("target_gain_table") or []
        for row in target_table:
            if not isinstance(row, dict):
                continue
            rows.append(
                {
                    "tx_gain_db": _to_float(row.get("recommended_tx_gain_db")),
                    "symbol_esn0_db": _to_float(row.get("target_snr_db")),
                    "sample_snr_db": float("nan"),
                }
            )
        return rows

    raise ValueError(f"Unsupported gain/SNR file format: {path.suffix}")


def _collect_metric_points(
    rows: list[dict[str, Any]], method: str, metric: str,
) -> list[tuple[float, float]]:
    points: list[tuple[float, float]] = []
    for row in rows:
        if row.get("method") != method:
            continue
        snr = _to_float(row.get("esn0_db"))
        value = _to_float(row.get(metric))
        if math.isfinite(snr) and math.isfinite(value):
            points.append((snr, value))
    points.sort(key=lambda item: item[0])
    return points


def _plot_metric_axis(ax, rows: list[dict[str, Any]], metric: str, title: str, ylabel: str) -> None:
    plotted = False
    for method, label in METHODS.items():
        points = _collect_metric_points(rows, method, metric)
        if not points:
            continue
        x, y = zip(*points)
        ax.plot(x, y, marker="o", linewidth=1.8, markersize=5, label=label)
        plotted = True
    ax.set_title(f"{title} vs. SNR")
    ax.set_xlabel("SNR / $E_s/N_0$ (dB)")
    ax.set_ylabel(ylabel)
    ax.grid(True, alpha=0.3)
    if plotted:
        ax.legend(fontsize=8)
    else:
        ax.text(0.5, 0.5, "No finite JSCM-FM/Opus-GFSK data", ha="center", va="center", transform=ax.transAxes)


def _plot_gain_snr_axis(ax, gain_rows: list[dict[str, float]], snr_key: str, title: str, ylabel: str) -> None:
    points: list[tuple[float, float]] = []
    for row in gain_rows:
        gain = _to_float(row.get("tx_gain_db"))
        snr = _to_float(row.get(snr_key))
        if math.isfinite(gain) and math.isfinite(snr):
            points.append((gain, snr))
    points.sort(key=lambda item: item[0])
    if points:
        x, y = zip(*points)
        ax.plot(x, y, marker="s", linewidth=1.8, markersize=5)
    else:
        ax.text(0.5, 0.5, f"No finite {snr_key} data", ha="center", va="center", transform=ax.transAxes)
    ax.set_title(title)
    ax.set_xlabel("TX gain (dB)")
    ax.set_ylabel(ylabel)
    ax.grid(True, alpha=0.3)


def plot_metric_dashboard(
    rows: list[dict[str, Any]],
    output_dir: Union[str, Path],
    gain_snr_rows: Optional[list[dict[str, float]]] = None,
    formats: tuple[str, ...] = ("png",),
) -> list[Path]:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    generated: list[Path] = []
    gain_snr_rows = gain_snr_rows or []

    fig = plt.figure(figsize=(15.5, 9.2), constrained_layout=True)
    grid = fig.add_gridspec(nrows=3, ncols=3, width_ratios=[1.0, 1.0, 0.95], wspace=0.35, hspace=0.42)

    metric_items = list(METRICS.items())
    for index, (metric, (title, ylabel)) in enumerate(metric_items):
        row_index = index // 2
        col_index = index % 2
        ax = fig.add_subplot(grid[row_index, col_index])
        _plot_metric_axis(ax, rows, metric, title, ylabel)

    right_grid = grid[:, 2].subgridspec(2, 1, hspace=0.34)
    ax_top = fig.add_subplot(right_grid[0, 0])
    _plot_gain_snr_axis(
        ax_top,
        gain_snr_rows,
        snr_key="sample_snr_db",
        title="TX Gain vs Sample-domain SNR",
        ylabel="Sample SNR (dB)",
    )
    ax_bottom = fig.add_subplot(right_grid[1, 0])
    _plot_gain_snr_axis(
        ax_bottom,
        gain_snr_rows,
        snr_key="symbol_esn0_db",
        title="TX Gain vs Symbol-domain $E_s/N_0$",
        ylabel="$E_s/N_0$ (dB)",
    )

    fig.suptitle("KPI vs SNR with TX-Gain Calibration Summary", fontsize=14)
    for extension in formats:
        path = output_dir / f"kpi_vs_snr_dashboard.{extension}"
        fig.savefig(path, dpi=220, bbox_inches="tight")
        generated.append(path)
    plt.close(fig)
    return generated


def plot_metric_curves(
    rows: list[dict[str, Any]],
    output_dir: Union[str, Path],
    gain_snr_rows: Optional[list[dict[str, float]]] = None,
    formats: tuple[str, ...] = ("png",),
) -> list[Path]:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    generated: list[Path] = []

    for metric, (title, ylabel) in METRICS.items():
        fig, ax = plt.subplots(figsize=(6.4, 4.4))
        _plot_metric_axis(ax, rows, metric, title, ylabel)
        fig.tight_layout()
        for extension in formats:
            path = output_dir / f"{metric}_vs_esn0.{extension}"
            fig.savefig(path, dpi=200, bbox_inches="tight")
            generated.append(path)
        plt.close(fig)

    generated.extend(plot_metric_dashboard(rows, output_dir, gain_snr_rows, formats))
    return generated


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Plot KPI-vs-SNR curves and a TX-gain-vs-SNR summary panel")
    parser.add_argument("--metrics-csv", required=True)
    parser.add_argument("--gain-snr-file", default="", help="Optional CSV/JSON containing tx_gain_db and measured SNR columns")
    parser.add_argument("--output-dir", default="figures")
    parser.add_argument("--formats", nargs="+", default=["png"], choices=["png", "pdf", "svg"])
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    gain_rows = read_gain_snr_rows(args.gain_snr_file) if args.gain_snr_file else []
    paths = plot_metric_curves(
        read_rows(args.metrics_csv),
        args.output_dir,
        gain_snr_rows=gain_rows,
        formats=tuple(args.formats),
    )
    for path in paths:
        print(path)


if __name__ == "__main__":
    main()
