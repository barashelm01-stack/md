from __future__ import annotations

import platform
import sys
from pathlib import Path

EXPECTED_PYTHON = (3, 9)
EXPECTED_TORCH = "2.5.1"
DEFAULT_DATA_ROOT = Path("/home/data")


def main() -> None:
    import torch

    errors: list[str] = []
    warnings: list[str] = []

    if sys.version_info[:2] != EXPECTED_PYTHON:
        errors.append(
            f"Python must be 3.9.x, detected {platform.python_version()}"
        )
    if torch.__version__.split("+")[0] != EXPECTED_TORCH:
        errors.append(
            f"torch must be {EXPECTED_TORCH}, detected {torch.__version__}"
        )
    if not DEFAULT_DATA_ROOT.exists():
        errors.append(f"LibriSpeech root does not exist: {DEFAULT_DATA_ROOT}")

    cuda_available = torch.cuda.is_available()
    torch_cuda = torch.version.cuda
    if cuda_available:
        device_name = torch.cuda.get_device_name(0)
        capability = torch.cuda.get_device_capability(0)
    else:
        device_name = "none"
        capability = None
        warnings.append("torch.cuda.is_available() is False")

    print(f"python={platform.python_version()}")
    print(f"torch={torch.__version__}")
    print(f"torch_cuda_runtime={torch_cuda}")
    print(f"cuda_available={cuda_available}")
    print(f"gpu={device_name}")
    print(f"compute_capability={capability}")
    print(f"data_root={DEFAULT_DATA_ROOT}")

    for warning in warnings:
        print(f"WARNING: {warning}")
    if errors:
        for error in errors:
            print(f"ERROR: {error}")
        raise SystemExit(1)
    print("environment_check=PASS")


if __name__ == "__main__":
    main()
