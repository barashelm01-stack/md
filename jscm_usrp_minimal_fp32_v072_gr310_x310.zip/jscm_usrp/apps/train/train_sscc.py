from __future__ import annotations
from pathlib import Path
import sys
_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(_ROOT / "src"))

import argparse
import csv
import json
import shutil
import time
from pathlib import Path
from typing import Any

import torch
from torch.nn.utils import clip_grad_norm_
from torch.utils.data import DataLoader

from jscm.experiment_utils import (
    build_speech_dataset,
    capture_rng_state,
    restore_rng_state,
    set_seed,
    validate_resume_config,
    write_csv_rows,
)
from jscm.losses import JSCMLoss
from jscm.metric_utils import aggregate_metric_records
from jscm.sscc import SSCCSystem
from jscm.training_runtime import accumulation_group_size, is_optimizer_step


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Train SSCC: Separate Source-Channel Coding")
    p.add_argument("--data-root", default="/home/data")
    p.add_argument("--train-manifest", default="")
    p.add_argument("--val-manifest", default="")
    p.add_argument("--output-dir", default="runs/sscc_6k")
    p.add_argument("--epochs", type=int, default=100)
    p.add_argument("--batch-size", type=int, default=50, help="Physical micro-batch size.")
    p.add_argument("--gradient-accumulation-steps", type=int, default=2)
    p.add_argument("--num-workers", type=int, default=8)
    p.add_argument("--lr", type=float, default=3e-4)
    p.add_argument("--weight-decay", type=float, default=1e-4)
    p.add_argument("--reference-bitrate", type=int, default=6000)
    p.add_argument("--quantizer-bits", type=int, default=6)
    p.add_argument("--model-dim", type=int, default=64)
    p.add_argument("--ff-dim", type=int, default=128)
    p.add_argument("--num-heads", type=int, default=4)
    p.add_argument("--encoder-layers", type=int, default=2)
    p.add_argument("--decoder-layers", type=int, default=2)
    p.add_argument("--disable-transformer", action="store_true")
    p.add_argument("--max-grad-norm", type=float, default=5.0)
    p.add_argument("--validate-every", type=int, default=1)
    p.add_argument("--seed", type=int, default=2026)
    p.add_argument("--resume", type=str, default="")
    args = p.parse_args()
    if args.gradient_accumulation_steps < 1:
        p.error("--gradient-accumulation-steps must be >= 1")
    if args.validate_every < 1:
        p.error("--validate-every must be >= 1")
    return args


def evaluate(model, loader, criterion, device):
    model.eval()
    records: list[dict[str, float]] = []
    with torch.no_grad():
        for batch in loader:
            x = batch["waveform"].to(device, non_blocking=True)
            valid = batch["valid_samples"].to(device, non_blocking=True)
            y, aux = model(x, return_aux=True)
            _, metrics = criterion(y.float(), x.float(), valid, aux)
            records.append(metrics)
    return aggregate_metric_records(records)


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    out = Path(args.output_dir).expanduser().resolve()
    out.mkdir(parents=True, exist_ok=True)
    (out / "config.json").write_text(json.dumps(vars(args), indent=2), encoding="utf-8")

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if device.type == "cuda":
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True

    train_ds = build_speech_dataset(
        manifest_path=args.train_manifest or None,
        data_root=args.data_root if not args.train_manifest else None,
        subset="train-clean-100",
        training=True,
        random_gain_db=6.0,
        seed=args.seed,
    )
    val_ds = build_speech_dataset(
        manifest_path=args.val_manifest or None,
        data_root=args.data_root if not args.val_manifest else None,
        subset="dev-clean",
        training=False,
        random_gain_db=0.0,
        seed=args.seed + 1,
    )
    data_generator = torch.Generator().manual_seed(args.seed)
    train_loader = DataLoader(
        train_ds,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.num_workers,
        pin_memory=device.type == "cuda",
        generator=data_generator,
        persistent_workers=False,
    )
    val_loader = DataLoader(
        val_ds,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,
        pin_memory=device.type == "cuda",
        persistent_workers=False,
    )
    model = SSCCSystem(
        reference_bitrate=args.reference_bitrate,
        quantizer_bits=args.quantizer_bits,
        model_dim=args.model_dim,
        ff_dim=args.ff_dim,
        num_heads=args.num_heads,
        encoder_layers=args.encoder_layers,
        decoder_layers=args.decoder_layers,
        use_transformer=not args.disable_transformer,
    ).to(device)
    criterion = JSCMLoss(latent_target_rms=0.55).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=max(args.epochs, 1))

    best = float("inf")
    rows: list[dict[str, Any]] = []
    start_epoch = 0
    if args.resume:
        checkpoint = torch.load(args.resume, map_location=device, weights_only=False)
        validate_resume_config(
            checkpoint.get("args", {}),
            vars(args),
            [
                "reference_bitrate", "quantizer_bits", "model_dim", "ff_dim",
                "num_heads", "encoder_layers", "decoder_layers", "disable_transformer",
                "gradient_accumulation_steps",
            ],
        )
        model.load_state_dict(checkpoint["model"])
        optimizer.load_state_dict(checkpoint["optimizer"])
        scheduler.load_state_dict(checkpoint["scheduler"])
        best = float(checkpoint.get("best_val", float("inf")))
        start_epoch = int(checkpoint["epoch"]) + 1
        restore_rng_state(checkpoint.get("rng_state"))
        if "data_generator_state" in checkpoint:
            data_generator.set_state(checkpoint["data_generator_state"])
        history = out / "epoch_metrics.csv"
        if history.is_file():
            with history.open("r", encoding="utf-8") as f:
                rows = list(csv.DictReader(f))

    effective_batch = args.batch_size * args.gradient_accumulation_steps
    print(
        f"device={device} precision=fp32 "
        f"physical_batch={args.batch_size} accumulation={args.gradient_accumulation_steps} "
        f"effective_batch={effective_batch}"
    )

    for epoch in range(start_epoch, args.epochs):
        if hasattr(train_ds, "set_epoch"):
            train_ds.set_epoch(epoch)
        model.train()
        records: list[dict[str, float]] = []
        optimizer.zero_grad(set_to_none=True)
        total_steps = len(train_loader)
        epoch_start = time.time()

        for step, batch in enumerate(train_loader):
            x = batch["waveform"].to(device, non_blocking=True)
            valid = batch["valid_samples"].to(device, non_blocking=True)
            group_size = accumulation_group_size(
                step, total_steps, args.gradient_accumulation_steps
            )
            y, aux = model(x, return_aux=True)
            loss, metrics = criterion(y.float(), x.float(), valid, aux)
            backward_loss = loss / float(group_size)
            backward_loss.backward()
            metrics["gradient_norm"] = 0.0

            if is_optimizer_step(step, total_steps, args.gradient_accumulation_steps):
                gradient_norm = clip_grad_norm_(model.parameters(), args.max_grad_norm)
                if not torch.isfinite(gradient_norm):
                    raise FloatingPointError(
                        f"Non-finite gradient norm at epoch={epoch}, step={step}"
                    )
                optimizer.step()
                optimizer.zero_grad(set_to_none=True)
                metrics["gradient_norm"] = float(gradient_norm.detach())
            records.append(metrics)

        scheduler.step()
        train_metrics = aggregate_metric_records(records)
        should_validate = ((epoch + 1) % args.validate_every == 0) or (epoch + 1 == args.epochs)
        val_metrics = evaluate(model, val_loader, criterion, device) if should_validate else {}
        elapsed = time.time() - epoch_start
        row: dict[str, Any] = {
            "epoch": epoch,
            "elapsed_s": elapsed,
            "lr": optimizer.param_groups[0]["lr"],
            "physical_batch_size": args.batch_size,
            "gradient_accumulation_steps": args.gradient_accumulation_steps,
            "effective_batch_size": effective_batch,
            "precision": "fp32",
            "validated": should_validate,
            **{f"train_{k}": v for k, v in train_metrics.items()},
            **{f"val_{k}": v for k, v in val_metrics.items()},
        }
        rows.append(row)
        write_csv_rows(rows, out / "epoch_metrics.csv")

        current_val = float(val_metrics.get("loss", float("inf")))
        if should_validate and current_val < best:
            best = current_val
        checkpoint = {
            "format_version": 3,
            "system_name": "SSCC",
            "model": model.state_dict(),
            "optimizer": optimizer.state_dict(),
            "scheduler": scheduler.state_dict(),
            "args": vars(args),
            "epoch": epoch,
            "best_val": best,
            "rng_state": capture_rng_state(),
            "data_generator_state": data_generator.get_state(),
        }
        torch.save(checkpoint, out / "last.pt")
        if should_validate and current_val <= best:
            shutil.copy2(out / "last.pt", out / "best.pt")
        print(
            f"epoch={epoch:03d} time={elapsed:.1f}s train={train_metrics['loss']:.4f} "
            f"val={val_metrics.get('loss', float('nan')):.4f} "
            f"effective_batch={effective_batch} precision=fp32"
        )


if __name__ == "__main__":
    main()
