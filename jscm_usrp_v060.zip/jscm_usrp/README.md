# JSCM-USRP Prototype

Reorganized prototype for joint source-channel speech communication with a PyTorch neural layer,
GNU Radio modulation/demodulation layer and two-USRP RF layer.

- Current architecture: `docs/SYSTEM_ARCHITECTURE.md`
- Remaining work: `docs/REMAINING_WORK.md`
- GNU Radio/USRP integration: `docs/GNURADIO_USRP_GUIDE.md`
- Core package: `src/jscm`
- Training and evaluation entry points: `apps`
- GNU Radio assets: `gnuradio`
- Hardware utilities: `usrp`

## Install core

```bash
pip install -e .
```

Optional metrics/radio dependencies:

```bash
pip install -e ".[metrics,radio,opus]"
```

## Important status

The neural, framing and ZeroMQ boundary code has been validated in software. Executable GNU Radio
UHD flowgraphs and physical two-USRP tests remain to be completed on the radio host.
