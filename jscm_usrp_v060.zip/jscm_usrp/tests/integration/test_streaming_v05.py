from __future__ import annotations

import unittest

import torch

from jscm.models import JSCMSystem
from jscm.sscc import SSCCSystem


class StreamingV05Test(unittest.TestCase):
    def test_jscm_stream_matches_block_bypass(self) -> None:
        torch.manual_seed(3)
        model = JSCMSystem(
            reference_bitrate=1000,
            model_dim=8,
            encoder_layers=1,
            decoder_layers=1,
        ).eval()
        waveform = torch.randn(1, 1, 16000)
        with torch.no_grad():
            block = model(waveform, None, channel_mode="bypass")
            state = model.init_stream_state(1)
            outputs = []
            for frame_index in range(50):
                frame = waveform[..., frame_index * 320 : (frame_index + 1) * 320]
                output, state = model.stream_step(frame, state, None, channel_mode="bypass")
                outputs.append(output)
            streamed = torch.cat(outputs, dim=-1)
        self.assertEqual(state["frames_processed"], 50)
        self.assertLess(float((block - streamed).abs().max()), 1e-5)

    def test_sscc_stream_matches_block(self) -> None:
        torch.manual_seed(4)
        model = SSCCSystem(
            reference_bitrate=1200,
            quantizer_bits=6,
            model_dim=8,
            encoder_layers=1,
            decoder_layers=1,
        ).eval()
        waveform = torch.randn(1, 1, 16000)
        with torch.no_grad():
            block = model(waveform)
            state = model.init_stream_state(1)
            outputs=[]
            for frame_index in range(50):
                output, state, _ = model.stream_step(
                    waveform[..., frame_index*320:(frame_index+1)*320], state
                )
                outputs.append(output)
            streamed=torch.cat(outputs,-1)
        self.assertLess(float((block-streamed).abs().max()),1e-5)


if __name__ == "__main__":
    unittest.main()
