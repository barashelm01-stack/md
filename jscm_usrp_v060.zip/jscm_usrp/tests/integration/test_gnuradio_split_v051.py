import unittest
import numpy as np
import torch

from jscm.gnuradio_blocks import deframe_demodulated, frame_bits, frame_continuous
from jscm.models import JSCMSystem
from jscm.radio_protocol import RadioMode, RadioPacket, deserialize_packet, serialize_packet
from jscm.sscc import SSCCSystem


class TestGNURadioSplit(unittest.TestCase):
    def test_radio_packet_roundtrip(self):
        source = RadioPacket(RadioMode.JSCM_CONTINUOUS, 7, np.linspace(-.5,.5,120,dtype=np.float32), 16000, 123, {"x":1})
        restored = deserialize_packet(serialize_packet(source))
        self.assertEqual(restored.mode, source.mode)
        self.assertEqual(restored.sequence_id, 7)
        np.testing.assert_array_equal(restored.payload, source.payload)

    def test_continuous_framer_roundtrip(self):
        payload = np.linspace(-.8,.8,120,dtype=np.float32)
        framed = frame_continuous(payload, 9)
        result = deframe_demodulated(np.concatenate([np.zeros(5,dtype=np.float32),framed.symbols]))
        self.assertIsNotNone(result)
        mode, seq, recovered = result
        self.assertEqual(mode, RadioMode.JSCM_CONTINUOUS); self.assertEqual(seq, 9)
        np.testing.assert_allclose(recovered, payload)

    def test_bit_framer_roundtrip(self):
        payload = np.arange(120,dtype=np.uint8)%2
        framed = frame_bits(payload, RadioMode.SSCC_BITS, 3)
        mode, seq, recovered = deframe_demodulated(framed.symbols)
        self.assertEqual(mode, RadioMode.SSCC_BITS); self.assertEqual(seq, 3)
        np.testing.assert_array_equal(recovered, payload)

    def test_jscm_split_stream_api(self):
        model = JSCMSystem(model_dim=16, encoder_layers=1, decoder_layers=1)
        x = torch.randn(1,1,320)
        es = model.init_encoder_stream_state(1)
        ds = model.init_decoder_stream_state(1)
        symbols, es = model.encode_source_stream(x, es)
        y, ds = model.decode_source_stream(symbols, ds)
        self.assertEqual(tuple(symbols.shape), (1,1,120))
        self.assertEqual(tuple(y.shape), (1,1,320))

    def test_sscc_split_stream_api(self):
        model = SSCCSystem(model_dim=16, encoder_layers=1, decoder_layers=1)
        x = torch.randn(1,1,320)
        es = model.init_encoder_stream_state(1)
        ds = model.init_decoder_stream_state(1)
        bits, es = model.encode_source_stream(x, es)
        y, ds = model.decode_source_stream(bits, ds)
        self.assertEqual(bits.shape, (1, model.used_payload_bits_per_frame))
        self.assertEqual(tuple(y.shape), (1,1,320))

if __name__ == '__main__': unittest.main()
