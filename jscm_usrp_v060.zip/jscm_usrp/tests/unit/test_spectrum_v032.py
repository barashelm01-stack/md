import unittest
import numpy as np

from jscm.gfsk import gfsk_modulate
from jscm.spectrum import occupied_bandwidth, packet_spectrum_report, spectrum_report, welch_psd


class SpectrumV032Test(unittest.TestCase):
    def test_psd_and_occupied_bandwidth(self):
        rng=np.random.default_rng(1)
        signal=gfsk_modulate(rng.integers(0,2,2000,dtype=np.uint8),samples_per_symbol=4)
        report,freq,psd=spectrum_report(signal,4_000_000.0)
        self.assertEqual(freq.shape,psd.shape)
        self.assertGreater(report["occupied_bandwidth_hz"],0)
        self.assertLessEqual(report["occupied_bandwidth_hz"],4_000_000.0)
        self.assertAlmostEqual(report["papr_db"],0.0,places=5)

    def test_packet_report_avoids_boundary_jump(self):
        packet=np.exp(1j*np.linspace(0,1,1000))
        report,_,_=packet_spectrum_report([packet,packet],4_000_000.0)
        self.assertLess(report["frequency_abs_max_hz"],1000.0)

    def test_known_rectangular_band(self):
        f=np.linspace(-100,100,201)
        p=np.zeros_like(f); p[(f>=-20)&(f<=30)]=1
        result=occupied_bandwidth(f,p,0.99)
        self.assertLessEqual(result["occupied_low_hz"],-19)
        self.assertGreaterEqual(result["occupied_high_hz"],29)

if __name__ == "__main__": unittest.main()
