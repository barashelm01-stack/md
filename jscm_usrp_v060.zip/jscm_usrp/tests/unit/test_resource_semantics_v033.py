from __future__ import annotations

import unittest

from apps.evaluation.benchmark import _jscm_row_resources
from jscm.models import JSCMSystem


class ResourceSemanticsV033Test(unittest.TestCase):
    def test_no_channel_has_no_wireless_resources(self) -> None:
        model = JSCMSystem(reference_bitrate=6000, model_dim=16, ff_dim=32, num_heads=4,
                           encoder_layers=1, decoder_layers=1, channel_sps=2)
        row = _jscm_row_resources(model, False)
        self.assertIsNone(row["total_channel_uses_per_second"])
        self.assertIsNone(row["samples_per_symbol"])

    def test_channel_row_has_resources(self) -> None:
        model = JSCMSystem(reference_bitrate=6000, model_dim=16, ff_dim=32, num_heads=4,
                           encoder_layers=1, decoder_layers=1, channel_sps=2)
        row = _jscm_row_resources(model, True)
        self.assertEqual(row["payload_channel_uses_per_frame"], 120)
        self.assertEqual(row["total_channel_uses_per_frame"], 176)


if __name__ == "__main__":
    unittest.main()
