from __future__ import annotations
import unittest
from jscm.experiment_utils import validate_resume_config

class ResumeConfigV033Test(unittest.TestCase):
    def test_matching(self):
        validate_resume_config({"a":1,"b":2},{"a":1,"b":2,"epochs":5},["a","b"])
    def test_mismatch(self):
        with self.assertRaises(ValueError):
            validate_resume_config({"a":1},{"a":2},["a"])

if __name__ == "__main__":
    unittest.main()
