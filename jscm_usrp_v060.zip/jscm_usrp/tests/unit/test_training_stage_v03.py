from __future__ import annotations

import argparse
import unittest

from apps.train.train_jscm import training_stage


class TrainingStageV03Test(unittest.TestCase):
    def _args(self, schedule: str) -> argparse.Namespace:
        return argparse.Namespace(
            schedule=schedule,
            pretrain_epochs=2,
            fm_warmup_epochs=1,
            mid_snr_epochs=2,
            warmup_esn0=40.0,
            mid_esn0_min=10.0,
            mid_esn0_max=20.0,
            esn0_min=-5.0,
            esn0_max=20.0,
        )

    def test_curriculum(self) -> None:
        args = self._args("curriculum")
        self.assertEqual(training_stage(0, args)[0], "bypass")
        self.assertEqual(training_stage(2, args)[0], "fm_warmup")
        self.assertEqual(training_stage(3, args)[0], "fm_mid")
        self.assertEqual(training_stage(5, args)[0], "fm_full")

    def test_direct(self) -> None:
        stage, low, high = training_stage(0, self._args("direct"))
        self.assertEqual(stage, "fm_direct")
        self.assertEqual((low, high), (-5.0, 20.0))


if __name__ == "__main__":
    unittest.main()
