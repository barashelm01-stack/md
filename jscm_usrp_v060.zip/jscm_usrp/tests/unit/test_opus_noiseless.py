from __future__ import annotations

import unittest

import numpy as np

from apps.evaluation.eval_opus_gfsk import create_opus_pair, opuslib, transmit_opus_frame


@unittest.skipIf(opuslib is None, "opuslib is not installed")
class OpusNoiselessTest(unittest.TestCase):
    def test_single_silent_frame_round_trip(self) -> None:
        bitrate = 6_000
        frame = np.zeros(320, dtype=np.float32)
        encoder, decoder = create_opus_pair(bitrate)
        ctl = opuslib.api.ctl
        encoder_ctl = opuslib.api.encoder.encoder_ctl
        self.assertEqual(encoder_ctl(encoder.encoder_state, ctl.get_bitrate), bitrate)
        self.assertEqual(encoder_ctl(encoder.encoder_state, ctl.get_vbr), 0)
        self.assertEqual(encoder_ctl(encoder.encoder_state, ctl.get_inband_fec), 0)
        self.assertEqual(encoder_ctl(encoder.encoder_state, ctl.get_dtx), 0)
        self.assertEqual(encoder_ctl(encoder.encoder_state, ctl.get_complexity), 10)

        decoded, bit_errors, total_bits, payload_bits, decode_failed = transmit_opus_frame(
            frame=frame,
            encoder=encoder,
            decoder=decoder,
            bitrate=bitrate,
            esn0_db=None,
            rng=np.random.default_rng(2026),
            samples_per_symbol=4,
        )
        self.assertEqual(decoded.shape, (320,))
        self.assertTrue(np.isfinite(decoded).all())
        self.assertEqual(bit_errors, 0)
        self.assertGreater(total_bits, payload_bits)
        self.assertEqual(total_bits - payload_bits, 56)
        self.assertFalse(decode_failed)


if __name__ == "__main__":
    unittest.main()
