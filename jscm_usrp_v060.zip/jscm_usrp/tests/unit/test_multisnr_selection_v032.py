import unittest
from apps.train.train_jscm import weighted_validation_loss


class MultiSNRSelectionV032Test(unittest.TestCase):
    def test_weighted_mean(self):
        metrics={0.0:{"loss":3.0},5.0:{"loss":2.0},10.0:{"loss":1.0}}
        self.assertAlmostEqual(weighted_validation_loss(metrics,[0,5,10]),2.0)
        self.assertAlmostEqual(weighted_validation_loss(metrics,[0,5,10],[2,1,1]),2.25)

    def test_invalid_weights(self):
        with self.assertRaises(ValueError):
            weighted_validation_loss({0.0:{"loss":1.0}},[0],[0])

if __name__ == "__main__": unittest.main()
