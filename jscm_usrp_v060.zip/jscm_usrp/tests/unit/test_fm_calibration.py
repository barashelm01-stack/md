from __future__ import annotations

import unittest

import torch

from jscm.channels import DifferentiableFMAWGN


class FMCalibrationTest(unittest.TestCase):
    def test_noiseless_recovery_and_energy(self) -> None:
        torch.manual_seed(7)
        payload = torch.randn(2, 4, 120)
        for sps in (2, 4, 8):
            channel = DifferentiableFMAWGN(samples_per_symbol=sps)
            bounded = channel.bound_payload(payload)
            recovered, aux = channel(payload, None, return_aux=True)
            mse = float((recovered - bounded).square().mean())
            self.assertLess(mse, 1e-4, msg=f"sps={sps}, mse={mse}")
            self.assertAlmostEqual(float(aux["tx_symbol_energy"]), 1.0, places=5)

    def test_packet_independence(self) -> None:
        torch.manual_seed(11)
        channel = DifferentiableFMAWGN(samples_per_symbol=4)
        payload_a = torch.randn(1, 3, 120)
        payload_b = payload_a.clone()
        payload_b[:, 0] = torch.randn_like(payload_b[:, 0]) * 5.0
        output_a = channel(payload_a, None)
        output_b = channel(payload_b, None)
        difference = float((output_a[:, 1:] - output_b[:, 1:]).abs().max())
        self.assertLess(difference, 1e-7)

    def test_packetwise_esn0_and_gradient(self) -> None:
        torch.manual_seed(13)
        channel = DifferentiableFMAWGN(samples_per_symbol=4)
        payload = torch.randn(2, 5, 16, requires_grad=True)
        esn0 = torch.linspace(-5.0, 20.0, 10).reshape(2, 5)
        output = channel(payload, esn0)
        output.square().mean().backward()
        self.assertTrue(torch.isfinite(output).all())
        self.assertIsNotNone(payload.grad)
        self.assertTrue(torch.isfinite(payload.grad).all())


if __name__ == "__main__":
    unittest.main()
