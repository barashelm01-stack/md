from __future__ import annotations

import unittest

import numpy as np

from jscm.objective_metrics import MetricAccumulator, compute_objective_metrics, si_sdr_np


class ObjectiveMetricsV03Test(unittest.TestCase):
    def test_identical_signal(self) -> None:
        rng = np.random.default_rng(2026)
        signal = rng.standard_normal(16_000).astype(np.float32) * 0.05
        metrics = compute_objective_metrics(signal, signal)
        self.assertGreater(metrics["si_sdr_db"], 100.0)
        self.assertAlmostEqual(metrics["output_input_rms_ratio"], 1.0, places=5)
        if np.isfinite(metrics["stoi"]):
            self.assertGreater(metrics["stoi"], 0.99)

    def test_accumulator_ignores_nan(self) -> None:
        accumulator = MetricAccumulator()
        accumulator.update({"a": 1.0, "b": float("nan")})
        accumulator.update({"a": 3.0, "b": 2.0})
        result = accumulator.mean()
        self.assertEqual(result["a"], 2.0)
        self.assertEqual(result["a_count"], 2)
        self.assertEqual(result["b"], 2.0)
        self.assertEqual(result["b_count"], 1)

    def test_all_nan_key_is_preserved(self) -> None:
        accumulator = MetricAccumulator()
        accumulator.update({"pesq_wb": float("nan")})
        result = accumulator.mean()
        self.assertTrue(np.isnan(result["pesq_wb"]))
        self.assertEqual(result["pesq_wb_count"], 0)

    def test_silence_is_nan_sisdr(self) -> None:
        silence = np.zeros(16_000, dtype=np.float32)
        self.assertTrue(np.isnan(si_sdr_np(silence, silence)))


if __name__ == "__main__":
    unittest.main()
