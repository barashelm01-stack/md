import unittest
import numpy as np
import torch

from jscm.sscc import (
    SSCCSystem, bits_to_indices, indices_to_bits,
    quantization_layout, uniform_quantize_ste,
)


class SSCCSystemTest(unittest.TestCase):
    def test_bit_roundtrip(self):
        indices=np.array([0,1,17,63],dtype=np.int64)
        bits=indices_to_bits(indices,6)
        np.testing.assert_array_equal(bits_to_indices(bits,6),indices)

    def test_layout(self):
        latent,used=quantization_layout(6000,20,6)
        self.assertEqual((latent,used),(20,120))

    def test_forward_backward_and_noiseless_gfsk(self):
        torch.manual_seed(2)
        model=SSCCSystem(model_dim=32,ff_dim=64,encoder_layers=1,decoder_layers=1,num_heads=4)
        x=torch.randn(1,1,16000)*0.05
        y,aux=model(x,return_aux=True)
        self.assertEqual(y.shape,x.shape)
        y.abs().mean().backward()
        self.assertTrue(all(torch.isfinite(p.grad).all() for p in model.parameters() if p.grad is not None))
        rng=np.random.default_rng(2)
        y_channel,stats=model.transmit_gfsk(x,120.0,rng,samples_per_symbol=4)
        self.assertEqual(y_channel.shape,x.shape)
        self.assertEqual(stats["bit_errors"],0.0)

if __name__ == "__main__": unittest.main()
