from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

import numpy as np
import soundfile as sf

from jscm.data import ManifestSpeechDataset
from jscm.manifest import make_balanced_fixed_entries, write_manifest


class ManifestSizeV031Test(unittest.TestCase):
    def _make_files(self, root: Path, speakers: int, files_per_speaker: int) -> list[Path]:
        files: list[Path] = []
        for speaker in range(speakers):
            chapter = root / f"{speaker:04d}" / "0001"
            chapter.mkdir(parents=True, exist_ok=True)
            for utterance in range(files_per_speaker):
                path = chapter / f"{speaker:04d}-0001-{utterance:04d}.wav"
                length = 16_000 + utterance * 37
                sf.write(path, np.zeros(length, dtype=np.float32), 16_000)
                files.append(path)
        return files

    def test_exact_size_unique_utterances_and_fixed_training(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            files = self._make_files(root, speakers=4, files_per_speaker=4)
            entries = make_balanced_fixed_entries(files, num_segments=12, seed=2026)

            self.assertEqual(len(entries), 12)
            self.assertEqual(len({entry["utterance_id"] for entry in entries}), 12)
            self.assertEqual(len({entry["speaker_id"] for entry in entries}), 4)
            self.assertTrue(all(entry["valid_samples"] == 16_000 for entry in entries))
            self.assertTrue(all(entry["start_sample"] is not None for entry in entries))

            manifest_path = root / "train_fixed.jsonl"
            write_manifest(entries, manifest_path)
            dataset = ManifestSpeechDataset(
                manifest_path,
                training=True,
                crops_per_entry=1,
                random_gain_db=0.0,
            )
            self.assertEqual(len(dataset), 12)
            self.assertEqual(dataset[0]["waveform"].shape, (1, 16_000))
            self.assertEqual(int(dataset[0]["valid_samples"]), 16_000)

    def test_reproducible_selection(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            files = self._make_files(root, speakers=3, files_per_speaker=5)
            first = make_balanced_fixed_entries(files, num_segments=10, seed=7)
            second = make_balanced_fixed_entries(files, num_segments=10, seed=7)
            third = make_balanced_fixed_entries(files, num_segments=10, seed=8)

            first_key = [(entry["utterance_id"], entry["start_sample"]) for entry in first]
            second_key = [(entry["utterance_id"], entry["start_sample"]) for entry in second]
            third_key = [(entry["utterance_id"], entry["start_sample"]) for entry in third]
            self.assertEqual(first_key, second_key)
            self.assertNotEqual(first_key, third_key)

    def test_reject_insufficient_eligible_utterances(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            files = self._make_files(root, speakers=2, files_per_speaker=2)
            with self.assertRaises(ValueError):
                make_balanced_fixed_entries(files, num_segments=5, seed=1)


if __name__ == "__main__":
    unittest.main()
