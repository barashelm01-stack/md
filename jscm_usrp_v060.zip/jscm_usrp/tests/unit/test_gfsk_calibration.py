from __future__ import annotations

import unittest

import numpy as np

from jscm.gfsk import gfsk_demodulate, gfsk_modulate, symbol_energy


class GFSKCalibrationTest(unittest.TestCase):
    def test_noiseless_ber_and_symbol_energy(self) -> None:
        rng = np.random.default_rng(2026)
        bits = rng.integers(0, 2, size=10_000, dtype=np.uint8)
        for sps in (2, 4, 8):
            waveform = gfsk_modulate(bits, samples_per_symbol=sps)
            recovered, _ = gfsk_demodulate(
                waveform,
                bits.size,
                samples_per_symbol=sps,
            )
            ber = float(np.mean(bits != recovered))
            self.assertEqual(ber, 0.0, msg=f"sps={sps}")
            self.assertAlmostEqual(symbol_energy(waveform, bits.size), 1.0, places=10)


if __name__ == "__main__":
    unittest.main()
