from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

import numpy as np
import soundfile as sf

from jscm.data import ManifestSpeechDataset
from jscm.manifest import (
    make_fixed_segment_entries,
    make_train_file_entries,
    read_manifest,
    write_manifest,
)


class ManifestV03Test(unittest.TestCase):
    def test_fixed_and_random_manifests(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            paths = []
            for index, length in enumerate((20_000, 8_000)):
                path = root / f"sample_{index}.wav"
                sf.write(path, np.linspace(-0.1, 0.1, length, dtype=np.float32), 16_000)
                paths.append(path)

            fixed = make_fixed_segment_entries(paths, max_segments=3)
            fixed_path = root / "fixed.jsonl"
            write_manifest(fixed, fixed_path)
            loaded = read_manifest(fixed_path)
            self.assertEqual(len(loaded), 3)
            dataset = ManifestSpeechDataset(fixed_path, training=False)
            self.assertEqual(len(dataset), 3)
            self.assertEqual(dataset[0]["waveform"].shape, (1, 16_000))
            self.assertEqual(int(dataset[1]["valid_samples"]), 4_000)

            train = make_train_file_entries(paths, max_files=1, seed=7)
            train_path = root / "train.jsonl"
            write_manifest(train, train_path)
            train_dataset = ManifestSpeechDataset(train_path, training=True, random_gain_db=0.0)
            self.assertEqual(len(train_dataset), 1)
            self.assertEqual(train_dataset[0]["waveform"].shape, (1, 16_000))

    def test_relative_path_resolution(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            audio = root / "audio.wav"
            sf.write(audio, np.zeros(16_000, dtype=np.float32), 16_000)
            manifest = root / "relative.jsonl"
            manifest.write_text(
                json.dumps(
                    {
                        "path": "audio.wav",
                        "utterance_id": "audio",
                        "start_sample": 0,
                        "num_samples": 16_000,
                        "valid_samples": 16_000,
                    }
                )
                + "\n",
                encoding="utf-8",
            )
            dataset = ManifestSpeechDataset(manifest, training=False)
            self.assertEqual(int(dataset[0]["valid_samples"]), 16_000)


if __name__ == "__main__":
    unittest.main()
