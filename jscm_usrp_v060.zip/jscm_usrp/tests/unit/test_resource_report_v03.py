from __future__ import annotations

import unittest

from jscm.models import JSCMSystem
from jscm.resource_report import jscm_resource_report, opus_resource_report


class ResourceReportV03Test(unittest.TestCase):
    def test_jscm_6k_report(self) -> None:
        model = JSCMSystem(
            reference_bitrate=6000,
            model_dim=32,
            ff_dim=64,
            num_heads=4,
            encoder_layers=1,
            decoder_layers=1,
        )
        report = jscm_resource_report(model)
        self.assertEqual(report["payload_channel_uses_per_frame"], 120)
        self.assertEqual(report["total_channel_uses_per_frame"], 176)
        self.assertEqual(report["total_channel_uses_per_second"], 8800)
        self.assertAlmostEqual(report["rf_duty_cycle"], 0.0088)

    def test_opus_report(self) -> None:
        report = opus_resource_report(6000, 4, 120.0, 176.0)
        self.assertEqual(report["overhead_channel_uses_per_frame"], 56)
        self.assertEqual(report["mean_total_channel_uses_per_second"], 8800.0)


if __name__ == "__main__":
    unittest.main()
