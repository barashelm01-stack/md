from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

import numpy as np

from jscm.objective_metrics import (
    compute_objective_metrics,
    segmental_snr_np,
    stft_distance_np,
    waveform_distance_np,
)
from apps.evaluation.plot_metric_curves import METRICS, plot_metric_curves


class ObjectiveMetricTests(unittest.TestCase):
    def test_identical_waveforms_have_zero_distances_and_high_segsnr(self) -> None:
        t = np.arange(16000, dtype=np.float64) / 16000.0
        x = 0.2 * np.sin(2.0 * np.pi * 440.0 * t)
        self.assertAlmostEqual(waveform_distance_np(x, x), 0.0, places=12)
        self.assertLess(stft_distance_np(x, x), 1e-10)
        self.assertAlmostEqual(segmental_snr_np(x, x), 35.0, places=6)

    def test_metrics_degrade_with_added_noise(self) -> None:
        rng = np.random.default_rng(7)
        target = rng.normal(0.0, 0.1, 16000)
        mild = target + rng.normal(0.0, 0.005, 16000)
        severe = target + rng.normal(0.0, 0.05, 16000)
        self.assertLess(waveform_distance_np(mild, target), waveform_distance_np(severe, target))
        self.assertGreater(segmental_snr_np(mild, target), segmental_snr_np(severe, target))
        self.assertLess(stft_distance_np(mild, target), stft_distance_np(severe, target))

    def test_compute_objective_metrics_contains_requested_fields(self) -> None:
        target = np.linspace(-0.2, 0.2, 16000, dtype=np.float32)
        result = compute_objective_metrics(target.copy(), target)
        for key in (
            "waveform_distance", "segsnr_db", "pesq_wb",
            "si_sdr_db", "stft_distance", "stoi",
        ):
            self.assertIn(key, result)


class PlotTests(unittest.TestCase):
    def test_generates_one_figure_per_metric(self) -> None:
        rows = []
        for method in ("jscm_fm", "opus_gfsk"):
            for snr in (0.0, 5.0, 10.0):
                row = {"method": method, "esn0_db": snr}
                for index, metric in enumerate(METRICS):
                    row[metric] = snr + index + (0.2 if method == "jscm_fm" else 0.0)
                rows.append(row)
        with tempfile.TemporaryDirectory() as directory:
            paths = plot_metric_curves(rows, directory)
            self.assertEqual(len(paths), len(METRICS))
            for path in paths:
                self.assertTrue(Path(path).is_file())
                self.assertGreater(Path(path).stat().st_size, 0)


if __name__ == "__main__":
    unittest.main()
