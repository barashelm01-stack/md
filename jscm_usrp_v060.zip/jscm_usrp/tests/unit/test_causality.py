from __future__ import annotations

import unittest

import torch

from jscm.models import JSCMSystem


class CausalityTest(unittest.TestCase):
    def test_future_frames_do_not_change_past_output(self) -> None:
        torch.manual_seed(2026)
        model = JSCMSystem(
            reference_bitrate=6000,
            model_dim=32,
            ff_dim=64,
            num_heads=4,
            encoder_layers=1,
            decoder_layers=1,
            channel_sps=4,
        ).eval()
        first = torch.randn(1, 1, 16_000)
        second = first.clone()
        boundary = 8_000  # Exact 20-ms frame boundary.
        second[..., boundary:] = torch.randn_like(second[..., boundary:]) * 3.0
        with torch.no_grad():
            output_first = model(first, None, channel_mode="bypass")
            output_second = model(second, None, channel_mode="bypass")
        maximum_difference = float(
            (output_first[..., :boundary] - output_second[..., :boundary]).abs().max()
        )
        self.assertLess(maximum_difference, 1e-6, msg=str(maximum_difference))


if __name__ == "__main__":
    unittest.main()
