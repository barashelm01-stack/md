import unittest
import torch

from jscm.training_runtime import (
    accumulation_group_size,
    is_optimizer_step,
    resolve_amp_config,
)


class TrainingRuntimeV041Test(unittest.TestCase):
    def test_accumulation_with_short_final_group(self):
        sizes = [accumulation_group_size(i, 5, 2) for i in range(5)]
        self.assertEqual(sizes, [2, 2, 2, 2, 1])
        boundaries = [is_optimizer_step(i, 5, 2) for i in range(5)]
        self.assertEqual(boundaries, [False, True, False, True, True])

    def test_amp_auto_is_disabled_on_cpu(self):
        config = resolve_amp_config("auto", "float16", torch.device("cpu"))
        self.assertFalse(config.enabled)
        self.assertFalse(config.scaler_enabled)

    def test_amp_on_rejects_cpu(self):
        with self.assertRaises(RuntimeError):
            resolve_amp_config("on", "float16", torch.device("cpu"))


if __name__ == "__main__":
    unittest.main()
