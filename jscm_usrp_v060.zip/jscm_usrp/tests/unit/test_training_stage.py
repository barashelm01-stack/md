from __future__ import annotations

import argparse
import unittest

from apps.train.train_jscm import training_stage


class TrainingStageTest(unittest.TestCase):
    def test_curriculum_boundaries(self) -> None:
        args = argparse.Namespace(
            pretrain_epochs=5,
            fm_warmup_epochs=5,
            mid_snr_epochs=10,
            warmup_esn0=40.0,
            mid_esn0_min=10.0,
            mid_esn0_max=20.0,
            esn0_min=-5.0,
            esn0_max=20.0,
        )
        self.assertEqual(training_stage(0, args)[0], "bypass")
        self.assertEqual(training_stage(4, args)[0], "bypass")
        self.assertEqual(training_stage(5, args), ("fm_warmup", 40.0, 40.0))
        self.assertEqual(training_stage(9, args)[0], "fm_warmup")
        self.assertEqual(training_stage(10, args), ("fm_mid", 10.0, 20.0))
        self.assertEqual(training_stage(19, args)[0], "fm_mid")
        self.assertEqual(training_stage(20, args), ("fm_full", -5.0, 20.0))


if __name__ == "__main__":
    unittest.main()
