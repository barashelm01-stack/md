from __future__ import annotations

import unittest

from jscm.metric_utils import aggregate_metric_records


class MetricAggregationTest(unittest.TestCase):
    def test_weighting_and_peak_reduction(self) -> None:
        records = [
            {
                "_num_samples": 2.0,
                "_num_valid_samples": 10.0,
                "loss": 1.0,
                "l1": 1.0,
                "si_sdr_db": 2.0,
                "latent_peak": 0.5,
            },
            {
                "_num_samples": 1.0,
                "_num_valid_samples": 2.0,
                "loss": 4.0,
                "l1": 3.0,
                "si_sdr_db": 8.0,
                "latent_peak": 0.9,
            },
        ]
        result = aggregate_metric_records(records)
        self.assertAlmostEqual(result["loss"], 2.0)
        self.assertAlmostEqual(result["l1"], 4.0 / 3.0)
        self.assertAlmostEqual(result["si_sdr_db"], 4.0)
        self.assertAlmostEqual(result["latent_peak"], 0.9)
        self.assertFalse(any(key.startswith("_") for key in result))

    def test_empty_records_fail(self) -> None:
        with self.assertRaises(RuntimeError):
            aggregate_metric_records([])


if __name__ == "__main__":
    unittest.main()
