from __future__ import annotations

import unittest

import torch

from jscm.losses import JSCMLoss


class LossAuxV03Test(unittest.TestCase):
    def test_tensor_and_float_aux_values(self) -> None:
        criterion = JSCMLoss()
        target = torch.randn(1, 1, 16_000) * 0.01
        estimate = target.clone().requires_grad_(True)
        aux = {
            "bounded_payload": torch.zeros(1, 50, 120),
            "latent_mean": torch.tensor(0.0),
            "latent_rms": torch.tensor(0.0),
            "latent_peak": torch.tensor(0.0),
            "tanh_saturation_ratio": torch.tensor(0.0),
            "phase_increment_max": torch.tensor(0.1),
            "phase_increment_limit": 0.2,
            "tx_symbol_energy": torch.tensor(1.0),
        }
        loss, metrics = criterion(estimate, target, torch.tensor([16_000]), aux)
        loss.backward()
        self.assertEqual(metrics["phase_increment_limit"], 0.2)
        self.assertEqual(metrics["tx_symbol_energy"], 1.0)
        self.assertTrue(torch.isfinite(estimate.grad).all())


if __name__ == "__main__":
    unittest.main()
