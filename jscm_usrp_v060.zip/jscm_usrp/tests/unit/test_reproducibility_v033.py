from __future__ import annotations

import random
import tempfile
import unittest
from pathlib import Path

import numpy as np
import soundfile as sf
import torch

from jscm.data import ManifestSpeechDataset
from jscm.experiment_utils import capture_rng_state, restore_rng_state


class ReproducibilityV033Test(unittest.TestCase):
    def test_rng_round_trip(self) -> None:
        random.seed(7); np.random.seed(7); torch.manual_seed(7)
        state = capture_rng_state()
        expected = (random.random(), float(np.random.rand()), float(torch.rand(())))
        random.random(); np.random.rand(); torch.rand(())
        restore_rng_state(state)
        actual = (random.random(), float(np.random.rand()), float(torch.rand(())))
        self.assertEqual(expected[0], actual[0])
        self.assertEqual(expected[1], actual[1])
        self.assertEqual(expected[2], actual[2])

    def test_manifest_augmentation_is_epoch_index_deterministic(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            wav = np.linspace(-0.2, 0.2, 16000, dtype=np.float32)
            audio = root / "1-1-1.flac"
            sf.write(audio, wav, 16000)
            manifest = root / "train.jsonl"
            manifest.write_text(
                '{"path":"%s","utterance_id":"1-1-1","start_sample":0,"num_samples":16000,"valid_samples":16000}\n'
                % str(audio).replace('\\', '\\\\'),
                encoding="utf-8",
            )
            ds = ManifestSpeechDataset(manifest, training=True, random_gain_db=6.0, seed=123)
            ds.set_epoch(2)
            first = ds[0]["waveform"].clone()
            second = ds[0]["waveform"].clone()
            self.assertTrue(torch.equal(first, second))
            ds.set_epoch(3)
            third = ds[0]["waveform"].clone()
            self.assertFalse(torch.equal(first, third))


if __name__ == "__main__":
    unittest.main()
