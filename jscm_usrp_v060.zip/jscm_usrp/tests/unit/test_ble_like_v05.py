from __future__ import annotations

import unittest

import numpy as np
import torch

from jscm.ble_like import BLELikeBitFramer
from jscm.channels import DifferentiableFMAWGN


class BLELikeV05Test(unittest.TestCase):
    def test_bit_framer_detects_offset_and_header_length(self) -> None:
        rng=np.random.default_rng(8)
        payload=rng.integers(0,2,size=137,dtype=np.uint8)
        framer=BLELikeBitFramer(max_sync_errors=0)
        packet=framer.frame_bits(payload)
        received=np.concatenate([np.zeros(17,dtype=np.uint8),packet,np.ones(9,dtype=np.uint8)])
        result=framer.deframe_bits(received)
        self.assertTrue(result.success)
        self.assertEqual(result.packet_start,17)
        self.assertEqual(result.payload_length,payload.size)
        np.testing.assert_array_equal(result.payload_bits,payload)

    def test_truncated_packet_fails(self) -> None:
        payload=np.ones(100,dtype=np.uint8)
        framer=BLELikeBitFramer()
        result=framer.deframe_bits(framer.frame_bits(payload)[:-5])
        self.assertFalse(result.success)
        self.assertEqual(result.reason,"truncated_payload")

    def test_fm_detected_framing_recovers_noiseless_payload(self) -> None:
        torch.manual_seed(2)
        channel=DifferentiableFMAWGN(samples_per_symbol=4).eval()
        raw=torch.randn(2,3,120)
        with torch.no_grad():
            recovered,aux=channel(
                raw,None,return_aux=True,framing_mode="detected",leading_idle_symbols=11
            )
        target=channel.bound_payload(raw)
        self.assertGreater(float(aux["frame_success_rate"]),0.999)
        self.assertLess(float((recovered-target).square().mean()),1e-4)


if __name__ == "__main__":
    unittest.main()
