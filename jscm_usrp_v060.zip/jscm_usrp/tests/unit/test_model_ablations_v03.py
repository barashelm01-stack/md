from __future__ import annotations

import unittest

import torch

from jscm.models import JSCMSystem


class ModelAblationsV03Test(unittest.TestCase):
    def test_conv_only_forward_backward(self) -> None:
        model = JSCMSystem(
            reference_bitrate=6000,
            model_dim=32,
            ff_dim=64,
            num_heads=4,
            encoder_layers=1,
            decoder_layers=1,
            use_transformer=False,
        )
        waveform = torch.randn(1, 1, 16_000, requires_grad=True)
        output = model(waveform, 10.0, channel_mode="fm")
        self.assertEqual(output.shape, waveform.shape)
        output.square().mean().backward()
        self.assertTrue(torch.isfinite(waveform.grad).all())

    def test_snr_conditioning_shapes(self) -> None:
        model = JSCMSystem(
            reference_bitrate=6000,
            model_dim=32,
            ff_dim=64,
            num_heads=4,
            encoder_layers=1,
            decoder_layers=1,
            snr_conditioning=True,
        )
        waveform = torch.randn(2, 1, 16_000)
        packet_snr = torch.linspace(-5, 20, 100).reshape(2, 50)
        output = model(waveform, packet_snr, channel_mode="fm")
        self.assertEqual(output.shape, waveform.shape)
        bypass = model(waveform, None, channel_mode="bypass")
        self.assertEqual(bypass.shape, waveform.shape)


if __name__ == "__main__":
    unittest.main()
