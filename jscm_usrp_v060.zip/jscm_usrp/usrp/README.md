USRP device discovery, loopback, IQ recording and UHD monitoring utilities belong here.
