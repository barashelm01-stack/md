GNU Radio flowgraphs and custom blocks. See ../docs/GNURADIO_USRP_GUIDE.md.
