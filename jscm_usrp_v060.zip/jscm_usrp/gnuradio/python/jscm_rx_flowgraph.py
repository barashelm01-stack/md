"""GNU Radio flowgraph entry point placeholder.

Build this flowgraph on the target GNU Radio/UHD host. See docs/GNURADIO_USRP_GUIDE.md.
The neural/radio IPC and framing contracts are implemented; hardware-specific block
construction requires the installed GNU Radio and UHD versions.
"""
def main():
    raise RuntimeError("GNU Radio/UHD flowgraph must be generated on the radio host.")

if __name__ == "__main__":
    main()
