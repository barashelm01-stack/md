from __future__ import annotations
from pathlib import Path
import sys
_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(_ROOT / "src"))

import argparse
import json
from pathlib import Path

import torch

from jscm.experiment_utils import build_model_from_checkpoint


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Validate checkpoint and framework invariants without training")
    p.add_argument("--checkpoint", type=str, default="")
    p.add_argument("--system-spec", type=str, default="system_spec.json")
    return p.parse_args()


def main() -> None:
    args = parse_args()
    spec = json.loads(Path(args.system_spec).read_text(encoding="utf-8"))
    errors: list[str] = []
    if spec["source_frame_ms"] * spec["frames_per_segment"] != 1000:
        errors.append("source frame duration and frame count do not form one second")
    if spec["framing_overhead_symbols_per_packet"] != 56:
        errors.append("BLE-like framing overhead must be 56 symbols in this framework")
    report = {"system_spec": spec, "checkpoint": None, "errors": errors}
    if args.checkpoint:
        checkpoint = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
        model = build_model_from_checkpoint(checkpoint, torch.device("cpu"))
        payload = model.payload_symbols_per_frame
        expected = int(model.reference_bitrate * 0.02)
        if payload != expected:
            errors.append(f"payload symbols/frame {payload} != reference-rate budget {expected}")
        report["checkpoint"] = {
            "stage": checkpoint.get("stage"),
            "reference_bitrate": model.reference_bitrate,
            "payload_symbols_per_frame": payload,
            "header_symbols": model.channel.header_symbols,
            "samples_per_symbol": model.channel.samples_per_symbol,
            "snr_conditioning": model.snr_conditioning,
        }
    report["valid"] = not errors
    print(json.dumps(report, indent=2))
    if errors:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
