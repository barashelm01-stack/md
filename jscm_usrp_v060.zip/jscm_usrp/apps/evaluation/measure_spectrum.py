from __future__ import annotations
from pathlib import Path
import sys
_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(_ROOT / "src"))

import argparse
import csv
import json
from pathlib import Path

import numpy as np
import torch

from apps.evaluation.eval_opus_gfsk import create_opus_pair, pcm16_bytes
from jscm.ble_like import BLELikeBitFramer, bytes_to_bits_lsb
from jscm.experiment_utils import build_model_from_checkpoint, build_speech_dataset
from jscm.gfsk import gfsk_modulate
from jscm.spectrum import packet_spectrum_report


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Measure PSD, 99% occupied bandwidth and frequency deviation")
    p.add_argument("--checkpoint", required=True)
    p.add_argument("--test-manifest", required=True)
    p.add_argument("--output-dir", default="runs/spectrum_v032")
    p.add_argument("--segments", type=int, default=20)
    p.add_argument("--symbol-rate", type=float, default=1_000_000.0)
    p.add_argument("--occupied-fraction", type=float, default=0.99)
    p.add_argument("--seed", type=int, default=2026)
    p.add_argument("--skip-opus", action="store_true")
    p.add_argument("--bandwidth-tolerance", type=float, default=0.05, help="Relative 99% bandwidth mismatch allowed")
    return p.parse_args()


def write_psd(path: Path, frequencies: np.ndarray, psd: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer=csv.writer(f); writer.writerow(["frequency_hz","psd_power_per_hz"])
        writer.writerows(zip(frequencies.tolist(), psd.tolist(), strict=True))


def main() -> None:
    args=parse_args(); out=Path(args.output_dir); out.mkdir(parents=True,exist_ok=True)
    device=torch.device("cuda" if torch.cuda.is_available() else "cpu")
    checkpoint=torch.load(args.checkpoint,map_location=device,weights_only=False)
    model=build_model_from_checkpoint(checkpoint,device)
    dataset=build_speech_dataset(manifest_path=args.test_manifest,data_root=None,subset="test-clean",training=False,max_segments=args.segments,random_gain_db=0.0)
    fm_packets=[]; opus_packets=[]
    rng=np.random.default_rng(args.seed)
    for i in range(min(len(dataset),args.segments)):
        sample=dataset[i]; waveform=sample["waveform"].unsqueeze(0).to(device)
        with torch.no_grad():
            _,aux=model(waveform,None,channel_mode="bypass",return_aux=True)
            framed=model.channel.frame_payload(aux["bounded_payload"])
            tx=model.channel.modulate_packets(framed)
        fm_packets.extend([packet.reshape(-1) for packet in tx.detach().cpu().numpy()])
        if not args.skip_opus:
            encoder,_=create_opus_pair(model.reference_bitrate)
            waveform_np=sample["waveform"].squeeze(0).numpy()
            for start in range(0, waveform_np.size, 320):
                frame=waveform_np[start:start+320]
                packet=encoder.encode(pcm16_bytes(frame),frame.size)
                bits=BLELikeBitFramer().frame_bits(bytes_to_bits_lsb(packet))
                opus_packets.append(gfsk_modulate(bits,samples_per_symbol=model.channel.samples_per_symbol))
    sample_rate=args.symbol_rate*model.channel.samples_per_symbol
    reports={}
    report,freq,psd=packet_spectrum_report(fm_packets,sample_rate,args.occupied_fraction)
    report.update({"method":"jscm_fm","source_segments":min(len(dataset),args.segments),"symbol_rate_hz":args.symbol_rate})
    reports["jscm_fm"]=report; write_psd(out/"jscm_fm_psd.csv",freq,psd)
    if opus_packets:
        report,freq,psd=packet_spectrum_report(opus_packets,sample_rate,args.occupied_fraction)
        report.update({"method":"opus_gfsk","source_segments":len(opus_packets),"symbol_rate_hz":args.symbol_rate})
        reports["opus_gfsk"]=report; write_psd(out/"opus_gfsk_psd.csv",freq,psd)
        j_bw=float(reports["jscm_fm"]["occupied_bandwidth_hz"])
        o_bw=float(reports["opus_gfsk"]["occupied_bandwidth_hz"])
        mismatch=abs(j_bw-o_bw)/max(o_bw,1e-12)
        reports["bandwidth_comparison"]={
            "reference":"opus_gfsk",
            "relative_mismatch":mismatch,
            "tolerance":float(args.bandwidth_tolerance),
            "within_tolerance":bool(mismatch<=args.bandwidth_tolerance),
        }
    (out/"spectrum_report.json").write_text(json.dumps(reports,indent=2),encoding="utf-8")
    print(json.dumps(reports,indent=2))

if __name__=="__main__":
    main()
