from __future__ import annotations
from pathlib import Path
import sys
_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(_ROOT / "src"))

import argparse
import json
import time
from pathlib import Path
from typing import Callable

import torch

from jscm.losses import JSCMLoss
from jscm.models import JSCMSystem


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Profile JSCM training and streaming inference")
    parser.add_argument("--checkpoint", default="")
    parser.add_argument("--output", default="runs/profile/runtime_profile.json")
    parser.add_argument("--batch-size", type=int, default=50)
    parser.add_argument("--warmup", type=int, default=10)
    parser.add_argument("--iterations", type=int, default=50)
    parser.add_argument("--device", choices=["auto", "cpu", "cuda"], default="auto")
    parser.add_argument("--amp", action="store_true")
    parser.add_argument("--esn0-db", type=float, default=10.0)
    return parser.parse_args()


def synchronize(device: torch.device) -> None:
    if device.type == "cuda":
        torch.cuda.synchronize(device)


def benchmark(fn: Callable[[], None], warmup: int, iterations: int, device: torch.device) -> dict[str, float]:
    for _ in range(warmup):
        fn()
    synchronize(device)
    samples: list[float] = []
    for _ in range(iterations):
        start = time.perf_counter()
        fn()
        synchronize(device)
        samples.append((time.perf_counter() - start) * 1000.0)
    tensor = torch.tensor(samples, dtype=torch.float64)
    return {
        "mean_ms": float(tensor.mean()),
        "std_ms": float(tensor.std(unbiased=False)),
        "p50_ms": float(tensor.quantile(0.50)),
        "p95_ms": float(tensor.quantile(0.95)),
        "min_ms": float(tensor.min()),
        "max_ms": float(tensor.max()),
    }


def build_model(args: argparse.Namespace, device: torch.device) -> JSCMSystem:
    if args.checkpoint:
        checkpoint = torch.load(args.checkpoint, map_location=device, weights_only=False)
        from jscm.experiment_utils import build_model_from_checkpoint
        return build_model_from_checkpoint(checkpoint, device)
    return JSCMSystem(model_dim=64, encoder_layers=2, decoder_layers=2).to(device)


def main() -> None:
    args = parse_args()
    if args.device == "auto":
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    else:
        device = torch.device(args.device)
    model = build_model(args, device)
    criterion = JSCMLoss().to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=2e-4)
    clean = torch.randn(args.batch_size, 1, model.num_samples, device=device).clamp(-1, 1)
    valid = torch.full((args.batch_size,), model.num_samples, device=device, dtype=torch.long)
    autocast_enabled = bool(args.amp and device.type == "cuda")

    model.eval()
    with torch.no_grad():
        encode = lambda: model.backbone.encode(clean)
        tokens = model.backbone.encode(clean)
        raw = model.channel_mapper(tokens)
        channel = lambda: model.channel(raw.float(), args.esn0_db)
        received = model.channel(raw.float(), args.esn0_db)
        token_hat = model.channel_demapper(received)
        decode = lambda: model.backbone.decode(token_hat, model.num_samples)
        full = lambda: model(clean, args.esn0_db, channel_mode="fm")
        stream_state = model.init_stream_state(args.batch_size, device=device, dtype=clean.dtype)
        frame = clean[..., :320]
        def stream_call() -> None:
            nonlocal stream_state
            _, stream_state = model.stream_step(frame, stream_state, args.esn0_db)

        sections = {
            "encode": benchmark(encode, args.warmup, args.iterations, device),
            "channel": benchmark(channel, args.warmup, args.iterations, device),
            "decode": benchmark(decode, args.warmup, args.iterations, device),
            "full_inference_1s": benchmark(full, args.warmup, args.iterations, device),
            "stream_step_20ms": benchmark(stream_call, args.warmup, args.iterations, device),
        }

    model.train()
    def training_step() -> None:
        optimizer.zero_grad(set_to_none=True)
        with torch.autocast(device_type=device.type, dtype=torch.float16, enabled=autocast_enabled):
            estimate, aux = model(clean, args.esn0_db, channel_mode="fm", return_aux=True)
        with torch.autocast(device_type=device.type, enabled=False):
            loss, _ = criterion(estimate.float(), clean.float(), valid, aux)
        loss.backward()
        optimizer.step()

    sections["full_training_step"] = benchmark(training_step, max(2, args.warmup // 2), args.iterations, device)
    peak_memory = None
    if device.type == "cuda":
        peak_memory = int(torch.cuda.max_memory_allocated(device))
    report = {
        "device": str(device),
        "batch_size": args.batch_size,
        "iterations": args.iterations,
        "amp": autocast_enabled,
        "parameter_count": sum(parameter.numel() for parameter in model.parameters()),
        "peak_cuda_memory_bytes": peak_memory,
        "sections": sections,
    }
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
