from __future__ import annotations
from pathlib import Path
import sys
_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(_ROOT / "src"))

import argparse
from pathlib import Path

import numpy as np
import soundfile as sf

from jscm.experiment_utils import build_speech_dataset, write_csv_rows
from jscm.ble_like import BLELikeBitFramer, bits_to_bytes_lsb, bytes_to_bits_lsb
from jscm.gfsk import add_awgn_esn0, gfsk_demodulate, gfsk_modulate
from jscm.objective_metrics import MetricAccumulator, compute_objective_metrics, dependency_status
from jscm.resource_report import opus_resource_report, write_resource_report

try:
    import opuslib
except ImportError:
    opuslib = None


def bytes_to_bits(data: bytes) -> np.ndarray:
    return bytes_to_bits_lsb(data)


def bits_to_bytes(bits: np.ndarray) -> bytes:
    array = np.asarray(bits, dtype=np.uint8).reshape(-1)
    if array.size % 8:
        array = np.pad(array, (0, 8 - array.size % 8))
    return bits_to_bytes_lsb(array)


def ble_like_frame(payload: bytes) -> bytes:
    framer = BLELikeBitFramer()
    bits = framer.frame_bits(bytes_to_bits_lsb(payload))
    return bits_to_bytes_lsb(bits)

def pcm16_bytes(frame: np.ndarray) -> bytes:
    frame = np.clip(frame, -1.0, 1.0)
    return np.round(frame * 32767.0).astype("<i2").tobytes()


def bytes_to_pcm16(data: bytes, frame_size: int) -> np.ndarray:
    pcm = np.frombuffer(data, dtype="<i2").astype(np.float32) / 32768.0
    if pcm.size < frame_size:
        pcm = np.pad(pcm, (0, frame_size - pcm.size))
    return pcm[:frame_size]


def si_sdr_np(estimate: np.ndarray, target: np.ndarray) -> float:
    estimate = estimate.astype(np.float64) - float(np.mean(estimate))
    target = target.astype(np.float64) - float(np.mean(target))
    projection = np.dot(estimate, target) * target / (np.dot(target, target) + 1e-12)
    noise = estimate - projection
    return float(
        10.0
        * np.log10(
            (np.dot(projection, projection) + 1e-12)
            / (np.dot(noise, noise) + 1e-12)
        )
    )


def _set_opus_encoder_ctl(encoder, request, value: int) -> None:
    """Set an Opus encoder option through the low-level CTL API.

    opuslib 3.0.1 contains broken high-level setters for ``inband_fec`` and
    ``dtx``. Using ``encoder_ctl`` directly keeps the baseline deterministic
    across opuslib releases.
    """
    opuslib.api.encoder.encoder_ctl(encoder.encoder_state, request, int(value))


def create_opus_pair(bitrate: int):
    if opuslib is None:
        raise RuntimeError("Install opuslib first: pip install opuslib")
    if bitrate <= 0:
        raise ValueError("bitrate must be positive")

    encoder = opuslib.Encoder(16_000, 1, opuslib.APPLICATION_VOIP)
    decoder = opuslib.Decoder(16_000, 1)
    ctl = opuslib.api.ctl
    _set_opus_encoder_ctl(encoder, ctl.set_bitrate, bitrate)
    _set_opus_encoder_ctl(encoder, ctl.set_vbr, 0)
    _set_opus_encoder_ctl(encoder, ctl.set_inband_fec, 0)
    _set_opus_encoder_ctl(encoder, ctl.set_dtx, 0)
    _set_opus_encoder_ctl(encoder, ctl.set_complexity, 10)
    return encoder, decoder


def transmit_opus_frame(
    frame: np.ndarray,
    encoder,
    decoder,
    bitrate: int,
    esn0_db: float | None,
    rng: np.random.Generator,
    samples_per_symbol: int,
    framing_mode: str = "detected",
    max_sync_errors: int = 0,
    leading_idle_bits: int = 0,
) -> tuple[np.ndarray, int, int, int, bool]:
    frame_size = int(frame.size)
    _set_opus_encoder_ctl(encoder, opuslib.api.ctl.set_bitrate, bitrate)
    packet = encoder.encode(pcm16_bytes(frame), frame_size)
    framer = BLELikeBitFramer(max_sync_errors=max_sync_errors)
    payload_bits = bytes_to_bits_lsb(packet)
    tx_bits = framer.frame_bits(payload_bits)
    if leading_idle_bits:
        idle = np.zeros(int(leading_idle_bits), dtype=np.uint8)
        tx_bits = np.concatenate([idle, tx_bits])

    waveform = gfsk_modulate(tx_bits, samples_per_symbol=samples_per_symbol)
    noisy = waveform if esn0_db is None else add_awgn_esn0(
        waveform, esn0_db, rng, samples_per_symbol=samples_per_symbol
    )
    rx_bits, _ = gfsk_demodulate(
        noisy,
        tx_bits.size,
        samples_per_symbol=samples_per_symbol,
    )
    bit_errors = int(np.count_nonzero(tx_bits != rx_bits))

    if framing_mode == "oracle":
        payload_start = int(leading_idle_bits) + framer.overhead_bits
        recovered_payload_bits = rx_bits[payload_start : payload_start + payload_bits.size]
        frame_success = recovered_payload_bits.size == payload_bits.size
    elif framing_mode == "detected":
        result = framer.deframe_bits(rx_bits)
        frame_success = result.success and result.payload_length == payload_bits.size
        recovered_payload_bits = result.payload_bits if frame_success else np.empty(0, dtype=np.uint8)
    else:
        raise ValueError("framing_mode must be 'oracle' or 'detected'")
    corrupted_payload = bits_to_bytes_lsb(recovered_payload_bits) if frame_success else b""
    decode_failed = not frame_success
    try:
        decoded = decoder.decode(corrupted_payload, frame_size, decode_fec=False)
    except Exception:
        decode_failed = True
        try:
            decoded = decoder.decode(b"", frame_size, decode_fec=False)
        except Exception:
            decoded = bytes(frame_size * 2)
    return (
        bytes_to_pcm16(decoded, frame_size),
        bit_errors,
        int(tx_bits.size),
        len(packet) * 8,
        decode_failed,
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Evaluate Opus-only and Opus + BLE-like GFSK/AWGN"
    )
    parser.add_argument("--data-root", default="")
    parser.add_argument("--test-manifest", default="")
    parser.add_argument("--output-dir", default="runs/opus_v03")
    parser.add_argument("--bitrate", type=int, default=6000)
    parser.add_argument("--esn0-list", nargs="+", type=float, default=[0, 5, 10, 15, 20])
    parser.add_argument("--max-segments", type=int, default=1000)
    parser.add_argument("--samples-per-symbol", type=int, default=4)
    parser.add_argument("--save-examples", type=int, default=3)
    parser.add_argument("--framing-mode", choices=["oracle", "detected"], default="detected")
    parser.add_argument("--max-sync-errors", type=int, default=0)
    parser.add_argument("--leading-idle-bits", type=int, default=0)
    parser.add_argument("--seed", type=int, default=2026)
    return parser.parse_args()


def _codec_only_frame(frame: np.ndarray, encoder, decoder) -> tuple[np.ndarray, int, bool]:
    packet = encoder.encode(pcm16_bytes(frame), frame.size)
    failed = False
    try:
        decoded = decoder.decode(packet, frame.size, decode_fec=False)
    except Exception:
        failed = True
        decoded = bytes(frame.size * 2)
    return bytes_to_pcm16(decoded, frame.size), len(packet) * 8, failed


def evaluate_method(
    dataset,
    output_dir: Path,
    bitrate: int,
    samples_per_symbol: int,
    esn0_db: float | None,
    seed: int,
    save_examples: int,
    framing_mode: str = "detected",
    max_sync_errors: int = 0,
    leading_idle_bits: int = 0,
) -> tuple[dict[str, float | int | str | None], dict]:
    rng = np.random.default_rng(seed)
    objective = MetricAccumulator()
    total_errors = 0
    total_bits = 0
    total_payload_bits = 0
    total_frames = 0
    decode_failures = 0

    for item_index in range(len(dataset)):
        sample = dataset[item_index]
        valid_samples = int(sample["valid_samples"].item())
        clean_padded = sample["waveform"].squeeze(0).numpy()
        clean = clean_padded[:valid_samples]
        encoder, decoder = create_opus_pair(bitrate)
        reconstructed: list[np.ndarray] = []
        for start in range(0, clean_padded.size, 320):
            frame = clean_padded[start : start + 320]
            if esn0_db is None:
                decoded, payload_bits, failed = _codec_only_frame(frame, encoder, decoder)
                errors = 0
                bits = payload_bits
            else:
                decoded, errors, bits, payload_bits, failed = transmit_opus_frame(
                    frame,
                    encoder,
                    decoder,
                    bitrate,
                    float(esn0_db),
                    rng,
                    samples_per_symbol,
                    framing_mode=framing_mode,
                    max_sync_errors=max_sync_errors,
                    leading_idle_bits=leading_idle_bits,
                )
            reconstructed.append(decoded)
            total_errors += errors
            total_bits += bits
            total_payload_bits += payload_bits
            total_frames += 1
            decode_failures += int(failed)

        estimate = np.concatenate(reconstructed)[:valid_samples]
        objective.update(compute_objective_metrics(estimate, clean))
        if item_index < save_examples:
            suffix = "only" if esn0_db is None else f"gfsk_esn0_{esn0_db:g}"
            sf.write(output_dir / f"opus_{suffix}_{item_index:03d}.wav", estimate, 16_000)

    mean_payload = total_payload_bits / max(total_frames, 1)
    mean_total = total_bits / max(total_frames, 1)
    row: dict[str, float | int | str | None] = {
        "method": "opus_only" if esn0_db is None else "opus_gfsk",
        "channel_applied": int(esn0_db is not None),
        "reference_bitrate": bitrate,
        "esn0_db": esn0_db,
        "samples_per_symbol": samples_per_symbol,
        "framing_mode": ("none" if esn0_db is None else framing_mode),
        "segments": len(dataset),
        "payload_channel_uses_per_frame": mean_payload,
        "total_channel_uses_per_frame": mean_total,
        "payload_channel_uses_per_second": mean_payload * 50.0,
        "total_channel_uses_per_second": mean_total * 50.0,
        **objective.mean(),
        "ber": total_errors / max(total_bits, 1) if esn0_db is not None else float("nan"),
        "decode_failure_rate": decode_failures / max(total_frames, 1),
    }
    report = opus_resource_report(
        bitrate,
        samples_per_symbol,
        mean_payload_bits_per_frame=mean_payload,
        mean_total_bits_per_frame=(mean_total if esn0_db is not None else mean_payload + 56.0),
    )
    return row, report


def main() -> None:
    args = parse_args()
    if opuslib is None:
        raise SystemExit("Install opuslib and system libopus first")
    output_dir = Path(args.output_dir).expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    print(f"objective metric dependencies={dependency_status()}")
    dataset = build_speech_dataset(
        manifest_path=args.test_manifest or None,
        data_root=args.data_root or None,
        subset="test-clean",
        training=False,
        max_segments=args.max_segments,
        random_gain_db=0.0,
    )

    rows: list[dict[str, float | int | str | None]] = []
    opus_only, report = evaluate_method(
        dataset,
        output_dir,
        args.bitrate,
        args.samples_per_symbol,
        None,
        args.seed,
        args.save_examples,
    )
    rows.append(opus_only)
    for esn0_db in args.esn0_list:
        row, report = evaluate_method(
            dataset,
            output_dir,
            args.bitrate,
            args.samples_per_symbol,
            float(esn0_db),
            args.seed,
            args.save_examples,
            framing_mode=args.framing_mode,
            max_sync_errors=args.max_sync_errors,
            leading_idle_bits=args.leading_idle_bits,
        )
        rows.append(row)
        print(
            f"Es/N0={esn0_db:5.1f}dB BER={float(row['ber']):.6e} "
            f"fail={float(row['decode_failure_rate']):.4f} "
            f"PESQ={float(row.get('pesq_wb', float('nan'))):.3f} "
            f"STOI={float(row.get('stoi', float('nan'))):.3f} "
            f"SI-SDR={float(row.get('si_sdr_db', float('nan'))):.3f}dB"
        )

    write_csv_rows(rows, output_dir / "metrics.csv")
    write_resource_report(report, output_dir / "resource_report.json")


if __name__ == "__main__":
    main()
