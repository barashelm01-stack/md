from __future__ import annotations
from pathlib import Path
import sys
_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(_ROOT / "src"))

import argparse
import csv
import math
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt


METRICS: dict[str, tuple[str, str]] = {
    "waveform_distance": ("Waveform Distance", "Mean absolute waveform distance"),
    "segsnr_db": ("Segmental SNR", "SegSNR (dB)"),
    "pesq_wb": ("PESQ-WB", "PESQ-WB"),
    "si_sdr_db": ("SI-SDR", "SI-SDR (dB)"),
    "stft_distance": ("STFT Distance", "Multi-resolution STFT distance"),
    "stoi": ("STOI", "STOI"),
}

METHODS: dict[str, str] = {
    "jscm_fm": "Proposed JSCM-FM",
    "opus_gfsk": "Opus-GFSK",
}


def _to_float(value: Any) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return float("nan")


def read_rows(csv_path: str | Path) -> list[dict[str, str]]:
    with Path(csv_path).open("r", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def plot_metric_curves(
    rows: list[dict[str, Any]],
    output_dir: str | Path,
    formats: tuple[str, ...] = ("png",),
) -> list[Path]:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    generated: list[Path] = []

    for metric, (title, ylabel) in METRICS.items():
        fig, ax = plt.subplots(figsize=(6.4, 4.4))
        plotted = False
        for method, label in METHODS.items():
            points: list[tuple[float, float]] = []
            for row in rows:
                if row.get("method") != method:
                    continue
                snr = _to_float(row.get("esn0_db"))
                value = _to_float(row.get(metric))
                if math.isfinite(snr) and math.isfinite(value):
                    points.append((snr, value))
            points.sort(key=lambda item: item[0])
            if not points:
                continue
            x, y = zip(*points, strict=True)
            ax.plot(x, y, marker="o", linewidth=1.8, markersize=5, label=label)
            plotted = True

        ax.set_title(f"{title} vs. $E_s/N_0$")
        ax.set_xlabel("$E_s/N_0$ (dB)")
        ax.set_ylabel(ylabel)
        ax.grid(True, alpha=0.3)
        if plotted:
            ax.legend()
        else:
            ax.text(0.5, 0.5, "No finite JSCM-FM/Opus-GFSK data", ha="center", va="center", transform=ax.transAxes)
        fig.tight_layout()
        for extension in formats:
            path = output_dir / f"{metric}_vs_esn0.{extension}"
            fig.savefig(path, dpi=200, bbox_inches="tight")
            generated.append(path)
        plt.close(fig)
    return generated


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Plot Opus-GFSK and proposed JSCM-FM metric curves")
    parser.add_argument("--metrics-csv", required=True)
    parser.add_argument("--output-dir", default="figures")
    parser.add_argument("--formats", nargs="+", default=["png"], choices=["png", "pdf", "svg"])
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    paths = plot_metric_curves(read_rows(args.metrics_csv), args.output_dir, tuple(args.formats))
    for path in paths:
        print(path)


if __name__ == "__main__":
    main()
