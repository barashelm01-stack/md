from __future__ import annotations
from pathlib import Path
import sys
_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(_ROOT / "src"))

import torch

from jscm.channels import DifferentiableFMAWGN
from jscm.models import JSCMSystem


def main() -> None:
    torch.manual_seed(0)

    channel = DifferentiableFMAWGN(samples_per_symbol=4)
    payload = torch.randn(2, 3, 120, requires_grad=True)
    recovered = channel(payload, torch.full((2, 3), 20.0))
    assert recovered.shape == payload.shape
    recovered.square().mean().backward()
    assert payload.grad is not None and torch.isfinite(payload.grad).all()

    bounded = channel.bound_payload(payload.detach())
    noiseless = channel(payload.detach(), None)
    noiseless_mse = float((noiseless - bounded).square().mean())
    assert noiseless_mse < 1e-4, noiseless_mse

    model = JSCMSystem(
        reference_bitrate=6000,
        model_dim=32,
        ff_dim=64,
        num_heads=4,
        encoder_layers=1,
        decoder_layers=1,
        channel_sps=4,
    )
    waveform = torch.randn(1, 1, 16_000)
    output, aux = model(waveform, 10.0, return_aux=True)
    assert output.shape == waveform.shape
    assert torch.isfinite(output).all()
    assert abs(float(aux["tx_symbol_energy"].detach()) - 1.0) < 1e-5

    print("smoke test passed")
    print(f"output shape: {tuple(output.shape)}")
    print(f"FM noiseless MSE: {noiseless_mse:.3e}")
    print(f"symbol energy Es: {float(aux['tx_symbol_energy'].detach()):.6f}")
    print(f"channel uses/s: {model.channel_uses_per_second}")


if __name__ == "__main__":
    main()
