from __future__ import annotations
from pathlib import Path
import sys
_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(_ROOT / "src"))

import numpy as np
import torch

from jscm.channels import DifferentiableFMAWGN
from jscm.gfsk import add_awgn_esn0, gfsk_demodulate, gfsk_modulate, symbol_energy


def main() -> None:
    torch.manual_seed(2026)
    payload = torch.randn(2, 4, 120)
    print("FM calibration")
    for sps in (2, 4, 8):
        channel = DifferentiableFMAWGN(samples_per_symbol=sps)
        bounded = channel.bound_payload(payload)
        recovered, aux = channel(payload, None, return_aux=True)
        mse = float((recovered - bounded).square().mean())
        print(
            f"  SPS={sps}: noiseless MSE={mse:.3e}, "
            f"Es={float(aux['tx_symbol_energy']):.6f}"
        )

    rng = np.random.default_rng(2026)
    bits = rng.integers(0, 2, size=20_000, dtype=np.uint8)
    print("GFSK calibration")
    for sps in (2, 4, 8):
        tx = gfsk_modulate(bits, samples_per_symbol=sps)
        no_noise_bits, _ = gfsk_demodulate(tx, bits.size, samples_per_symbol=sps)
        no_noise_ber = float(np.mean(no_noise_bits != bits))
        noisy = add_awgn_esn0(
            tx,
            10.0,
            np.random.default_rng(2026),
            samples_per_symbol=sps,
        )
        noisy_bits, _ = gfsk_demodulate(noisy, bits.size, samples_per_symbol=sps)
        noisy_ber = float(np.mean(noisy_bits != bits))
        print(
            f"  SPS={sps}: noiseless BER={no_noise_ber:.3e}, "
            f"BER@10dB={noisy_ber:.3e}, Es={symbol_energy(tx, bits.size):.6f}"
        )


if __name__ == "__main__":
    main()
