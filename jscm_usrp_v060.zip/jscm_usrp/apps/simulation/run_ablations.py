from __future__ import annotations
from pathlib import Path
import sys
_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(_ROOT / "src"))

import argparse
import shlex
import subprocess
from pathlib import Path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Prepare or run the v0.3.1 ablations")
    parser.add_argument("--train-manifest", required=True)
    parser.add_argument("--val-manifest", required=True)
    parser.add_argument("--output-root", default="runs/ablations_v03")
    parser.add_argument("--epochs", type=int, default=20)
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--num-workers", type=int, default=4)
    parser.add_argument("--execute", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    common = [
        "python",
        "train_jscm.py",
        "--train-manifest",
        args.train_manifest,
        "--val-manifest",
        args.val_manifest,
        "--epochs",
        str(args.epochs),
        "--batch-size",
        str(args.batch_size),
        "--num-workers",
        str(args.num_workers),
    ]
    variants = {
        "base_curriculum": [],
        "direct_snr": ["--schedule", "direct"],
        "conv_only": ["--disable-transformer"],
        "snr_conditioned": ["--snr-conditioning"],
    }
    output_root = Path(args.output_root)
    for name, extra in variants.items():
        command = common + ["--output-dir", str(output_root / name)] + extra
        print(shlex.join(command))
        if args.execute:
            subprocess.run(command, check=True)


if __name__ == "__main__":
    main()
