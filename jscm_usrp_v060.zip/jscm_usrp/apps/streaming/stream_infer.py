from __future__ import annotations
from pathlib import Path
import sys
_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(_ROOT / "src"))

import argparse
from pathlib import Path

import numpy as np
import soundfile as sf
import torch

from jscm.experiment_utils import build_model_from_checkpoint


def parse_args() -> argparse.Namespace:
    parser=argparse.ArgumentParser(description="Stateful 20-ms JSCM streaming inference")
    parser.add_argument("--checkpoint",required=True)
    parser.add_argument("--input",required=True)
    parser.add_argument("--output",required=True)
    parser.add_argument("--esn0-db",type=float,default=10.0)
    parser.add_argument("--channel-mode",choices=["bypass","fm"],default="fm")
    parser.add_argument("--framing-mode",choices=["oracle","detected"],default="detected")
    return parser.parse_args()


def main() -> None:
    args=parse_args(); device=torch.device("cuda" if torch.cuda.is_available() else "cpu")
    checkpoint=torch.load(args.checkpoint,map_location=device,weights_only=False)
    model=build_model_from_checkpoint(checkpoint,device)
    waveform,sample_rate=sf.read(args.input,dtype="float32",always_2d=False)
    if sample_rate!=model.sample_rate:
        raise ValueError(f"Expected {model.sample_rate} Hz input, got {sample_rate}")
    if waveform.ndim==2:
        waveform=waveform.mean(axis=1)
    original_length=waveform.size; hop=model.sample_rate*model.frame_ms//1000
    pad=(-original_length)%hop
    if pad: waveform=np.pad(waveform,(0,pad))
    state=model.init_stream_state(1,device=device,dtype=next(model.parameters()).dtype)
    outputs=[]
    with torch.no_grad():
        for start in range(0,waveform.size,hop):
            frame=torch.from_numpy(waveform[start:start+hop]).view(1,1,hop).to(device)
            output,state=model.stream_step(
                frame,state,args.esn0_db,channel_mode=args.channel_mode,
                framing_mode=args.framing_mode,
            )
            outputs.append(output.squeeze().cpu().numpy())
    reconstructed=np.concatenate(outputs)[:original_length]
    path=Path(args.output); path.parent.mkdir(parents=True,exist_ok=True)
    sf.write(path,reconstructed,model.sample_rate)
    print(f"frames={state['frames_processed']} samples={original_length} output={path}")


if __name__=="__main__":
    main()
