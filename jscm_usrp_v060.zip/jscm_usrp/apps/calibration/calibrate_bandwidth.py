from __future__ import annotations
from pathlib import Path
import sys
_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(_ROOT / "src"))

import argparse
import json
from pathlib import Path

import numpy as np
import torch

from jscm.ble_like import BLELikeBitFramer
from jscm.experiment_utils import build_model_from_checkpoint, build_speech_dataset
from jscm.gfsk import gfsk_modulate
from jscm.spectrum import packet_spectrum_report


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Calibrate JSCM FM modulation index to GFSK 99% occupied bandwidth")
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--test-manifest", required=True)
    parser.add_argument("--output-dir", default="runs/bandwidth_calibration")
    parser.add_argument("--segments", type=int, default=20)
    parser.add_argument("--symbol-rate", type=float, default=1_000_000.0)
    parser.add_argument("--occupied-fraction", type=float, default=0.99)
    parser.add_argument("--min-index", type=float, default=0.1)
    parser.add_argument("--max-index", type=float, default=1.2)
    parser.add_argument("--candidates", type=int, default=23)
    parser.add_argument("--tolerance", type=float, default=0.05)
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--write-checkpoint", default="", help="Optional calibrated checkpoint output path")
    return parser.parse_args()


def collect_payloads(model, dataset, device: torch.device, limit: int) -> torch.Tensor:
    values=[]
    with torch.no_grad():
        for index in range(min(limit, len(dataset))):
            waveform=dataset[index]["waveform"].unsqueeze(0).to(device)
            tokens=model.backbone.encode(waveform)
            values.append(model.channel.bound_payload(model.channel_mapper(tokens).float()).cpu())
    if not values:
        raise RuntimeError("No payloads collected")
    return torch.cat(values, dim=0).to(device)


def main() -> None:
    args=parse_args(); output=Path(args.output_dir); output.mkdir(parents=True,exist_ok=True)
    device=torch.device("cuda" if torch.cuda.is_available() else "cpu")
    checkpoint=torch.load(args.checkpoint,map_location=device,weights_only=False)
    model=build_model_from_checkpoint(checkpoint,device)
    dataset=build_speech_dataset(manifest_path=args.test_manifest,data_root=None,subset="test-clean",training=False,max_segments=args.segments,random_gain_db=0.0)
    payloads=collect_payloads(model,dataset,device,args.segments)
    sample_rate=args.symbol_rate*model.channel.samples_per_symbol

    rng=np.random.default_rng(args.seed)
    bit_framer=BLELikeBitFramer()
    gfsk_packets=[]
    packet_count=payloads.shape[0]*payloads.shape[1]
    for _ in range(packet_count):
        payload_bits=rng.integers(0,2,size=model.payload_symbols_per_frame,dtype=np.uint8)
        packet_bits=bit_framer.frame_bits(payload_bits)
        gfsk_packets.append(gfsk_modulate(packet_bits,samples_per_symbol=model.channel.samples_per_symbol,bt=model.channel.bt,modulation_index=0.5))
    gfsk_report,_,_=packet_spectrum_report(gfsk_packets,sample_rate,args.occupied_fraction)
    target=float(gfsk_report["occupied_bandwidth_hz"])

    original=float(model.channel.modulation_index)
    records=[]
    candidates=np.linspace(args.min_index,args.max_index,args.candidates)
    framed=model.channel.frame_payload(payloads)
    for value in candidates:
        model.channel.modulation_index=float(value)
        with torch.no_grad():
            tx=model.channel.modulate_packets(framed).detach().cpu().numpy()
        packets=[packet.reshape(-1) for packet in tx]
        report,_,_=packet_spectrum_report(packets,sample_rate,args.occupied_fraction)
        bandwidth=float(report["occupied_bandwidth_hz"])
        mismatch=abs(bandwidth-target)/max(target,1e-12)
        records.append({"modulation_index":float(value),"occupied_bandwidth_hz":bandwidth,"relative_mismatch":mismatch})
    model.channel.modulation_index=original
    best=min(records,key=lambda item:item["relative_mismatch"])
    report={
        "target":"gfsk",
        "target_occupied_bandwidth_hz":target,
        "occupied_fraction":args.occupied_fraction,
        "original_modulation_index":original,
        "best":best,
        "tolerance":args.tolerance,
        "within_tolerance":bool(best["relative_mismatch"]<=args.tolerance),
        "candidates":records,
    }
    (output/"bandwidth_calibration.json").write_text(json.dumps(report,indent=2),encoding="utf-8")
    if args.write_checkpoint:
        updated=dict(checkpoint)
        updated_args=dict(updated.get("args",{}))
        updated_args["channel_modulation_index"]=float(best["modulation_index"])
        updated["args"]=updated_args
        updated["bandwidth_calibration"]=report
        path=Path(args.write_checkpoint); path.parent.mkdir(parents=True,exist_ok=True)
        torch.save(updated,path)
    print(json.dumps(report,indent=2))


if __name__=="__main__":
    main()
