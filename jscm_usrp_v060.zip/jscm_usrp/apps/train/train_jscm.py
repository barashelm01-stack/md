from __future__ import annotations
from pathlib import Path
import sys
_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(_ROOT / "src"))

import argparse
import json
import math
import random
import shutil
import time
from contextlib import contextmanager, nullcontext
from pathlib import Path
from typing import Any, Iterator

import numpy as np
import soundfile as sf
import torch
from torch.nn.utils import clip_grad_norm_
from torch.utils.data import DataLoader

from jscm.experiment_utils import (
    append_jsonl,
    build_speech_dataset,
    set_seed,
    write_csv_rows,
    capture_rng_state,
    restore_rng_state,
    validate_resume_config,
)
from jscm.losses import JSCMLoss
from jscm.metric_utils import aggregate_metric_records
from jscm.models import JSCMSystem
from jscm.objective_metrics import MetricAccumulator, compute_objective_metrics, dependency_status
from jscm.resource_report import jscm_resource_report, write_resource_report
from jscm.training_runtime import (
    accumulation_group_size,
    autocast_context,
    is_optimizer_step,
    make_grad_scaler,
    resolve_amp_config,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train FreqCodec-style JSCM v0.4.1")
    parser.add_argument("--data-root", type=str, default="")
    parser.add_argument("--train-manifest", type=str, default="")
    parser.add_argument("--val-manifest", type=str, default="")
    parser.add_argument("--output-dir", type=str, default="runs/jscm_v03")
    parser.add_argument("--epochs", type=int, default=20)
    parser.add_argument("--batch-size", type=int, default=50, help="Physical micro-batch size.")
    parser.add_argument("--gradient-accumulation-steps", type=int, default=2)
    parser.add_argument("--num-workers", type=int, default=4)
    parser.add_argument("--lr", type=float, default=2e-4)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument(
        "--reference-bitrate",
        "--target-bitrate",
        dest="reference_bitrate",
        type=int,
        default=6000,
        help="Opus reference bitrate; JSCM uses the same payload channel uses/s.",
    )
    parser.add_argument("--model-dim", type=int, default=64)
    parser.add_argument("--ff-dim", type=int, default=128)
    parser.add_argument("--num-heads", type=int, default=4)
    parser.add_argument("--encoder-layers", type=int, default=2)
    parser.add_argument("--decoder-layers", type=int, default=2)
    parser.add_argument("--channel-sps", type=int, default=4)
    parser.add_argument("--channel-bt", type=float, default=0.5)
    parser.add_argument("--channel-modulation-index", type=float, default=0.5)
    parser.add_argument("--channel-payload-peak", type=float, default=0.95)
    parser.add_argument("--disable-transformer", action="store_true")
    parser.add_argument("--snr-conditioning", action="store_true")
    parser.add_argument("--snr-condition-min-db", type=float, default=-20.0)
    parser.add_argument("--snr-condition-max-db", type=float, default=40.0)

    parser.add_argument("--schedule", choices=["curriculum", "direct"], default="curriculum")
    parser.add_argument("--pretrain-epochs", type=int, default=3)
    parser.add_argument("--fm-warmup-epochs", type=int, default=2)
    parser.add_argument("--mid-snr-epochs", type=int, default=3)
    parser.add_argument("--warmup-esn0", type=float, default=40.0)
    parser.add_argument("--mid-esn0-min", type=float, default=10.0)
    parser.add_argument("--mid-esn0-max", type=float, default=20.0)
    parser.add_argument("--esn0-min", type=float, default=-5.0)
    parser.add_argument("--esn0-max", type=float, default=20.0)
    parser.add_argument("--val-esn0", type=float, default=10.0, help="Deprecated single-SNR display point.")
    parser.add_argument("--val-esn0-list", nargs="+", type=float, default=[0, 5, 10, 15, 20], help="Validation Es/N0 points used for FM model selection.")
    parser.add_argument("--selection-snr-weights", nargs="+", type=float, default=[], help="Optional non-negative weights matching --val-esn0-list.")
    parser.add_argument("--objective-val-esn0", type=float, default=10.0, help="SNR at which expensive PESQ/STOI validation is evaluated.")

    parser.add_argument("--train-crops-per-entry", type=int, default=1)
    parser.add_argument("--max-val-segments", type=int, default=1000)
    parser.add_argument("--random-gain-db", type=float, default=6.0)
    parser.add_argument("--objective-val-segments", type=int, default=50)
    parser.add_argument("--save-example-count", type=int, default=3)
    parser.add_argument("--save-example-every", type=int, default=1)
    parser.add_argument("--log-interval", type=int, default=50)
    parser.add_argument("--amp", choices=["auto", "on", "off"], default="auto")
    parser.add_argument("--amp-dtype", choices=["float16", "bfloat16"], default="float16")
    parser.add_argument("--max-grad-norm", type=float, default=5.0)
    parser.add_argument("--full-validation-every", type=int, default=5,
                        help="Run the full multi-SNR validation every N epochs.")
    parser.add_argument("--quick-val-esn0", type=float, default=10.0,
                        help="Single validation SNR used between full validations.")
    parser.add_argument("--objective-validation-every", type=int, default=5,
                        help="Compute PESQ/STOI objective metrics every N epochs.")
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--resume", type=str, default="")
    args = parser.parse_args()
    args.use_transformer = not args.disable_transformer
    if args.gradient_accumulation_steps < 1:
        parser.error("--gradient-accumulation-steps must be >= 1")
    if args.full_validation_every < 1 or args.objective_validation_every < 1:
        parser.error("validation frequencies must be >= 1")
    return args


@contextmanager
def fixed_torch_rng(seed: int, device: torch.device) -> Iterator[None]:
    cpu_state = torch.random.get_rng_state()
    cuda_state = None
    if device.type == "cuda":
        cuda_state = torch.cuda.get_rng_state(device)
    try:
        torch.manual_seed(seed)
        if device.type == "cuda":
            torch.cuda.manual_seed(seed)
        yield
    finally:
        torch.random.set_rng_state(cpu_state)
        if cuda_state is not None:
            torch.cuda.set_rng_state(cuda_state, device)


def seed_worker(worker_id: int) -> None:
    worker_seed = torch.initial_seed() % (2**32)
    random.seed(worker_seed)
    np.random.seed(worker_seed)


def training_stage(epoch: int, args: argparse.Namespace) -> tuple[str, float, float]:
    if getattr(args, "schedule", "curriculum") == "direct":
        return "fm_direct", args.esn0_min, args.esn0_max
    if epoch < args.pretrain_epochs:
        return "bypass", float("nan"), float("nan")
    offset = epoch - args.pretrain_epochs
    if offset < args.fm_warmup_epochs:
        return "fm_warmup", args.warmup_esn0, args.warmup_esn0
    offset -= args.fm_warmup_epochs
    if offset < args.mid_snr_epochs:
        return "fm_mid", args.mid_esn0_min, args.mid_esn0_max
    return "fm_full", args.esn0_min, args.esn0_max


def weighted_validation_loss(
    metrics_by_snr: dict[float, dict[str, float | int]],
    snr_list: list[float],
    weights: list[float] | None = None,
) -> float:
    selected_weights = weights or [1.0] * len(snr_list)
    if len(selected_weights) != len(snr_list):
        raise ValueError("weights must match snr_list length")
    if any(weight < 0 for weight in selected_weights) or sum(selected_weights) <= 0:
        raise ValueError("weights must be non-negative with positive sum")
    return sum(
        float(weight) * float(metrics_by_snr[float(snr)]["loss"])
        for snr, weight in zip(snr_list, selected_weights, strict=True)
    ) / float(sum(selected_weights))


def sample_packet_esn0(
    batch_size: int,
    frames: int,
    low: float,
    high: float,
    device: torch.device,
) -> torch.Tensor:
    if low == high:
        return torch.full((batch_size, frames), low, device=device)
    return torch.empty(batch_size, frames, device=device).uniform_(low, high)


def save_checkpoint(
    path: Path,
    model: JSCMSystem,
    optimizer: torch.optim.Optimizer,
    scheduler: torch.optim.lr_scheduler.LRScheduler,
    epoch: int,
    best_pretrain_val: float,
    best_fm_val: float,
    stage: str,
    args: argparse.Namespace,
    data_generator: torch.Generator,
    scaler,
) -> None:
    torch.save(
        {
            "format_version": 3,
            "model": model.state_dict(),
            "optimizer": optimizer.state_dict(),
            "scheduler": scheduler.state_dict(),
            "scaler": scaler.state_dict(),
            "epoch": epoch,
            "best_pretrain_val": best_pretrain_val,
            "best_fm_val": best_fm_val,
            "stage": stage,
            "args": vars(args),
            "rng_state": capture_rng_state(),
            "data_generator_state": data_generator.get_state(),
        },
        path,
    )


def _save_examples(
    clean: torch.Tensor,
    estimate: torch.Tensor,
    valid_samples: torch.Tensor,
    output_dir: Path,
    prefix: str,
    count: int,
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    clean_np = clean.detach().cpu().numpy()
    estimate_np = estimate.detach().cpu().numpy()
    valid_np = valid_samples.detach().cpu().numpy()
    for index, (reference, reconstructed, valid) in enumerate(
        zip(clean_np, estimate_np, valid_np, strict=True)
    ):
        if index >= count:
            break
        valid = int(valid)
        sf.write(output_dir / f"{prefix}_{index:02d}_clean.wav", reference[0, :valid], 16_000)
        sf.write(
            output_dir / f"{prefix}_{index:02d}_reconstructed.wav",
            reconstructed[0, :valid],
            16_000,
        )


def run_validation(
    model: JSCMSystem,
    loader: DataLoader,
    criterion: JSCMLoss,
    device: torch.device,
    esn0_db: float | None,
    channel_mode: str,
    noise_seed: int,
    objective_segments: int = 0,
    example_dir: Path | None = None,
    example_count: int = 0,
    amp_config=None,
) -> dict[str, float | int]:
    model.eval()
    loss_records: list[dict[str, float]] = []
    objective = MetricAccumulator()
    processed_objective = 0
    examples_saved = False
    with fixed_torch_rng(noise_seed, device), torch.no_grad():
        for batch in loader:
            waveform = batch["waveform"].to(device, non_blocking=True)
            valid_samples = batch["valid_samples"].to(device, non_blocking=True)
            amp_ctx = autocast_context(amp_config, device) if amp_config is not None else nullcontext()
            with amp_ctx:
                estimate, aux = model(
                    waveform,
                    esn0_db,
                    channel_mode=channel_mode,
                    return_aux=True,
                )
            _, metrics = criterion(estimate.float(), waveform.float(), valid_samples, aux)
            loss_records.append(metrics)

            if example_dir is not None and not examples_saved and example_count > 0:
                _save_examples(
                    waveform,
                    estimate,
                    valid_samples,
                    example_dir,
                    channel_mode,
                    example_count,
                )
                examples_saved = True

            if processed_objective < objective_segments:
                clean_np = waveform.detach().cpu().numpy()
                estimate_np = estimate.detach().cpu().numpy()
                valid_np = valid_samples.detach().cpu().numpy()
                for clean_item, estimate_item, valid in zip(
                    clean_np, estimate_np, valid_np, strict=True
                ):
                    if processed_objective >= objective_segments:
                        break
                    valid = int(valid)
                    objective.update(
                        compute_objective_metrics(
                            estimate_item[0, :valid], clean_item[0, :valid], 16_000
                        )
                    )
                    processed_objective += 1

    result: dict[str, float | int] = dict(aggregate_metric_records(loss_records))
    if objective_segments > 0:
        result.update(objective.mean())
        result["objective_segments"] = processed_objective
    return result


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    output_dir = Path(args.output_dir).expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    if not args.resume:
        for stale_name in (
            "train_steps.jsonl",
            "epoch_metrics.jsonl",
            "epoch_metrics.csv",
        ):
            stale_path = output_dir / stale_name
            if stale_path.exists():
                stale_path.unlink()
    (output_dir / "config.json").write_text(json.dumps(vars(args), indent=2), encoding="utf-8")
    print(f"objective metric dependencies={dependency_status()}")

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if device.type == "cuda":
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True
    amp_config = resolve_amp_config(args.amp, args.amp_dtype, device)
    scaler = make_grad_scaler(amp_config)
    effective_batch_size = args.batch_size * args.gradient_accumulation_steps
    print(
        f"device={device} amp={amp_config.enabled} amp_dtype={args.amp_dtype} "
        f"physical_batch={args.batch_size} accumulation={args.gradient_accumulation_steps} "
        f"effective_batch={effective_batch_size}"
    )

    train_set = build_speech_dataset(
        manifest_path=args.train_manifest or None,
        data_root=args.data_root or None,
        subset="train-clean-100",
        training=True,
        crops_per_entry=args.train_crops_per_entry,
        random_gain_db=args.random_gain_db,
        seed=args.seed,
    )
    val_set = build_speech_dataset(
        manifest_path=args.val_manifest or None,
        data_root=args.data_root or None,
        subset="dev-clean",
        training=False,
        max_segments=args.max_val_segments,
        random_gain_db=0.0,
        seed=args.seed + 1,
    )
    generator = torch.Generator().manual_seed(args.seed)
    train_loader = DataLoader(
        train_set,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.num_workers,
        pin_memory=device.type == "cuda",
        drop_last=False,
        persistent_workers=False,
        worker_init_fn=seed_worker,
        generator=generator,
    )
    val_loader = DataLoader(
        val_set,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,
        pin_memory=device.type == "cuda",
        persistent_workers=False,
        worker_init_fn=seed_worker,
    )

    model = JSCMSystem(
        reference_bitrate=args.reference_bitrate,
        model_dim=args.model_dim,
        ff_dim=args.ff_dim,
        num_heads=args.num_heads,
        encoder_layers=args.encoder_layers,
        decoder_layers=args.decoder_layers,
        channel_sps=args.channel_sps,
        channel_bt=args.channel_bt,
        channel_modulation_index=args.channel_modulation_index,
        channel_payload_peak=args.channel_payload_peak,
        use_transformer=args.use_transformer,
        snr_conditioning=args.snr_conditioning,
        snr_condition_min_db=args.snr_condition_min_db,
        snr_condition_max_db=args.snr_condition_max_db,
    ).to(device)
    criterion = JSCMLoss().to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=max(args.epochs, 1))

    start_epoch = 0
    best_pretrain_val = float("inf")
    best_fm_val = float("inf")
    if args.resume:
        checkpoint = torch.load(args.resume, map_location=device, weights_only=False)
        validate_resume_config(
            checkpoint.get("args", {}), vars(args),
            ["reference_bitrate", "model_dim", "ff_dim", "num_heads",
             "encoder_layers", "decoder_layers", "channel_sps",
             "channel_bt", "channel_modulation_index", "channel_payload_peak",
             "disable_transformer", "snr_conditioning", "schedule",
             "gradient_accumulation_steps", "amp_dtype"],
        )
        model.load_state_dict(checkpoint["model"])
        optimizer.load_state_dict(checkpoint["optimizer"])
        if "scheduler" in checkpoint:
            scheduler.load_state_dict(checkpoint["scheduler"])
        if "scaler" in checkpoint:
            scaler.load_state_dict(checkpoint["scaler"])
        start_epoch = int(checkpoint["epoch"]) + 1
        best_pretrain_val = float(checkpoint.get("best_pretrain_val", float("inf")))
        best_fm_val = float(checkpoint.get("best_fm_val", float("inf")))
        restore_rng_state(checkpoint.get("rng_state"))
        if "data_generator_state" in checkpoint:
            generator.set_state(checkpoint["data_generator_state"])

    parameter_count = sum(parameter.numel() for parameter in model.parameters())
    resource = jscm_resource_report(model)
    resource["parameters"] = parameter_count
    resource["use_transformer"] = args.use_transformer
    resource["snr_conditioning"] = args.snr_conditioning
    resource["physical_batch_size"] = args.batch_size
    resource["gradient_accumulation_steps"] = args.gradient_accumulation_steps
    resource["effective_batch_size"] = effective_batch_size
    resource["amp_enabled"] = amp_config.enabled
    resource["amp_dtype"] = args.amp_dtype
    write_resource_report(resource, output_dir / "resource_report.json")
    print(json.dumps(resource, indent=2))

    epoch_rows: list[dict[str, Any]] = []
    history_path = output_dir / "epoch_metrics.jsonl"
    if args.resume and history_path.is_file():
        with history_path.open("r", encoding="utf-8") as history_file:
            for line in history_file:
                line = line.strip()
                if line:
                    epoch_rows.append(json.loads(line))
    for epoch in range(start_epoch, args.epochs):
        model.train()
        if hasattr(train_set, "set_epoch"):
            train_set.set_epoch(epoch)
        stage, esn0_low, esn0_high = training_stage(epoch, args)
        channel_mode = "bypass" if stage == "bypass" else "fm"
        epoch_records: list[dict[str, float]] = []
        epoch_start = time.time()

        optimizer.zero_grad(set_to_none=True)
        total_train_steps = len(train_loader)
        for step, batch in enumerate(train_loader):
            waveform = batch["waveform"].to(device, non_blocking=True)
            valid_samples = batch["valid_samples"].to(device, non_blocking=True)
            packet_esn0 = None
            if channel_mode == "fm":
                packet_esn0 = sample_packet_esn0(
                    waveform.shape[0], model.num_frames, esn0_low, esn0_high, device
                )

            group_size = accumulation_group_size(
                step, total_train_steps, args.gradient_accumulation_steps
            )
            with autocast_context(amp_config, device):
                estimate, aux = model(
                    waveform,
                    packet_esn0,
                    channel_mode=channel_mode,
                    return_aux=True,
                )
            loss, metrics = criterion(estimate.float(), waveform.float(), valid_samples, aux)
            backward_loss = loss / float(group_size)
            scaler.scale(backward_loss).backward()
            metrics["gradient_norm"] = 0.0
            if is_optimizer_step(step, total_train_steps, args.gradient_accumulation_steps):
                scaler.unscale_(optimizer)
                gradient_norm = clip_grad_norm_(model.parameters(), max_norm=args.max_grad_norm)
                if not torch.isfinite(gradient_norm):
                    raise FloatingPointError(
                        f"Non-finite gradient norm at epoch={epoch}, step={step}"
                    )
                metrics["gradient_norm"] = float(gradient_norm.detach())
                scaler.step(optimizer)
                scaler.update()
                optimizer.zero_grad(set_to_none=True)
            epoch_records.append(metrics)

            if step % args.log_interval == 0:
                esn0_text = "bypass"
                if packet_esn0 is not None:
                    esn0_text = f"[{packet_esn0.min().item():.1f},{packet_esn0.max().item():.1f}]dB"
                step_record = {
                    "epoch": epoch,
                    "step": step,
                    "stage": stage,
                    "lr": optimizer.param_groups[0]["lr"],
                    "esn0": esn0_text,
                    "physical_batch_size": args.batch_size,
                    "gradient_accumulation_steps": args.gradient_accumulation_steps,
                    "effective_batch_size": effective_batch_size,
                    "amp_enabled": amp_config.enabled,
                    "amp_dtype": args.amp_dtype,
                    **metrics,
                }
                append_jsonl(step_record, output_dir / "train_steps.jsonl")
                print(
                    f"epoch={epoch:03d} step={step:05d} stage={stage} "
                    f"loss={metrics['loss']:.4f} l1={metrics['l1']:.4f} "
                    f"stft={metrics['stft']:.4f} sisdr={metrics['si_sdr_db']:.2f}dB "
                    f"latent_rms={metrics.get('latent_rms', float('nan')):.3f} "
                    f"sat={metrics.get('tanh_saturation_ratio', float('nan')):.3f} "
                    f"gain={metrics.get('output_input_rms_ratio', float('nan')):.3f} "
                    f"grad={metrics['gradient_norm']:.3f} EsN0={esn0_text}"
                )

        if not epoch_records:
            raise RuntimeError("Training loader produced no batches")
        scheduler.step()
        train_metrics = aggregate_metric_records(epoch_records)
        save_examples = (
            args.save_example_every > 0 and epoch % args.save_example_every == 0
        )
        epoch_example_dir = output_dir / "examples" / f"epoch_{epoch:03d}" if save_examples else None
        full_validation = ((epoch + 1) % args.full_validation_every == 0) or (epoch + 1 == args.epochs)
        objective_validation = ((epoch + 1) % args.objective_validation_every == 0) or (epoch + 1 == args.epochs)
        validate_bypass = stage == "bypass" or full_validation
        val_bypass = (
            run_validation(
                model,
                val_loader,
                criterion,
                device,
                esn0_db=None,
                channel_mode="bypass",
                noise_seed=args.seed + 10_000,
                objective_segments=(args.objective_val_segments if objective_validation else 0),
                example_dir=(epoch_example_dir / "bypass") if epoch_example_dir and objective_validation else None,
                example_count=(args.save_example_count if objective_validation else 0),
                amp_config=amp_config,
            )
            if validate_bypass else {}
        )
        if args.selection_snr_weights and len(args.selection_snr_weights) != len(args.val_esn0_list):
            raise ValueError("--selection-snr-weights must match --val-esn0-list length")
        weights = args.selection_snr_weights or [1.0] * len(args.val_esn0_list)
        if any(weight < 0 for weight in weights) or sum(weights) <= 0:
            raise ValueError("selection SNR weights must be non-negative with positive sum")
        validation_snr_list = (
            list(args.val_esn0_list) if full_validation else [float(args.quick_val_esn0)]
        )
        val_fm_by_snr: dict[float, dict[str, float | int]] = {}
        for snr_index, validation_esn0 in enumerate(validation_snr_list):
            compute_objective = (
                objective_validation
                and abs(validation_esn0 - args.objective_val_esn0) < 1e-9
            )
            val_fm_by_snr[float(validation_esn0)] = run_validation(
                model,
                val_loader,
                criterion,
                device,
                esn0_db=float(validation_esn0),
                channel_mode="fm",
                noise_seed=args.seed + 20_000 + snr_index,
                objective_segments=(args.objective_val_segments if compute_objective else 0),
                example_dir=(epoch_example_dir / f"fm_{validation_esn0:g}db") if epoch_example_dir and compute_objective else None,
                example_count=(args.save_example_count if compute_objective else 0),
                amp_config=amp_config,
            )
        if full_validation:
            val_fm_selection_loss = weighted_validation_loss(
                val_fm_by_snr, list(args.val_esn0_list), list(weights)
            )
        else:
            val_fm_selection_loss = float(val_fm_by_snr[float(args.quick_val_esn0)]["loss"])
        objective_key = min(validation_snr_list, key=lambda value: abs(value - args.objective_val_esn0))
        val_fm = val_fm_by_snr[float(objective_key)]
        elapsed = time.time() - epoch_start

        epoch_row: dict[str, Any] = {
            "epoch": epoch,
            "stage": stage,
            "elapsed_s": elapsed,
            "lr": optimizer.param_groups[0]["lr"],
            "physical_batch_size": args.batch_size,
            "gradient_accumulation_steps": args.gradient_accumulation_steps,
            "effective_batch_size": effective_batch_size,
            "amp_enabled": amp_config.enabled,
            "amp_dtype": args.amp_dtype,
            "full_validation": full_validation,
            "objective_validation": objective_validation,
        }
        epoch_row.update({f"train_{key}": value for key, value in train_metrics.items()})
        epoch_row.update({f"val_bypass_{key}": value for key, value in val_bypass.items()})
        epoch_row["val_fm_selection_loss"] = val_fm_selection_loss
        for validation_esn0, snr_metrics in val_fm_by_snr.items():
            epoch_row.update({
                f"val_fm_{validation_esn0:g}db_{key}": value
                for key, value in snr_metrics.items()
            })
        epoch_rows.append(epoch_row)
        write_csv_rows(epoch_rows, output_dir / "epoch_metrics.csv")
        append_jsonl(epoch_row, output_dir / "epoch_metrics.jsonl")

        print(
            f"epoch={epoch:03d} time={elapsed:.1f}s train_loss={train_metrics['loss']:.4f} "
            f"val_bypass={val_bypass.get('loss', float('nan')):.4f} "
            f"val_fm_multi={val_fm_selection_loss:.4f} "
            f"val_fm@{objective_key:g}dB={val_fm['loss']:.4f} "
            f"PESQ={val_fm.get('pesq_wb', float('nan')):.3f} "
            f"STOI={val_fm.get('stoi', float('nan')):.3f} "
            f"SI-SDR={val_fm.get('si_sdr_db', float('nan')):.2f}dB"
        )

        pretrain_is_best = (
            stage == "bypass" and val_bypass and float(val_bypass["loss"]) < best_pretrain_val
        )
        fm_is_best = (
            stage != "bypass" and full_validation and val_fm_selection_loss < best_fm_val
        )
        if pretrain_is_best:
            best_pretrain_val = float(val_bypass["loss"])
        if fm_is_best:
            best_fm_val = float(val_fm_selection_loss)

        save_checkpoint(
            output_dir / "last.pt",
            model,
            optimizer,
            scheduler,
            epoch,
            best_pretrain_val,
            best_fm_val,
            stage,
            args,
            generator,
            scaler,
        )
        if pretrain_is_best:
            shutil.copy2(output_dir / "last.pt", output_dir / "best_pretrain.pt")
        if fm_is_best:
            shutil.copy2(output_dir / "last.pt", output_dir / "best_fm.pt")


if __name__ == "__main__":
    main()
