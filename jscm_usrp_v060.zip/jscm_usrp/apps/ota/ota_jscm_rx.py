from __future__ import annotations
from pathlib import Path
import sys
_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(_ROOT / "src"))

import argparse
from pathlib import Path

import numpy as np
import soundfile as sf
import torch

from jscm.experiment_utils import load_checkpoint
from jscm.models import JSCMSystem
from jscm.radio_ipc import PacketReceiver
from jscm.radio_protocol import RadioMode


def main() -> None:
    p = argparse.ArgumentParser(description="Receive demodulated JSCM symbols from GNU Radio and decode speech.")
    p.add_argument("--checkpoint", required=True)
    p.add_argument("--output", required=True)
    p.add_argument("--endpoint", default="tcp://0.0.0.0:5556")
    p.add_argument("--frames", type=int, required=True)
    p.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = p.parse_args()
    checkpoint = load_checkpoint(args.checkpoint, map_location=args.device)
    config = checkpoint.get("model_config", checkpoint.get("config", {}))
    model = JSCMSystem(**{k: v for k, v in config.items() if k in JSCMSystem.__init__.__code__.co_varnames})
    model.load_state_dict(checkpoint["model"]); model.to(args.device).eval()
    receiver = PacketReceiver(args.endpoint, bind=True)
    state = model.init_decoder_stream_state(1, torch.device(args.device), next(model.parameters()).dtype)
    output = []
    try:
        with torch.inference_mode():
            for _ in range(args.frames):
                packet = receiver.recv()
                if packet.mode != RadioMode.JSCM_CONTINUOUS:
                    raise ValueError(f"Unexpected radio mode {packet.mode}")
                symbols = torch.from_numpy(packet.payload).view(1, 1, -1).to(args.device)
                frame, state = model.decode_source_stream(symbols, state)
                valid = int((packet.metadata or {}).get("valid_audio_samples", frame.shape[-1]))
                output.append(frame.squeeze().float().cpu().numpy()[:valid])
    finally:
        receiver.close()
    sf.write(Path(args.output), np.concatenate(output), model.sample_rate)

if __name__ == "__main__":
    main()
