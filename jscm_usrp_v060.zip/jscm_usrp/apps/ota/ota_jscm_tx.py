from __future__ import annotations
from pathlib import Path
import sys
_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(_ROOT / "src"))

import argparse
import time
from pathlib import Path

import numpy as np
import soundfile as sf
import torch

from jscm.experiment_utils import load_checkpoint
from jscm.models import JSCMSystem
from jscm.radio_ipc import PacketSender
from jscm.radio_protocol import RadioMode, RadioPacket


def main() -> None:
    p = argparse.ArgumentParser(description="Encode 20-ms speech frames and send continuous JSCM symbols to GNU Radio.")
    p.add_argument("--checkpoint", required=True)
    p.add_argument("--input", required=True)
    p.add_argument("--endpoint", default="tcp://127.0.0.1:5555")
    p.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = p.parse_args()
    checkpoint = load_checkpoint(args.checkpoint, map_location=args.device)
    config = checkpoint.get("model_config", checkpoint.get("config", {}))
    model = JSCMSystem(**{k: v for k, v in config.items() if k in JSCMSystem.__init__.__code__.co_varnames})
    model.load_state_dict(checkpoint["model"]); model.to(args.device).eval()
    audio, sr = sf.read(Path(args.input), dtype="float32", always_2d=False)
    if sr != model.sample_rate:
        raise ValueError(f"Expected {model.sample_rate} Hz audio, got {sr}")
    if audio.ndim > 1:
        audio = audio.mean(axis=1)
    frame_samples = model.sample_rate * model.frame_ms // 1000
    sender = PacketSender(args.endpoint, bind=False)
    state = model.init_encoder_stream_state(1, torch.device(args.device), next(model.parameters()).dtype)
    try:
        with torch.inference_mode():
            for sequence_id, start in enumerate(range(0, audio.size, frame_samples)):
                frame = np.zeros(frame_samples, dtype=np.float32)
                chunk = audio[start:start + frame_samples]; frame[:chunk.size] = chunk
                tensor = torch.from_numpy(frame).view(1, 1, -1).to(args.device)
                symbols, state = model.encode_source_stream(tensor, state)
                payload = symbols.squeeze(0).squeeze(0).float().cpu().numpy()
                sender.send(RadioPacket(RadioMode.JSCM_CONTINUOUS, sequence_id, payload,
                    sample_rate=model.sample_rate, timestamp_ns=time.time_ns(),
                    metadata={"valid_audio_samples": int(chunk.size)}))
    finally:
        sender.close()

if __name__ == "__main__":
    main()
