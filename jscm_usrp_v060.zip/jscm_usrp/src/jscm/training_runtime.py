from __future__ import annotations

from contextlib import nullcontext
from dataclasses import dataclass

import torch


@dataclass(frozen=True)
class AMPConfig:
    enabled: bool
    dtype: torch.dtype
    scaler_enabled: bool


def resolve_amp_config(mode: str, dtype_name: str, device: torch.device) -> AMPConfig:
    mode = mode.lower()
    if mode not in {"auto", "on", "off"}:
        raise ValueError("amp mode must be one of: auto, on, off")
    if dtype_name not in {"float16", "bfloat16"}:
        raise ValueError("amp dtype must be float16 or bfloat16")
    enabled = device.type == "cuda" and mode != "off"
    if mode == "on" and device.type != "cuda":
        raise RuntimeError("--amp on requires a CUDA device")
    dtype = torch.float16 if dtype_name == "float16" else torch.bfloat16
    # Gradient scaling is required for FP16, but not BF16.
    return AMPConfig(enabled=enabled, dtype=dtype, scaler_enabled=enabled and dtype == torch.float16)


def autocast_context(config: AMPConfig, device: torch.device):
    if not config.enabled:
        return nullcontext()
    return torch.autocast(device_type=device.type, dtype=config.dtype, enabled=True)


def make_grad_scaler(config: AMPConfig):
    try:
        return torch.amp.GradScaler("cuda", enabled=config.scaler_enabled)
    except (AttributeError, TypeError):
        return torch.cuda.amp.GradScaler(enabled=config.scaler_enabled)


def accumulation_group_size(step: int, total_steps: int, accumulation_steps: int) -> int:
    if accumulation_steps < 1:
        raise ValueError("gradient accumulation steps must be >= 1")
    group_start = (step // accumulation_steps) * accumulation_steps
    return min(accumulation_steps, total_steps - group_start)


def is_optimizer_step(step: int, total_steps: int, accumulation_steps: int) -> bool:
    return ((step + 1) % accumulation_steps == 0) or (step + 1 == total_steps)
