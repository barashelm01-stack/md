from __future__ import annotations

from typing import Any

import torch
import torch.nn as nn
import torch.nn.functional as F


def valid_sample_mask(
    valid_samples: torch.Tensor | None,
    length: int,
    device: torch.device,
    dtype: torch.dtype,
    batch: int,
) -> torch.Tensor:
    if valid_samples is None:
        return torch.ones(batch, 1, length, device=device, dtype=dtype)
    valid_samples = valid_samples.to(device=device, dtype=torch.long)
    if valid_samples.shape != (batch,):
        raise ValueError(f"valid_samples must have shape [B], got {tuple(valid_samples.shape)}")
    positions = torch.arange(length, device=device)[None, :]
    return (positions < valid_samples[:, None]).to(dtype=dtype).unsqueeze(1)


class MultiResolutionSTFTLoss(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.configs = [(256, 64, 256), (512, 128, 512), (1024, 256, 1024)]
        for index, (_, _, win_length) in enumerate(self.configs):
            self.register_buffer(f"window_{index}", torch.hann_window(win_length), persistent=False)

    def _magnitude(self, x: torch.Tensor, index: int) -> torch.Tensor:
        n_fft, hop_length, win_length = self.configs[index]
        window = getattr(self, f"window_{index}")
        spec = torch.stft(
            x,
            n_fft=n_fft,
            hop_length=hop_length,
            win_length=win_length,
            window=window,
            center=True,
            return_complex=True,
        )
        return spec.abs().clamp_min(1e-7)

    def forward(self, estimate: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        estimate = estimate.squeeze(1)
        target = target.squeeze(1)
        total = estimate.new_tensor(0.0)
        for index in range(len(self.configs)):
            est_mag = self._magnitude(estimate, index)
            tgt_mag = self._magnitude(target, index)
            spectral_convergence = torch.linalg.vector_norm(tgt_mag - est_mag) / (
                torch.linalg.vector_norm(tgt_mag) + 1e-7
            )
            log_magnitude = F.l1_loss(torch.log(est_mag), torch.log(tgt_mag))
            total = total + spectral_convergence + log_magnitude
        return total / len(self.configs)


def masked_si_sdr(
    estimate: torch.Tensor,
    target: torch.Tensor,
    mask: torch.Tensor,
    eps: float = 1e-8,
) -> torch.Tensor:
    estimate = estimate.squeeze(1)
    target = target.squeeze(1)
    mask = mask.squeeze(1)
    count = mask.sum(dim=-1, keepdim=True).clamp_min(1.0)

    estimate_mean = (estimate * mask).sum(dim=-1, keepdim=True) / count
    target_mean = (target * mask).sum(dim=-1, keepdim=True) / count
    estimate = (estimate - estimate_mean) * mask
    target = (target - target_mean) * mask

    projection = (estimate * target).sum(dim=-1, keepdim=True) * target
    projection = projection / (target.square().sum(dim=-1, keepdim=True) + eps)
    noise = estimate - projection
    ratio = projection.square().sum(dim=-1) / (noise.square().sum(dim=-1) + eps)
    return 10.0 * torch.log10(ratio + eps)


class JSCMLoss(nn.Module):
    def __init__(
        self,
        stft_weight: float = 0.5,
        sisdr_weight: float = 0.05,
        latent_weight: float = 0.01,
        latent_target_rms: float = 0.4,
    ) -> None:
        super().__init__()
        self.stft = MultiResolutionSTFTLoss()
        self.stft_weight = float(stft_weight)
        self.sisdr_weight = float(sisdr_weight)
        self.latent_weight = float(latent_weight)
        self.latent_target_rms = float(latent_target_rms)

    def forward(
        self,
        estimate: torch.Tensor,
        target: torch.Tensor,
        valid_samples: torch.Tensor | None = None,
        aux: dict[str, Any] | None = None,
    ) -> tuple[torch.Tensor, dict[str, float]]:
        if estimate.shape != target.shape:
            raise ValueError(f"Shape mismatch: {tuple(estimate.shape)} vs {tuple(target.shape)}")
        batch, _, length = target.shape
        mask = valid_sample_mask(
            valid_samples,
            length,
            target.device,
            target.dtype,
            batch,
        )
        estimate_masked = estimate * mask
        target_masked = target * mask

        valid_count = mask.sum().clamp_min(1.0)
        l1 = ((estimate - target).abs() * mask).sum() / valid_count
        input_rms = ((target.square() * mask).sum() / valid_count).sqrt()
        output_rms = ((estimate.square() * mask).sum() / valid_count).sqrt()
        output_input_rms_ratio = output_rms / input_rms.clamp_min(1e-8)
        stft = self.stft(estimate_masked, target_masked)
        sisdr_value = masked_si_sdr(estimate, target, mask).mean()
        bounded_sisdr_loss = -torch.clamp(sisdr_value, -30.0, 30.0) / 30.0

        latent_loss = estimate.new_tensor(0.0)
        if aux is not None and "bounded_payload" in aux:
            latent_rms = aux["bounded_payload"].square().mean().sqrt()
            latent_loss = (latent_rms - self.latent_target_rms).square()

        total = (
            l1
            + self.stft_weight * stft
            + self.sisdr_weight * bounded_sisdr_loss
            + self.latent_weight * latent_loss
        )
        metrics = {
            "_num_samples": float(batch),
            "_num_valid_samples": float(mask.sum().detach()),
            "loss": float(total.detach()),
            "l1": float(l1.detach()),
            "stft": float(stft.detach()),
            "si_sdr_db": float(sisdr_value.detach()),
            "latent_loss": float(latent_loss.detach()),
            "input_rms": float(input_rms.detach()),
            "output_rms": float(output_rms.detach()),
            "output_input_rms_ratio": float(output_input_rms_ratio.detach()),
        }
        if aux is not None:
            for key in (
                "latent_mean",
                "latent_rms",
                "latent_peak",
                "tanh_saturation_ratio",
                "phase_increment_max",
                "phase_increment_limit",
            ):
                if key in aux:
                    value = aux[key]
                    metrics[key] = float(value.detach()) if torch.is_tensor(value) else float(value)
            if "tx_symbol_energy" in aux:
                value = aux["tx_symbol_energy"]
                metrics["tx_symbol_energy"] = (
                    float(value.detach()) if torch.is_tensor(value) else float(value)
                )
        return total, metrics
