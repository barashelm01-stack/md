from __future__ import annotations

from functools import lru_cache

import numpy as np


def gaussian_kernel(bt: float, samples_per_symbol: int, span_symbols: int = 4) -> np.ndarray:
    if bt <= 0:
        raise ValueError("bt must be positive")
    if samples_per_symbol < 1:
        raise ValueError("samples_per_symbol must be >= 1")
    half = span_symbols * samples_per_symbol / 2.0
    t = np.arange(-half, half + 1.0, dtype=np.float64) / samples_per_symbol
    kernel = np.exp(-2.0 * (np.pi * bt * t) ** 2 / np.log(2.0))
    return kernel / kernel.sum()


@lru_cache(maxsize=32)
def design_symbol_equalizer(
    bt: float,
    samples_per_symbol: int,
    span_symbols: int = 4,
    equalizer_taps: int = 7,
    regularization: float = 1e-8,
) -> np.ndarray:
    if equalizer_taps < 1 or equalizer_taps % 2 == 0:
        raise ValueError("equalizer_taps must be a positive odd integer")

    impulse_length = 65
    center = impulse_length // 2
    impulse = np.zeros(impulse_length, dtype=np.float64)
    impulse[center] = 1.0
    upsampled = np.repeat(impulse, samples_per_symbol)
    shaped = np.convolve(
        upsampled,
        gaussian_kernel(bt, samples_per_symbol, span_symbols),
        mode="same",
    )
    symbol_response = shaped[: impulse_length * samples_per_symbol].reshape(
        impulse_length, samples_per_symbol
    ).mean(axis=1)
    channel = symbol_response[center - 2 : center + 3]

    convolution_length = channel.size + equalizer_taps - 1
    matrix = np.zeros((convolution_length, equalizer_taps), dtype=np.float64)
    for column in range(equalizer_taps):
        matrix[column : column + channel.size, column] = channel
    target = np.zeros(convolution_length, dtype=np.float64)
    target[convolution_length // 2] = 1.0
    equalizer = np.linalg.solve(
        matrix.T @ matrix + regularization * np.eye(equalizer_taps),
        matrix.T @ target,
    )
    return 0.5 * (equalizer + equalizer[::-1])


def gfsk_modulate(
    bits: np.ndarray,
    samples_per_symbol: int = 4,
    bt: float = 0.5,
    modulation_index: float = 0.5,
    span_symbols: int = 4,
) -> np.ndarray:
    bits = np.asarray(bits, dtype=np.uint8).reshape(-1)
    if bits.size == 0:
        raise ValueError("bits must not be empty")
    nrz = 2.0 * bits.astype(np.float64) - 1.0
    upsampled = np.repeat(nrz, samples_per_symbol)
    shaped = np.convolve(
        upsampled,
        gaussian_kernel(bt, samples_per_symbol, span_symbols),
        mode="same",
    )
    phase = np.cumsum(np.pi * modulation_index * shaped / samples_per_symbol)
    # This gives exactly Es=1 for every channel symbol.
    return np.exp(1j * phase) / np.sqrt(samples_per_symbol)


def add_awgn_esn0(
    signal: np.ndarray,
    esn0_db: float,
    rng: np.random.Generator,
    samples_per_symbol: int = 4,
) -> np.ndarray:
    signal = np.asarray(signal, dtype=np.complex128)
    if samples_per_symbol < 1:
        raise ValueError("samples_per_symbol must be >= 1")
    # Signal energy is one per symbol. Dividing N0 by SPS makes the expected
    # accumulated noise energy over one symbol equal to N0.
    noise_power = 10.0 ** (-float(esn0_db) / 10.0) / samples_per_symbol
    noise = np.sqrt(noise_power / 2.0) * (
        rng.standard_normal(signal.shape) + 1j * rng.standard_normal(signal.shape)
    )
    return signal + noise


def gfsk_demodulate(
    signal: np.ndarray,
    num_symbols: int,
    samples_per_symbol: int = 4,
    bt: float = 0.5,
    modulation_index: float = 0.5,
    span_symbols: int = 4,
    equalizer_taps: int = 7,
) -> tuple[np.ndarray, np.ndarray]:
    signal = np.asarray(signal, dtype=np.complex128).reshape(-1)
    required_samples = num_symbols * samples_per_symbol
    if signal.size < required_samples:
        raise ValueError(
            f"Need at least {required_samples} samples for {num_symbols} symbols, got {signal.size}"
        )

    phase_difference = np.angle(signal[1:] * np.conj(signal[:-1]))
    phase_difference = np.concatenate([phase_difference[:1], phase_difference])
    soft_samples = phase_difference * samples_per_symbol / (np.pi * modulation_index)
    soft_symbols = soft_samples[:required_samples].reshape(
        num_symbols, samples_per_symbol
    ).mean(axis=1)
    equalizer = design_symbol_equalizer(
        bt,
        samples_per_symbol,
        span_symbols=span_symbols,
        equalizer_taps=equalizer_taps,
    )
    equalized = np.convolve(soft_symbols, equalizer, mode="same")
    bits = (equalized > 0.0).astype(np.uint8)
    return bits, equalized


def symbol_energy(signal: np.ndarray, num_symbols: int) -> float:
    if num_symbols <= 0:
        raise ValueError("num_symbols must be positive")
    return float(np.sum(np.abs(signal) ** 2) / num_symbols)
