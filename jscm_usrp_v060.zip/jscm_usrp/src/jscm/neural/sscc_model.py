"""Layered import facade for :mod:`jscm.sscc`."""
from jscm.sscc import *  # noqa: F401,F403
