"""Layered import facade for :mod:`jscm.losses`."""
from jscm.losses import *  # noqa: F401,F403
