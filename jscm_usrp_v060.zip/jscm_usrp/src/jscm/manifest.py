from __future__ import annotations

import json
import random
from collections import defaultdict, deque
from pathlib import Path
from typing import TypedDict

import soundfile as sf


class ManifestEntry(TypedDict, total=False):
    path: str
    utterance_id: str
    speaker_id: str
    start_sample: int | None
    num_samples: int
    valid_samples: int
    source_sample_rate: int
    source_num_samples: int


def _target_length(info: sf.SoundFile, target_sample_rate: int) -> int:
    return int(round(info.frames * target_sample_rate / info.samplerate))


def _speaker_id(path: Path) -> str:
    """Infer the LibriSpeech speaker ID from ``speaker/chapter/file`` layout."""
    if len(path.parents) >= 2:
        candidate = path.parent.parent.name
        if candidate:
            return candidate
    stem_parts = path.stem.split("-")
    return stem_parts[0] if stem_parts else path.stem


def read_manifest(path: str | Path) -> list[ManifestEntry]:
    manifest_path = Path(path).expanduser().resolve()
    entries: list[ManifestEntry] = []
    with manifest_path.open("r", encoding="utf-8") as file:
        for line_number, line in enumerate(file, start=1):
            line = line.strip()
            if not line:
                continue
            try:
                raw = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(
                    f"Invalid JSON in {manifest_path} at line {line_number}: {exc}"
                ) from exc
            if "path" not in raw or "utterance_id" not in raw:
                raise ValueError(
                    f"Manifest entry {line_number} must contain path and utterance_id"
                )
            audio_path = Path(raw["path"]).expanduser()
            if not audio_path.is_absolute():
                audio_path = (manifest_path.parent / audio_path).resolve()
            raw["path"] = str(audio_path)
            entries.append(raw)
    if not entries:
        raise ValueError(f"Manifest is empty: {manifest_path}")
    return entries


def write_manifest(entries: list[ManifestEntry], path: str | Path) -> None:
    manifest_path = Path(path).expanduser().resolve()
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    with manifest_path.open("w", encoding="utf-8") as file:
        for entry in entries:
            file.write(json.dumps(entry, ensure_ascii=False) + "\n")


def make_balanced_fixed_entries(
    files: list[Path],
    num_segments: int,
    target_sample_rate: int = 16_000,
    segment_samples: int = 16_000,
    seed: int = 2026,
) -> list[ManifestEntry]:
    """Create an exact-size, reproducible one-second manifest.

    Selection rules:
    - one segment at most from each utterance/file;
    - only utterances that contain a complete segment are eligible;
    - speakers are sampled in shuffled round-robin order;
    - the crop start is fixed by ``seed``.

    This avoids over-representing long utterances and ensures validation/test
    manifests remain identical between runs.
    """
    if num_segments <= 0:
        raise ValueError("num_segments must be positive")
    if segment_samples <= 0:
        raise ValueError("segment_samples must be positive")

    rng = random.Random(seed)
    grouped: dict[str, list[tuple[Path, sf.SoundFile, int]]] = defaultdict(list)
    for path in sorted(files):
        info = sf.info(path)
        target_length = _target_length(info, target_sample_rate)
        if target_length < segment_samples:
            continue
        grouped[_speaker_id(path)].append((path, info, target_length))

    eligible_count = sum(len(items) for items in grouped.values())
    if eligible_count < num_segments:
        raise ValueError(
            f"Requested {num_segments} complete segments, but only "
            f"{eligible_count} eligible utterances are available"
        )

    speaker_ids = sorted(grouped)
    rng.shuffle(speaker_ids)
    queues: dict[str, deque[tuple[Path, sf.SoundFile, int]]] = {}
    for speaker_id in speaker_ids:
        items = grouped[speaker_id]
        rng.shuffle(items)
        queues[speaker_id] = deque(items)

    selected: list[tuple[Path, sf.SoundFile, int]] = []
    while len(selected) < num_segments:
        made_progress = False
        for speaker_id in speaker_ids:
            queue = queues[speaker_id]
            if not queue:
                continue
            selected.append(queue.popleft())
            made_progress = True
            if len(selected) >= num_segments:
                break
        if not made_progress:
            raise RuntimeError("Speaker-balanced selection terminated unexpectedly")

    entries: list[ManifestEntry] = []
    for path, info, target_length in selected:
        max_start = target_length - segment_samples
        start = rng.randint(0, max_start) if max_start > 0 else 0
        entries.append(
            {
                "path": str(path.resolve()),
                "utterance_id": path.stem,
                "speaker_id": _speaker_id(path),
                "start_sample": int(start),
                "num_samples": int(segment_samples),
                "valid_samples": int(segment_samples),
                "source_sample_rate": int(info.samplerate),
                "source_num_samples": int(info.frames),
            }
        )
    return entries


def make_train_file_entries(
    files: list[Path],
    target_sample_rate: int = 16_000,
    max_hours: float | None = None,
    max_files: int | None = None,
    seed: int = 2026,
) -> list[ManifestEntry]:
    """Legacy random-crop manifest generator retained for compatibility."""
    if max_hours is not None and max_hours <= 0:
        raise ValueError("max_hours must be positive")
    if max_files is not None and max_files <= 0:
        raise ValueError("max_files must be positive")

    ordered = list(files)
    random.Random(seed).shuffle(ordered)
    entries: list[ManifestEntry] = []
    accumulated_seconds = 0.0
    for path in ordered:
        info = sf.info(path)
        target_length = _target_length(info, target_sample_rate)
        entries.append(
            {
                "path": str(path.resolve()),
                "utterance_id": path.stem,
                "speaker_id": _speaker_id(path),
                "start_sample": None,
                "num_samples": target_sample_rate,
                "source_sample_rate": int(info.samplerate),
                "source_num_samples": int(info.frames),
            }
        )
        accumulated_seconds += target_length / target_sample_rate
        if max_files is not None and len(entries) >= max_files:
            break
        if max_hours is not None and accumulated_seconds >= max_hours * 3600.0:
            break
    if not entries:
        raise ValueError("No training files were selected")
    return entries


def make_fixed_segment_entries(
    files: list[Path],
    target_sample_rate: int = 16_000,
    segment_samples: int = 16_000,
    max_segments: int | None = None,
) -> list[ManifestEntry]:
    """Legacy sequential segment generator retained for compatibility."""
    if segment_samples <= 0:
        raise ValueError("segment_samples must be positive")
    if max_segments is not None and max_segments <= 0:
        raise ValueError("max_segments must be positive")

    entries: list[ManifestEntry] = []
    for path in sorted(files):
        info = sf.info(path)
        target_length = max(_target_length(info, target_sample_rate), 1)
        for start in range(0, target_length, segment_samples):
            valid = min(segment_samples, target_length - start)
            entries.append(
                {
                    "path": str(path.resolve()),
                    "utterance_id": path.stem,
                    "speaker_id": _speaker_id(path),
                    "start_sample": int(start),
                    "num_samples": int(segment_samples),
                    "valid_samples": int(valid),
                    "source_sample_rate": int(info.samplerate),
                    "source_num_samples": int(info.frames),
                }
            )
            if max_segments is not None and len(entries) >= max_segments:
                return entries
    if not entries:
        raise ValueError("No fixed segments were generated")
    return entries


def manifest_summary(
    entries: list[ManifestEntry], target_sample_rate: int = 16_000
) -> dict[str, float | int]:
    fixed_segments = sum(entry.get("start_sample") is not None for entry in entries)
    source_seconds = 0.0
    seen_paths: set[str] = set()
    speakers: set[str] = set()
    segment_samples = 0
    for entry in entries:
        path = str(entry["path"])
        speakers.add(str(entry.get("speaker_id", _speaker_id(Path(path)))))
        if path not in seen_paths:
            seen_paths.add(path)
            sr = int(entry.get("source_sample_rate", target_sample_rate))
            frames = int(entry.get("source_num_samples", 0))
            if sr > 0 and frames > 0:
                source_seconds += frames / sr
        if entry.get("start_sample") is not None:
            segment_samples += int(entry.get("valid_samples", entry.get("num_samples", 0)))
    return {
        "entries": len(entries),
        "unique_files": len(seen_paths),
        "unique_speakers": len(speakers),
        "fixed_segments": fixed_segments,
        "random_crop_entries": len(entries) - fixed_segments,
        "source_hours": source_seconds / 3600.0,
        "fixed_segment_hours": segment_samples / target_sample_rate / 3600.0,
    }
