from __future__ import annotations

import struct
from dataclasses import dataclass

import numpy as np

from .radio_protocol import RadioMode

PREAMBLE = np.array([1, 0, 1, 0, 1, 0, 1, 0], dtype=np.uint8)
ACCESS_ADDRESS = np.unpackbits(np.array([0xD6, 0xBE, 0x89, 0x8E], dtype=np.uint8), bitorder="little")


def bits_to_bipolar(bits: np.ndarray) -> np.ndarray:
    return 2.0 * np.asarray(bits, dtype=np.float32) - 1.0


def _bytes_to_lsb_bits(data: bytes) -> np.ndarray:
    return np.unpackbits(np.frombuffer(data, dtype=np.uint8), bitorder="little")


def build_header(mode: RadioMode, sequence_id: int, payload_length: int) -> np.ndarray:
    if not 0 <= payload_length <= 65535:
        raise ValueError("payload_length must fit uint16")
    raw = struct.pack("<BBH", int(mode), int(sequence_id) & 0xFF, int(payload_length))
    return _bytes_to_lsb_bits(raw)


def parse_header(samples: np.ndarray) -> tuple[RadioMode, int, int]:
    hard = (np.asarray(samples) >= 0).astype(np.uint8)
    if hard.size < 32:
        raise ValueError("header is truncated")
    raw = np.packbits(hard[:32], bitorder="little").tobytes()
    mode, sequence_id, payload_length = struct.unpack("<BBH", raw)
    return RadioMode(mode), sequence_id, payload_length


@dataclass(frozen=True)
class FramedSymbols:
    symbols: np.ndarray
    overhead_symbols: int
    payload_symbols: int


def frame_continuous(payload: np.ndarray, sequence_id: int) -> FramedSymbols:
    payload = np.asarray(payload, dtype=np.float32).reshape(-1)
    sync = bits_to_bipolar(np.concatenate([PREAMBLE, ACCESS_ADDRESS]))
    header = bits_to_bipolar(build_header(RadioMode.JSCM_CONTINUOUS, sequence_id, payload.size))
    return FramedSymbols(np.concatenate([sync, header, payload]), sync.size + header.size, payload.size)


def frame_bits(payload_bits: np.ndarray, mode: RadioMode, sequence_id: int) -> FramedSymbols:
    if mode == RadioMode.JSCM_CONTINUOUS:
        raise ValueError("use frame_continuous for JSCM")
    payload_bits = np.asarray(payload_bits, dtype=np.uint8).reshape(-1)
    sync = bits_to_bipolar(np.concatenate([PREAMBLE, ACCESS_ADDRESS]))
    header = bits_to_bipolar(build_header(mode, sequence_id, payload_bits.size))
    return FramedSymbols(
        np.concatenate([sync, header, bits_to_bipolar(payload_bits)]),
        sync.size + header.size,
        payload_bits.size,
    )


def find_sync(samples: np.ndarray, max_errors: int = 2) -> int | None:
    samples = np.asarray(samples, dtype=np.float32).reshape(-1)
    reference = bits_to_bipolar(np.concatenate([PREAMBLE, ACCESS_ADDRESS]))
    if samples.size < reference.size:
        return None
    hard = np.where(samples >= 0, 1.0, -1.0)
    for offset in range(samples.size - reference.size + 1):
        errors = int(np.count_nonzero(hard[offset:offset + reference.size] != reference))
        if errors <= max_errors:
            return offset
    return None


def deframe_demodulated(samples: np.ndarray, max_sync_errors: int = 2):
    samples = np.asarray(samples, dtype=np.float32).reshape(-1)
    sync_len = PREAMBLE.size + ACCESS_ADDRESS.size
    header_len = 32
    start = find_sync(samples, max_sync_errors)
    if start is None:
        return None
    header_start = start + sync_len
    if samples.size < header_start + header_len:
        return None
    mode, sequence_id, payload_length = parse_header(samples[header_start:header_start + header_len])
    payload_start = header_start + header_len
    if samples.size < payload_start + payload_length:
        return None
    payload = samples[payload_start:payload_start + payload_length].copy()
    if mode != RadioMode.JSCM_CONTINUOUS:
        payload = (payload >= 0).astype(np.uint8)
    return mode, sequence_id, payload
