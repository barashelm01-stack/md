from __future__ import annotations

from typing import Any

import numpy as np


def welch_psd(
    signal: np.ndarray,
    sample_rate: float,
    nfft: int = 4096,
    segment_length: int = 2048,
    overlap: float = 0.5,
) -> tuple[np.ndarray, np.ndarray]:
    """Return centered Welch PSD with units of power/Hz."""
    x = np.asarray(signal, dtype=np.complex128).reshape(-1)
    if x.size < 8:
        raise ValueError("signal is too short for PSD estimation")
    segment_length = min(int(segment_length), x.size)
    if segment_length < 8:
        raise ValueError("segment_length must be >= 8")
    nfft = max(int(nfft), segment_length)
    hop = max(1, int(round(segment_length * (1.0 - overlap))))
    window = np.hanning(segment_length)
    window_energy = float(np.sum(window**2))
    starts = list(range(0, max(x.size - segment_length + 1, 1), hop))
    if not starts:
        starts = [0]
    spectra = []
    for start in starts:
        segment = x[start : start + segment_length]
        if segment.size < segment_length:
            segment = np.pad(segment, (0, segment_length - segment.size))
        fft = np.fft.fftshift(np.fft.fft(segment * window, n=nfft))
        spectra.append(np.abs(fft) ** 2 / (sample_rate * window_energy))
    psd = np.mean(np.stack(spectra, axis=0), axis=0)
    frequencies = np.fft.fftshift(np.fft.fftfreq(nfft, d=1.0 / sample_rate))
    return frequencies, psd


def occupied_bandwidth(
    frequencies: np.ndarray,
    psd: np.ndarray,
    fraction: float = 0.99,
) -> dict[str, float]:
    """Find the narrowest contiguous frequency interval containing `fraction` power."""
    f = np.asarray(frequencies, dtype=np.float64).reshape(-1)
    p = np.asarray(psd, dtype=np.float64).reshape(-1)
    if f.shape != p.shape or f.size < 2:
        raise ValueError("frequencies and psd must have matching non-trivial shapes")
    if not 0.0 < fraction < 1.0:
        raise ValueError("fraction must be in (0,1)")
    p = np.maximum(p, 0.0)
    total = float(p.sum())
    if total <= 0:
        raise ValueError("PSD has zero total power")
    cumulative = np.concatenate([[0.0], np.cumsum(p)])
    target = fraction * total
    best_left = 0
    best_right = f.size - 1
    right = 0
    for left in range(f.size):
        right = max(right, left)
        while right < f.size and cumulative[right + 1] - cumulative[left] < target:
            right += 1
        if right >= f.size:
            break
        if f[right] - f[left] < f[best_right] - f[best_left]:
            best_left, best_right = left, right
    return {
        "occupied_fraction": float(fraction),
        "occupied_bandwidth_hz": float(f[best_right] - f[best_left]),
        "occupied_low_hz": float(f[best_left]),
        "occupied_high_hz": float(f[best_right]),
        "occupied_center_hz": float(0.5 * (f[best_left] + f[best_right])),
    }


def papr_db(signal: np.ndarray) -> float:
    x = np.asarray(signal).reshape(-1)
    power = np.abs(x) ** 2
    mean_power = float(np.mean(power))
    if mean_power <= 0:
        return float("nan")
    return float(10.0 * np.log10(float(np.max(power)) / mean_power))


def instantaneous_frequency_stats(
    signal: np.ndarray,
    sample_rate: float,
) -> dict[str, float]:
    x = np.asarray(signal, dtype=np.complex128).reshape(-1)
    if x.size < 2:
        raise ValueError("signal needs at least two samples")
    phase_step = np.angle(x[1:] * np.conj(x[:-1]))
    frequency = phase_step * sample_rate / (2.0 * np.pi)
    abs_frequency = np.abs(frequency)
    return {
        "frequency_mean_hz": float(np.mean(frequency)),
        "frequency_std_hz": float(np.std(frequency)),
        "frequency_abs_mean_hz": float(np.mean(abs_frequency)),
        "frequency_abs_p95_hz": float(np.quantile(abs_frequency, 0.95)),
        "frequency_abs_p99_hz": float(np.quantile(abs_frequency, 0.99)),
        "frequency_abs_max_hz": float(np.max(abs_frequency)),
    }


def spectrum_report(
    signal: np.ndarray,
    sample_rate: float,
    occupied_fraction: float = 0.99,
    nfft: int = 4096,
    segment_length: int = 2048,
) -> tuple[dict[str, Any], np.ndarray, np.ndarray]:
    frequencies, psd = welch_psd(
        signal,
        sample_rate=sample_rate,
        nfft=nfft,
        segment_length=segment_length,
    )
    report: dict[str, Any] = {
        "sample_rate_hz": float(sample_rate),
        "num_samples": int(np.asarray(signal).size),
        "mean_sample_power": float(np.mean(np.abs(signal) ** 2)),
        "papr_db": papr_db(signal),
    }
    report.update(occupied_bandwidth(frequencies, psd, fraction=occupied_fraction))
    report.update(instantaneous_frequency_stats(signal, sample_rate))
    return report, frequencies, psd


def packet_spectrum_report(
    packets: list[np.ndarray],
    sample_rate: float,
    occupied_fraction: float = 0.99,
    nfft: int = 4096,
    segment_length: int = 2048,
) -> tuple[dict[str, Any], np.ndarray, np.ndarray]:
    """Average packet PSDs without introducing artificial inter-packet phase jumps."""
    if not packets:
        raise ValueError("packets must not be empty")
    psd_values: list[np.ndarray] = []
    frequency_values: list[np.ndarray] = []
    sample_power_sum = 0.0
    sample_count = 0
    peak_power = 0.0
    for packet in packets:
        x = np.asarray(packet, dtype=np.complex128).reshape(-1)
        if x.size < 8:
            continue
        f, p = welch_psd(x, sample_rate, nfft=nfft, segment_length=segment_length)
        psd_values.append(p)
        phase_step = np.angle(x[1:] * np.conj(x[:-1]))
        frequency_values.append(phase_step * sample_rate / (2.0 * np.pi))
        power = np.abs(x) ** 2
        sample_power_sum += float(power.sum())
        sample_count += int(power.size)
        peak_power = max(peak_power, float(power.max()))
    if not psd_values or sample_count == 0:
        raise ValueError("no valid packets for spectrum analysis")
    psd = np.mean(np.stack(psd_values, axis=0), axis=0)
    frequency = np.concatenate(frequency_values)
    abs_frequency = np.abs(frequency)
    mean_power = sample_power_sum / sample_count
    report: dict[str, Any] = {
        "sample_rate_hz": float(sample_rate),
        "num_packets": len(psd_values),
        "num_samples": sample_count,
        "mean_sample_power": mean_power,
        "papr_db": float(10.0 * np.log10(peak_power / mean_power)),
        "frequency_mean_hz": float(np.mean(frequency)),
        "frequency_std_hz": float(np.std(frequency)),
        "frequency_abs_mean_hz": float(np.mean(abs_frequency)),
        "frequency_abs_p95_hz": float(np.quantile(abs_frequency, 0.95)),
        "frequency_abs_p99_hz": float(np.quantile(abs_frequency, 0.99)),
        "frequency_abs_max_hz": float(np.max(abs_frequency)),
    }
    report.update(occupied_bandwidth(f, psd, fraction=occupied_fraction))
    return report, f, psd
