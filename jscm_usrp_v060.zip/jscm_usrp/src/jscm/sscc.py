from __future__ import annotations

import math
from typing import Any

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from .gfsk import add_awgn_esn0, gfsk_demodulate, gfsk_modulate, symbol_energy
from .ble_like import BLELikeBitFramer


def quantization_layout(reference_bitrate: int, frame_ms: int, quantizer_bits: int) -> tuple[int, int]:
    if quantizer_bits < 1 or quantizer_bits > 16:
        raise ValueError("quantizer_bits must be in [1,16]")
    bit_budget = int(round(reference_bitrate * frame_ms / 1000.0))
    latent_symbols = bit_budget // quantizer_bits
    used_bits = latent_symbols * quantizer_bits
    if latent_symbols < 1:
        raise ValueError("reference bitrate is too small for the selected quantizer")
    return latent_symbols, used_bits


def uniform_quantize_ste(x: torch.Tensor, bits: int) -> tuple[torch.Tensor, torch.Tensor]:
    """Symmetric [-1,1] uniform quantizer with straight-through gradients."""
    levels = 2**bits
    bounded = torch.tanh(x)
    index = torch.round((bounded + 1.0) * 0.5 * (levels - 1)).clamp(0, levels - 1)
    dequantized = 2.0 * index / (levels - 1) - 1.0
    ste = bounded + (dequantized - bounded).detach()
    return ste, index.to(torch.long)


def indices_to_bits(indices: np.ndarray, bits: int) -> np.ndarray:
    values = np.asarray(indices, dtype=np.uint32).reshape(-1)
    shifts = np.arange(bits - 1, -1, -1, dtype=np.uint32)
    return ((values[:, None] >> shifts[None, :]) & 1).astype(np.uint8).reshape(-1)


def bits_to_indices(bits_array: np.ndarray, bits: int) -> np.ndarray:
    values = np.asarray(bits_array, dtype=np.uint8).reshape(-1)
    if values.size % bits != 0:
        raise ValueError("bit count must be divisible by quantizer_bits")
    groups = values.reshape(-1, bits).astype(np.uint32)
    weights = (1 << np.arange(bits - 1, -1, -1, dtype=np.uint32))[None, :]
    return np.sum(groups * weights, axis=1).astype(np.int64)


class SSCCSystem(nn.Module):
    """Finite-rate digital baseline sharing the FreqCodec-style backbone."""

    def __init__(self, sample_rate: int = 16_000, seconds: float = 1.0,
                 frame_ms: int = 20, reference_bitrate: int = 6_000,
                 quantizer_bits: int = 6, model_dim: int = 64,
                 encoder_layers: int = 2, decoder_layers: int = 2,
                 num_heads: int = 4, ff_dim: int = 128,
                 use_transformer: bool = True) -> None:
        super().__init__()
        del num_heads, ff_dim
        from .freqcodec_backbone import FreqCodecBackbone
        self.sample_rate = int(sample_rate)
        self.num_samples = int(round(sample_rate * seconds))
        self.frame_ms = int(frame_ms)
        self.num_frames = int(round(1000.0 * seconds / frame_ms))
        self.reference_bitrate = int(reference_bitrate)
        self.quantizer_bits = int(quantizer_bits)
        self.latent_symbols_per_frame, self.used_payload_bits_per_frame = quantization_layout(
            reference_bitrate, frame_ms, quantizer_bits)
        self.unused_payload_bits_per_frame = int(round(reference_bitrate * frame_ms / 1000.0)) - self.used_payload_bits_per_frame
        self.use_transformer = bool(use_transformer)
        self.backbone = FreqCodecBackbone(sample_rate, frame_ms, model_dim,
            encoder_layers, decoder_layers, self.use_transformer)
        self.latent_mapper = nn.Linear(model_dim, self.latent_symbols_per_frame)
        self.latent_demapper = nn.Linear(self.latent_symbols_per_frame, model_dim)

    def encode_indices(self, waveform: torch.Tensor):
        tokens = self.backbone.encode(waveform)
        return uniform_quantize_ste(self.latent_mapper(tokens), self.quantizer_bits)

    def decode_quantized(self, quantized: torch.Tensor) -> torch.Tensor:
        return self.backbone.decode(self.latent_demapper(quantized), self.num_samples)

    def forward(self, waveform: torch.Tensor, return_aux: bool = False):
        quantized, indices = self.encode_indices(waveform)
        output = self.decode_quantized(quantized)
        if not return_aux:
            return output
        return output, {"bounded_payload": quantized, "quantizer_indices": indices,
            "latent_mean": quantized.mean(), "latent_rms": quantized.square().mean().sqrt(),
            "latent_peak": quantized.abs().amax(),
            "tanh_saturation_ratio": (quantized.abs() >= 1.0).float().mean()}

    def transmit_gfsk(self, waveform: torch.Tensor, esn0_db: float,
                      rng: np.random.Generator, samples_per_symbol: int = 4,
                      framing_mode: str = "detected", max_sync_errors: int = 0,
                      leading_idle_bits: int = 0):
        device, dtype = waveform.device, waveform.dtype
        with torch.no_grad():
            _, indices = self.encode_indices(waveform)
        indices_np = indices.detach().cpu().numpy(); received = np.empty_like(indices_np)
        total_errors = total_bits = 0; energy_values = []; frame_failures = 0
        for b in range(indices_np.shape[0]):
            for frame in range(indices_np.shape[1]):
                payload_bits = indices_to_bits(indices_np[b, frame], self.quantizer_bits)
                framer = BLELikeBitFramer(max_sync_errors=max_sync_errors)
                packet_bits = framer.frame_bits(payload_bits)
                if leading_idle_bits:
                    packet_bits = np.concatenate([np.zeros(int(leading_idle_bits), dtype=np.uint8), packet_bits])
                tx = gfsk_modulate(packet_bits, samples_per_symbol=samples_per_symbol)
                energy_values.append(symbol_energy(tx, packet_bits.size))
                rx = add_awgn_esn0(tx, esn0_db, rng, samples_per_symbol=samples_per_symbol)
                recovered_bits, _ = gfsk_demodulate(rx, packet_bits.size, samples_per_symbol=samples_per_symbol)
                total_errors += int(np.count_nonzero(recovered_bits != packet_bits)); total_bits += int(packet_bits.size)
                if framing_mode == "oracle":
                    start = int(leading_idle_bits) + framer.overhead_bits
                    recovered_payload = recovered_bits[start:start+payload_bits.size]
                    success = recovered_payload.size == payload_bits.size
                elif framing_mode == "detected":
                    result = framer.deframe_bits(recovered_bits)
                    success = result.success and result.payload_length == payload_bits.size
                    recovered_payload = result.payload_bits if success else np.zeros(payload_bits.size, dtype=np.uint8)
                else:
                    raise ValueError("framing_mode must be 'oracle' or 'detected'")
                frame_failures += int(not success)
                received[b, frame] = bits_to_indices(recovered_payload, self.quantizer_bits).reshape(indices_np.shape[-1])
        levels = 2**self.quantizer_bits
        quantized = 2.0 * torch.from_numpy(received).to(device=device, dtype=dtype)/(levels-1)-1.0
        return self.decode_quantized(quantized), {"ber": total_errors/max(total_bits,1),
            "bit_errors": float(total_errors), "total_bits": float(total_bits),
            "tx_symbol_energy": float(np.mean(energy_values)),
            "frame_failures": float(frame_failures),
            "total_frames": float(indices_np.shape[0] * indices_np.shape[1]),
            "frame_success_rate": 1.0 - frame_failures / max(indices_np.shape[0] * indices_np.shape[1], 1)}


    def init_encoder_stream_state(self, batch_size: int, device: torch.device | None = None,
                                  dtype: torch.dtype | None = None) -> dict[str, Any]:
        parameter = next(self.parameters())
        device = parameter.device if device is None else device
        dtype = parameter.dtype if dtype is None else dtype
        full = self.backbone.init_stream_state(batch_size, device, dtype)
        return {"analysis_context": full["analysis_context"], "tx": full["tx"], "frames_processed": 0}

    def init_decoder_stream_state(self, batch_size: int, device: torch.device | None = None,
                                  dtype: torch.dtype | None = None) -> dict[str, Any]:
        parameter = next(self.parameters())
        device = parameter.device if device is None else device
        dtype = parameter.dtype if dtype is None else dtype
        full = self.backbone.init_stream_state(batch_size, device, dtype)
        return {"rx": full["rx"], "frames_processed": 0}

    def encode_source_stream(self, waveform_frame: torch.Tensor, state: dict[str, Any]):
        expected = self.sample_rate * self.frame_ms // 1000
        if waveform_frame.ndim != 3 or waveform_frame.shape[1] != 1 or waveform_frame.shape[-1] != expected:
            raise ValueError(f"Expected [B,1,{expected}], got {tuple(waveform_frame.shape)}")
        backbone_state = {"analysis_context": state["analysis_context"], "tx": state["tx"], "rx": None}
        token, backbone_state = self.backbone.stream_encode(waveform_frame, backbone_state)
        quantized, indices = uniform_quantize_ste(self.latent_mapper(token), self.quantizer_bits)
        bits = [indices_to_bits(row.detach().cpu().numpy(), self.quantizer_bits) for row in indices[:, 0]]
        return np.stack(bits), {"analysis_context": backbone_state["analysis_context"], "tx": backbone_state["tx"],
            "frames_processed": int(state.get("frames_processed", 0)) + 1}

    def decode_source_stream(self, payload_bits: np.ndarray, state: dict[str, Any]):
        payload_bits = np.asarray(payload_bits, dtype=np.uint8)
        if payload_bits.ndim == 1:
            payload_bits = payload_bits[None, :]
        expected = self.used_payload_bits_per_frame
        if payload_bits.shape[1] != expected:
            raise ValueError(f"Expected {expected} payload bits, got {payload_bits.shape[1]}")
        indices = np.stack([bits_to_indices(row, self.quantizer_bits) for row in payload_bits])
        levels = 2 ** self.quantizer_bits
        parameter = next(self.parameters())
        quantized = 2.0 * torch.from_numpy(indices).to(device=parameter.device, dtype=parameter.dtype) / (levels - 1) - 1.0
        token = self.latent_demapper(quantized.unsqueeze(1))
        backbone_state = {"analysis_context": None, "tx": None, "rx": state["rx"]}
        frame, backbone_state = self.backbone.stream_decode(token, backbone_state)
        return frame, {"rx": backbone_state["rx"], "frames_processed": int(state.get("frames_processed", 0)) + 1}

    def init_stream_state(self, batch_size: int, device: torch.device | None = None,
                          dtype: torch.dtype | None = None) -> dict[str, Any]:
        parameter = next(self.parameters())
        device = parameter.device if device is None else device
        dtype = parameter.dtype if dtype is None else dtype
        return {"backbone": self.backbone.init_stream_state(batch_size, device, dtype), "frames_processed": 0}

    def stream_step(self, waveform_frame: torch.Tensor, state: dict[str, Any]):
        expected = self.sample_rate * self.frame_ms // 1000
        if waveform_frame.ndim != 3 or waveform_frame.shape[-1] != expected:
            raise ValueError(f"Expected [B,1,{expected}], got {tuple(waveform_frame.shape)}")
        token, backbone_state = self.backbone.stream_encode(waveform_frame, state["backbone"])
        quantized, indices = uniform_quantize_ste(self.latent_mapper(token), self.quantizer_bits)
        token_hat = self.latent_demapper(quantized)
        output, backbone_state = self.backbone.stream_decode(token_hat, backbone_state)
        return output, {"backbone": backbone_state, "frames_processed": int(state.get("frames_processed",0))+1}, indices

    def config(self) -> dict[str, Any]:
        return {"reference_bitrate": self.reference_bitrate, "quantizer_bits": self.quantizer_bits,
            "latent_symbols_per_frame": self.latent_symbols_per_frame,
            "used_payload_bits_per_frame": self.used_payload_bits_per_frame,
            "unused_payload_bits_per_frame": self.unused_payload_bits_per_frame,
            "model_dim": self.latent_demapper.out_features, "use_transformer": self.use_transformer,
            "backbone": "freqcodec_style_conv_gru"}

