"""Layered import facade for :mod:`jscm.resource_report`."""
from jscm.resource_report import *  # noqa: F401,F403
