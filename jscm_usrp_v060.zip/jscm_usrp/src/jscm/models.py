from __future__ import annotations

import math
from typing import Any

import torch
import torch.nn as nn

from .channel_impl import DifferentiableFMAWGN, expand_packet_esn0
from .freqcodec_backbone import FreqCodecBackbone


class JSCMSystem(nn.Module):
    """FreqCodec-style 16-kHz causal JSCM with packet-wise FM/AWGN.

    The implementation is fully editable PyTorch code. It follows the frequency-domain
    magnitude/phase design direction of FunCodec/FreqCodec, but does not vendor or claim
    binary compatibility with the upstream FunCodec implementation.
    """

    def __init__(
        self,
        sample_rate: int = 16_000,
        seconds: float = 1.0,
        frame_ms: int = 20,
        reference_bitrate: int = 6_000,
        model_dim: int = 96,
        encoder_layers: int = 2,
        decoder_layers: int = 3,
        num_heads: int = 4,
        ff_dim: int = 192,
        channel_sps: int = 4,
        channel_bt: float = 0.5,
        channel_modulation_index: float = 0.5,
        channel_payload_peak: float = 0.95,
        use_transformer: bool = True,
        snr_conditioning: bool = False,
        snr_condition_min_db: float = -20.0,
        snr_condition_max_db: float = 40.0,
        target_bitrate: int | None = None,
    ) -> None:
        super().__init__()
        del num_heads, ff_dim  # retained for checkpoint/CLI compatibility
        if target_bitrate is not None:
            reference_bitrate = int(target_bitrate)
        self.sample_rate = int(sample_rate)
        self.num_samples = int(round(sample_rate * seconds))
        self.frame_ms = int(frame_ms)
        self.num_frames = int(round(1000.0 * seconds / frame_ms))
        self.reference_bitrate = int(reference_bitrate)
        self.use_transformer = bool(use_transformer)  # legacy name: now enables Conv-GRU sequence model
        self.snr_conditioning = bool(snr_conditioning)
        self.snr_condition_min_db = float(snr_condition_min_db)
        self.snr_condition_max_db = float(snr_condition_max_db)
        self.payload_symbols_per_frame = int(round(reference_bitrate * frame_ms / 1000.0))
        self.backbone = FreqCodecBackbone(
            sample_rate=sample_rate, frame_ms=frame_ms, model_dim=model_dim,
            encoder_layers=encoder_layers, decoder_layers=decoder_layers,
            use_sequence_model=self.use_transformer,
        )
        self.channel_mapper = nn.Linear(model_dim, self.payload_symbols_per_frame)
        self.channel = DifferentiableFMAWGN(
            samples_per_symbol=channel_sps,
            bt=channel_bt,
            modulation_index=channel_modulation_index,
            payload_peak=channel_payload_peak,
        )
        self.channel_demapper = nn.Linear(self.payload_symbols_per_frame, model_dim)
        self.snr_embedding = (
            nn.Sequential(nn.Linear(1, model_dim), nn.SiLU(), nn.Linear(model_dim, model_dim))
            if self.snr_conditioning else None
        )

    @property
    def payload_channel_uses_per_second(self) -> int:
        return self.num_frames * self.payload_symbols_per_frame

    @property
    def channel_uses_per_second(self) -> int:
        return self.payload_channel_uses_per_second + self.num_frames * self.channel.header_symbols

    def forward(self, waveform: torch.Tensor, esn0_db: torch.Tensor | float | None,
                channel_mode: str = "fm", return_aux: bool = False,
                framing_mode: str = "oracle"):
        if waveform.ndim != 3 or waveform.shape[1] != 1 or waveform.shape[-1] != self.num_samples:
            raise ValueError(f"Expected [B,1,{self.num_samples}], got {tuple(waveform.shape)}")
        tokens = self.backbone.encode(waveform)
        if tokens.shape[1] != self.num_frames:
            raise RuntimeError(f"Expected {self.num_frames} tokens, got {tokens.shape[1]}")
        raw_payload = self.channel_mapper(tokens)
        # Keep the calibrated physical layer in FP32 even when the neural
        # backbone runs under CUDA autocast. Complex FM/phase operations are
        # more stable and more widely supported in FP32.
        with torch.autocast(device_type=raw_payload.device.type, enabled=False):
            raw_payload_fp32 = raw_payload.float()
            if channel_mode == "fm":
                received, channel_aux = self.channel(
                    raw_payload_fp32, esn0_db, return_aux=True, framing_mode=framing_mode
                )
            elif channel_mode == "bypass":
                bounded = self.channel.bound_payload(raw_payload_fp32)
                received = bounded
                channel_aux = {
                    "raw_payload": raw_payload_fp32,
                    "bounded_payload": bounded,
                    "tx_symbol_energy": raw_payload_fp32.new_tensor(float("nan")),
                    "phase_increment_max": raw_payload_fp32.new_tensor(0.0),
                    "phase_increment_limit": math.pi * self.channel.modulation_index
                        * self.channel.payload_peak / self.channel.samples_per_symbol,
                }
            else:
                raise ValueError(f"Unsupported channel_mode={channel_mode!r}")
        tokens_hat = self.channel_demapper(received)
        if self.snr_embedding is not None:
            value = self.snr_condition_max_db if esn0_db is None else esn0_db
            packet_snr = expand_packet_esn0(value, waveform.shape[0], self.num_frames, waveform.device)
            packet_snr = packet_snr.clamp(self.snr_condition_min_db, self.snr_condition_max_db)
            midpoint = 0.5 * (self.snr_condition_min_db + self.snr_condition_max_db)
            half_range = 0.5 * (self.snr_condition_max_db - self.snr_condition_min_db)
            tokens_hat = tokens_hat + self.snr_embedding(((packet_snr-midpoint)/half_range).unsqueeze(-1))
        output = self.backbone.decode(tokens_hat, self.num_samples)
        if not return_aux:
            return output
        raw, bounded = channel_aux["raw_payload"], channel_aux["bounded_payload"]
        return output, {
            **channel_aux,
            "latent_mean": bounded.mean(),
            "latent_rms": bounded.square().mean().sqrt(),
            "latent_peak": bounded.abs().amax(),
            "tanh_saturation_ratio": (raw.abs() > 2.0).float().mean(),
        }


    def init_encoder_stream_state(
        self, batch_size: int, device: torch.device | None = None, dtype: torch.dtype | None = None
    ) -> dict[str, Any]:
        parameter = next(self.parameters())
        device = parameter.device if device is None else device
        dtype = parameter.dtype if dtype is None else dtype
        full = self.backbone.init_stream_state(batch_size, device, dtype)
        return {
            "analysis_context": full["analysis_context"],
            "tx": full["tx"],
            "frames_processed": 0,
        }

    def init_decoder_stream_state(
        self, batch_size: int, device: torch.device | None = None, dtype: torch.dtype | None = None
    ) -> dict[str, Any]:
        parameter = next(self.parameters())
        device = parameter.device if device is None else device
        dtype = parameter.dtype if dtype is None else dtype
        full = self.backbone.init_stream_state(batch_size, device, dtype)
        return {"rx": full["rx"], "frames_processed": 0}

    def encode_source_stream(
        self, waveform_frame: torch.Tensor, state: dict[str, Any]
    ) -> tuple[torch.Tensor, dict[str, Any]]:
        expected = self.sample_rate * self.frame_ms // 1000
        if waveform_frame.ndim != 3 or waveform_frame.shape[1] != 1 or waveform_frame.shape[-1] != expected:
            raise ValueError(f"Expected [B,1,{expected}], got {tuple(waveform_frame.shape)}")
        backbone_state = {"analysis_context": state["analysis_context"], "tx": state["tx"], "rx": None}
        token, backbone_state = self.backbone.stream_encode(waveform_frame, backbone_state)
        raw = self.channel_mapper(token)
        symbols = self.channel.bound_payload(raw.float())
        return symbols, {
            "analysis_context": backbone_state["analysis_context"],
            "tx": backbone_state["tx"],
            "frames_processed": int(state.get("frames_processed", 0)) + 1,
        }

    def decode_source_stream(
        self, received_symbols: torch.Tensor, state: dict[str, Any], esn0_db: torch.Tensor | float | None = None
    ) -> tuple[torch.Tensor, dict[str, Any]]:
        if received_symbols.ndim != 3 or received_symbols.shape[1] != 1 or received_symbols.shape[-1] != self.payload_symbols_per_frame:
            raise ValueError(
                f"Expected [B,1,{self.payload_symbols_per_frame}], got {tuple(received_symbols.shape)}"
            )
        token_hat = self.channel_demapper(received_symbols.float())
        if self.snr_embedding is not None:
            value = self.snr_condition_max_db if esn0_db is None else esn0_db
            packet_snr = expand_packet_esn0(value, received_symbols.shape[0], 1, received_symbols.device)
            packet_snr = packet_snr.clamp(self.snr_condition_min_db, self.snr_condition_max_db)
            midpoint = 0.5 * (self.snr_condition_min_db + self.snr_condition_max_db)
            half_range = 0.5 * (self.snr_condition_max_db - self.snr_condition_min_db)
            token_hat = token_hat + self.snr_embedding(((packet_snr-midpoint)/half_range).unsqueeze(-1))
        backbone_state = {"analysis_context": None, "tx": None, "rx": state["rx"]}
        frame, backbone_state = self.backbone.stream_decode(token_hat, backbone_state)
        return frame, {"rx": backbone_state["rx"], "frames_processed": int(state.get("frames_processed", 0)) + 1}

    def init_stream_state(
        self,
        batch_size: int,
        device: torch.device | None = None,
        dtype: torch.dtype | None = None,
    ) -> dict[str, Any]:
        parameter = next(self.parameters())
        device = parameter.device if device is None else device
        dtype = parameter.dtype if dtype is None else dtype
        return {
            "backbone": self.backbone.init_stream_state(batch_size, device, dtype),
            "frames_processed": 0,
        }

    def stream_step(
        self,
        waveform_frame: torch.Tensor,
        state: dict[str, Any],
        esn0_db: torch.Tensor | float | None,
        channel_mode: str = "fm",
        framing_mode: str = "oracle",
        return_aux: bool = False,
    ):
        expected = self.sample_rate * self.frame_ms // 1000
        if waveform_frame.ndim != 3 or waveform_frame.shape[1] != 1 or waveform_frame.shape[-1] != expected:
            raise ValueError(f"Expected [B,1,{expected}], got {tuple(waveform_frame.shape)}")
        token, backbone_state = self.backbone.stream_encode(waveform_frame, state["backbone"])
        raw_payload = self.channel_mapper(token)
        with torch.autocast(device_type=raw_payload.device.type, enabled=False):
            raw_payload_fp32 = raw_payload.float()
            if channel_mode == "fm":
                received, channel_aux = self.channel(
                    raw_payload_fp32,
                    esn0_db,
                    return_aux=True,
                    framing_mode=framing_mode,
                )
            elif channel_mode == "bypass":
                bounded = self.channel.bound_payload(raw_payload_fp32)
                received = bounded
                channel_aux = {
                    "raw_payload": raw_payload_fp32,
                    "bounded_payload": bounded,
                    "frame_success": torch.ones(
                        waveform_frame.shape[0], 1, dtype=torch.bool, device=waveform_frame.device
                    ),
                    "frame_success_rate": raw_payload_fp32.new_tensor(1.0),
                }
            else:
                raise ValueError(f"Unsupported channel_mode={channel_mode!r}")
        token_hat = self.channel_demapper(received)
        if self.snr_embedding is not None:
            value = self.snr_condition_max_db if esn0_db is None else esn0_db
            packet_snr = expand_packet_esn0(value, waveform_frame.shape[0], 1, waveform_frame.device)
            packet_snr = packet_snr.clamp(self.snr_condition_min_db, self.snr_condition_max_db)
            midpoint = 0.5 * (self.snr_condition_min_db + self.snr_condition_max_db)
            half_range = 0.5 * (self.snr_condition_max_db - self.snr_condition_min_db)
            token_hat = token_hat + self.snr_embedding(((packet_snr-midpoint)/half_range).unsqueeze(-1))
        output_frame, backbone_state = self.backbone.stream_decode(token_hat, backbone_state)
        new_state = {
            "backbone": backbone_state,
            "frames_processed": int(state.get("frames_processed", 0)) + 1,
        }
        if not return_aux:
            return output_frame, new_state
        return output_frame, new_state, channel_aux

