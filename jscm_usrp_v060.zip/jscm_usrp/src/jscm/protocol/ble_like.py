"""Layered import facade for :mod:`jscm.ble_like`."""
from jscm.ble_like import *  # noqa: F401,F403
