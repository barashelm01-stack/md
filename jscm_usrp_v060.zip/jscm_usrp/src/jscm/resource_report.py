from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .models import JSCMSystem


def jscm_resource_report(model: JSCMSystem, symbol_rate: int = 1_000_000) -> dict[str, Any]:
    payload_per_frame = model.payload_symbols_per_frame
    overhead_per_frame = model.channel.header_symbols
    total_per_frame = payload_per_frame + overhead_per_frame
    packets_per_second = model.num_frames
    return {
        "method": "jscm_fm",
        "reference_bitrate": model.reference_bitrate,
        "frame_ms": model.frame_ms,
        "packets_per_second": packets_per_second,
        "payload_channel_uses_per_frame": payload_per_frame,
        "overhead_channel_uses_per_frame": overhead_per_frame,
        "total_channel_uses_per_frame": total_per_frame,
        "payload_channel_uses_per_second": payload_per_frame * packets_per_second,
        "total_channel_uses_per_second": total_per_frame * packets_per_second,
        "samples_per_symbol": model.channel.samples_per_symbol,
        "active_baseband_samples_per_source_second": (
            total_per_frame * packets_per_second * model.channel.samples_per_symbol
        ),
        "symbol_rate": symbol_rate,
        "active_baseband_sample_rate": symbol_rate * model.channel.samples_per_symbol,
        "rf_duty_cycle": total_per_frame * packets_per_second / symbol_rate,
        "bt": model.channel.bt,
        "modulation_index": model.channel.modulation_index,
        "payload_peak": model.channel.payload_peak,
        "nominal_symbol_energy": 1.0,
        "framing_modes": ["oracle", "detected"],
        "default_evaluation_framing_mode": "detected",
        "whitening": False,
        "crc": False,
    }


def opus_resource_report(
    bitrate: int,
    samples_per_symbol: int,
    mean_payload_bits_per_frame: float,
    mean_total_bits_per_frame: float,
    frame_ms: int = 20,
    symbol_rate: int = 1_000_000,
) -> dict[str, Any]:
    packets_per_second = int(round(1000 / frame_ms))
    return {
        "method": "opus_gfsk",
        "reference_bitrate": int(bitrate),
        "frame_ms": int(frame_ms),
        "packets_per_second": packets_per_second,
        "mean_payload_channel_uses_per_frame": float(mean_payload_bits_per_frame),
        "overhead_channel_uses_per_frame": 56,
        "mean_total_channel_uses_per_frame": float(mean_total_bits_per_frame),
        "mean_payload_channel_uses_per_second": (
            float(mean_payload_bits_per_frame) * packets_per_second
        ),
        "mean_total_channel_uses_per_second": (
            float(mean_total_bits_per_frame) * packets_per_second
        ),
        "samples_per_symbol": int(samples_per_symbol),
        "active_baseband_samples_per_source_second": (
            float(mean_total_bits_per_frame) * packets_per_second * samples_per_symbol
        ),
        "symbol_rate": symbol_rate,
        "active_baseband_sample_rate": symbol_rate * samples_per_symbol,
        "rf_duty_cycle": float(mean_total_bits_per_frame) * packets_per_second / symbol_rate,
        "bt": 0.5,
        "modulation_index": 0.5,
        "nominal_symbol_energy": 1.0,
        "framing_modes": ["oracle", "detected"],
        "default_evaluation_framing_mode": "detected",
        "whitening": False,
        "crc": False,
    }


def write_resource_report(report: dict[str, Any], path: str | Path) -> None:
    output_path = Path(path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(report, indent=2), encoding="utf-8")


def sscc_resource_report(model, samples_per_symbol: int = 4, symbol_rate: int = 1_000_000) -> dict[str, Any]:
    payload = int(model.used_payload_bits_per_frame)
    overhead = 56
    total = payload + overhead
    return {
        "method": "sscc_gfsk",
        "reference_bitrate": int(model.reference_bitrate),
        "quantizer_bits": int(model.quantizer_bits),
        "latent_symbols_per_frame": int(model.latent_symbols_per_frame),
        "used_payload_bits_per_frame": payload,
        "unused_payload_bits_per_frame": int(model.unused_payload_bits_per_frame),
        "overhead_channel_uses_per_frame": overhead,
        "total_channel_uses_per_frame": total,
        "total_channel_uses_per_second": total * 50,
        "samples_per_symbol": int(samples_per_symbol),
        "symbol_rate": int(symbol_rate),
        "rf_duty_cycle": total * 50 / symbol_rate,
        "bt": 0.5,
        "modulation_index": 0.5,
        "nominal_symbol_energy": 1.0,
        "framing_modes": ["oracle", "detected"],
        "default_evaluation_framing_mode": "detected",
        "whitening": False,
        "crc": False,
    }

