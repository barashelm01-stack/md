from __future__ import annotations

import csv
import json
import random
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import torch
from torch.utils.data import Dataset

from .data_impl import LibriSpeechOneSecond, ManifestSpeechDataset, SpeechSample
from .models import JSCMSystem


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)



def capture_rng_state() -> dict[str, Any]:
    state: dict[str, Any] = {
        "python": random.getstate(),
        "numpy": np.random.get_state(),
        "torch_cpu": torch.get_rng_state(),
    }
    if torch.cuda.is_available():
        state["torch_cuda"] = torch.cuda.get_rng_state_all()
    return state


def restore_rng_state(state: dict[str, Any] | None) -> None:
    if not state:
        return
    if "python" in state:
        random.setstate(state["python"])
    if "numpy" in state:
        np.random.set_state(state["numpy"])
    if "torch_cpu" in state:
        torch.set_rng_state(state["torch_cpu"])
    if torch.cuda.is_available() and "torch_cuda" in state:
        torch.cuda.set_rng_state_all(state["torch_cuda"])


def build_speech_dataset(
    *,
    manifest_path: str | None,
    data_root: str | None,
    subset: str,
    training: bool,
    crops_per_entry: int = 1,
    max_segments: int | None = None,
    random_gain_db: float = 6.0,
    seed: int = 2026,
) -> Dataset[SpeechSample]:
    if manifest_path:
        return ManifestSpeechDataset(
            manifest_path,
            training=training,
            crops_per_entry=crops_per_entry,
            random_gain_db=random_gain_db,
            max_entries=(max_segments if not training else None),
            seed=seed,
        )
    if not data_root:
        raise ValueError("Provide either a manifest path or --data-root")
    return LibriSpeechOneSecond(
        data_root,
        subset,
        training=training,
        crops_per_file=crops_per_entry,
        max_segments=max_segments,
        random_gain_db=random_gain_db,
        seed=seed,
    )


def model_kwargs_from_config(config: dict[str, Any]) -> dict[str, Any]:
    return {
        "reference_bitrate": int(
            config.get("reference_bitrate", config.get("target_bitrate", 6000))
        ),
        "model_dim": int(config.get("model_dim", 96)),
        "ff_dim": int(config.get("ff_dim", 192)),
        "num_heads": int(config.get("num_heads", 4)),
        "encoder_layers": int(config.get("encoder_layers", 2)),
        "decoder_layers": int(config.get("decoder_layers", 3)),
        "channel_sps": int(config.get("channel_sps", 4)),
        "channel_bt": float(config.get("channel_bt", 0.5)),
        "channel_modulation_index": float(config.get("channel_modulation_index", 0.5)),
        "channel_payload_peak": float(config.get("channel_payload_peak", 0.95)),
        "use_transformer": bool(config.get("use_transformer", True)),
        "snr_conditioning": bool(config.get("snr_conditioning", False)),
        "snr_condition_min_db": float(config.get("snr_condition_min_db", -20.0)),
        "snr_condition_max_db": float(config.get("snr_condition_max_db", 40.0)),
    }


def build_model_from_checkpoint(
    checkpoint: dict[str, Any], device: torch.device
) -> JSCMSystem:
    model = JSCMSystem(**model_kwargs_from_config(checkpoint.get("args", {})))
    model.load_state_dict(checkpoint["model"])
    return model.to(device).eval()



def validate_resume_config(
    saved: dict[str, Any],
    current: dict[str, Any],
    immutable_keys: Iterable[str],
) -> None:
    mismatches: list[str] = []
    for key in immutable_keys:
        if key in saved and key in current and saved[key] != current[key]:
            mismatches.append(f"{key}: saved={saved[key]!r}, current={current[key]!r}")
    if mismatches:
        raise ValueError("Resume configuration mismatch: " + "; ".join(mismatches))


def write_csv_rows(rows: list[dict[str, Any]], path: str | Path) -> None:
    if not rows:
        raise ValueError("Cannot write an empty CSV")
    output_path = Path(path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames: list[str] = []
    seen: set[str] = set()
    for row in rows:
        for key in row:
            if key not in seen:
                seen.add(key)
                fieldnames.append(key)
    with output_path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key, "") for key in fieldnames})


def append_jsonl(record: dict[str, Any], path: str | Path) -> None:
    output_path = Path(path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("a", encoding="utf-8") as file:
        file.write(json.dumps(record, ensure_ascii=False) + "\n")
