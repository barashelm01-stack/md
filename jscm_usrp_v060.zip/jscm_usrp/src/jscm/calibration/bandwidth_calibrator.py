"""Layered import facade for :mod:`jscm.spectrum`."""
from jscm.spectrum import *  # noqa: F401,F403
