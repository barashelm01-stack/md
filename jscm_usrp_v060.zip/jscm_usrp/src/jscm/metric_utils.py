from __future__ import annotations

from collections.abc import Mapping, Sequence


def aggregate_metric_records(records: Sequence[Mapping[str, float]]) -> dict[str, float]:
    """Aggregate batch metric dictionaries without over-weighting short batches.

    Metrics are assumed to be batch means. Most metrics are weighted by the
    number of samples in the batch. Waveform L1 is weighted by the number of
    valid waveform samples because zero-padded tails are excluded from that
    metric. ``latent_peak`` is aggregated with a maximum rather than a mean.

    Metadata keys start with ``_`` and are omitted from the returned dictionary.
    """
    if not records:
        raise RuntimeError("No metric records were produced")

    common_keys = set.intersection(*(set(record) for record in records))
    metric_keys = sorted(key for key in common_keys if not key.startswith("_"))
    if not metric_keys:
        raise RuntimeError("Metric records contain no common metric keys")

    aggregated: dict[str, float] = {}
    for key in metric_keys:
        if key in {"latent_peak", "phase_increment_max", "gradient_norm"}:
            aggregated[key] = max(float(record[key]) for record in records)
            continue

        weight_key = "_num_valid_samples" if key == "l1" else "_num_samples"
        numerator = 0.0
        denominator = 0.0
        for record in records:
            weight = float(record.get(weight_key, 1.0))
            if weight < 0.0:
                raise ValueError(f"Metric weight {weight_key} must be non-negative")
            numerator += float(record[key]) * weight
            denominator += weight
        if denominator <= 0.0:
            raise RuntimeError(f"Total aggregation weight for {key!r} is zero")
        aggregated[key] = numerator / denominator
    return aggregated
