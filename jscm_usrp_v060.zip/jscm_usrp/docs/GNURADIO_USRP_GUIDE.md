# GNU Radio / USRP air-interface split

## Runtime boundary

- PyTorch: source encoder/decoder only.
- GNU Radio: BLE-like framing, FM/GFSK modulation and demodulation, synchronization and deframing.
- UHD/USRP: complex-IQ streaming and RF conversion.

## ZMQ endpoints

- TX application pushes serialized `RadioPacket` messages to `tcp://127.0.0.1:5555`.
- GNU Radio TX flowgraph receives packets, frames and modulates them, then feeds UHD USRP Sink.
- GNU Radio RX flowgraph demodulates and deframes packets, then pushes packets to `tcp://<decoder-host>:5556`.

## JSCM TX flowgraph

`ZMQ PULL Message Source -> RadioPacket parser -> continuous framer -> PDU to tagged stream -> interpolation/Gaussian FIR -> Frequency Modulator -> UHD USRP Sink`

JSCM payload remains float32. Do not add Binary Slicer to the payload path.

## JSCM RX flowgraph

`UHD USRP Source -> DC Blocker -> optional CFO correction -> Quadrature Demod -> Gaussian matched filter -> symbol phase selection -> continuous deframer -> ZMQ PUSH Message Sink`

Only synchronization and header samples are hard-decided. Continuous payload samples are forwarded as float32.

## SSCC/Opus

Use the same message protocol with modes `SSCC_BITS` or `OPUS_BYTES`; after GFSK demodulation these payloads are hard-decided.

## Parameters

- Symbol rate: 1 MHz
- Samples/symbol: 4
- UHD sample rate: 4 MS/s
- BT: 0.5
- Modulation index: checkpoint-calibrated value
- Payload symbols/frame: 120 at 6 kbps reference rate

The GNU Radio Frequency Modulator sensitivity corresponding to modulation index `h` is approximately `pi*h/SPS`, subject to exact Gaussian-filter normalization. Validate it against the existing PyTorch noiseless calibration before OTA use.
