# Remaining Work

## Blocking before USRP experiments

1. Create and validate executable GNU Radio TX/RX flowgraphs for JSCM, SSCC and Opus.
2. Replace placeholder USRP serial numbers and confirm UHD device discovery and actual rates.
3. Implement/validate sample-level acquisition, coarse CFO correction and four-phase SPS timing search.
4. Numerically align GNU Radio FM/GFSK gain, filter taps and group delay with the PyTorch reference chain.
5. Decide and freeze one common prototype framing overhead for simulation and OTA resource accounting.
6. Complete GNU Radio software-channel loopback before connecting RF hardware.
7. Complete two-USRP cable loopback with 40-60 dB attenuation; verify no TX underflow/RX overflow.

## Required for a repeatable OTA prototype

8. Add a superframe acquisition sequence and continuous transmission buffering.
9. Add sequence tracking, timeout, missing-frame insertion and decoder-state reset policy.
10. Record raw complex64 IQ in parallel with online demodulation.
11. Add OTA run controller and immutable run directories containing configs, logs and recovered audio.
12. Add received-power/noise/SNR estimation and CFO/timing diagnostics.
13. Add OTA link metrics: synchronization success, header success, packet success, symbol MSE/correlation,
    BER for digital baselines, UHD underflow/overflow counts and occupied bandwidth.
14. Perform software loopback, cable loopback, short-range LOS and controlled NLOS in that order.

## Deferred by current scope

- Real LibriSpeech training and deployment benchmarking.
- Standard-compliant BLE whitening, CRC, hopping, ACK/retransmission and Link Layer state machine.
- FPGA/RFNoC implementation of modulation or neural inference.
