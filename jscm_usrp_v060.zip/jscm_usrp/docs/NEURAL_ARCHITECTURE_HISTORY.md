# v0.4 Frequency-domain codec architecture

The waveform Transformer front/back end has been replaced by an editable PyTorch frequency-domain codec backbone:

1. Causal 512-point block FFT with 320-sample (20 ms) hop and 192-sample past context.
2. Magnitude/phase features: log magnitude, cosine phase and sine phase.
3. Frequency-axis residual convolutional encoder.
4. Causal dilated temporal convolution plus GRU sequence model (no plain Transformer).
5. Continuous FM mapper for JSCM, or finite-rate scalar quantizer for the digital neural baseline.
6. Parallel magnitude/phase spectrum decoder and causal inverse block FFT synthesis.

This is a FreqCodec-style reimplementation for the current JSCM framework. It is not a vendored copy of the upstream FunCodec source and does not load FunCodec checkpoints directly.
