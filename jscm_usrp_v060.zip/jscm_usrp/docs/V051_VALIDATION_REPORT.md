# v0.5.1 validation report

This revision separates neural source coding from the GNU Radio/USRP physical layer.

Validated components:

- binary serialization for continuous JSCM, SSCC bit and Opus byte packets;
- continuous BLE-like framing without hard slicing the JSCM payload;
- digital framing with hard-decided payloads;
- independent encoder and decoder streaming states;
- 20-ms JSCM source encoder/decoder API;
- 20-ms SSCC bit encoder/decoder API;
- lazy optional ZeroMQ dependency;
- legacy differentiable FM/GFSK simulation retained for training only.

GNU Radio and UHD are not installed in the validation container, so hardware flowgraphs were not executed. The software-facing packet and model boundaries were tested independently.
