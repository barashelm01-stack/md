# v0.4.2

- Removed all legacy neural-separated naming and compatibility entry points.
- `SSCCSystem`, `train_sscc.py`, `eval_sscc.py`, and `--sscc-checkpoint` are now the only SSCC APIs.
- Removed `NeuralSeparatedCodec`, `neural_separated.py`, `train_neural_codec.py`, `eval_neural_separated.py`, and `--neural-codec-checkpoint`.
- Updated tests and packaging metadata to use SSCC terminology only.
