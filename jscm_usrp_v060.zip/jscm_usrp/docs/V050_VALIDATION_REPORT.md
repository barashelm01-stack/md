# JSCM v0.5.0 code validation report

No LibriSpeech training was run. Validation was limited to code, synthetic waveform and command-line integration tests.

## Added functionality

1. Stateful 20-ms inference
   - FFT analysis context: 192 samples.
   - Per-layer causal convolution state.
   - GRU hidden state for transmit and receive sequence models.
   - Exact block/stream equivalence in bypass mode.
   - JSCM and SSCC both expose `init_stream_state` and `stream_step`.

2. Runtime profiling
   - Encoder latency.
   - FM channel latency.
   - Decoder latency.
   - Full 1-s inference latency.
   - Stateful 20-ms step latency.
   - Full training-step latency.
   - Peak CUDA memory when CUDA is available.

3. Automatic bandwidth calibration
   - Measures packet-wise Welch PSD and 99% occupied bandwidth.
   - Uses a same-resource GFSK reference.
   - Grid-searches FM modulation index.
   - Reports relative mismatch and tolerance pass/fail.
   - Can write a calibrated checkpoint configuration.

4. Detected BLE-like framing
   - 8-bit preamble.
   - 32-bit Access Address.
   - 16-bit little-endian payload length.
   - Sync search using Hamming distance.
   - Header parsing, truncation detection and packet-failure reporting.
   - Supports leading idle symbols/bits in evaluation.
   - Whitening and CRC remain disabled.
   - Symbol timing remains known; sample-level timing recovery is not implemented.

## Test results

- Python compilation: passed.
- Unit tests: 51/51 passed.
- Stateful JSCM block/stream equivalence: max error below 1e-5.
- Stateful SSCC block/stream equivalence: max error below 1e-5.
- BLE-like bit framing with a 17-bit leading offset: detected and recovered.
- Truncated payload: correctly rejected.
- FM detected framing with 11 leading idle symbols: all packets recovered at no noise.
- Existing FM no-noise calibration and GFSK zero-BER tests: passed.
- `profile_runtime.py`: completed on CPU synthetic input.
- `calibrate_bandwidth.py`: completed on a synthetic checkpoint and manifest.
- `eval_jscm.py --framing-mode detected`: completed.
- `eval_opus_gfsk.py --framing-mode detected --leading-idle-bits 8`: completed.
- Unified JSCM/SSCC benchmark in detected mode: completed.

## Important scope limitation

The detected framing path is BLE-like, not BLE 4.2 compliant. It performs packet sync and header parsing after symbol-aligned demodulation. It still omits sample timing recovery, carrier-frequency offset, whitening, CRC, channel hopping, ACK/retransmission and Link Layer state behavior.
