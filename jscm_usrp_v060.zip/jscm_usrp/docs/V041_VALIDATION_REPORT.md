# JSCM v0.4.1 code validation

No LibriSpeech training was run.

## Results

- Python compilation: passed.
- Unit tests: 46/46 passed.
- FreqCodec-style JSCM smoke test: passed.
- Gradient accumulation boundary and short-final-group tests: passed.
- AMP auto/off CPU behavior tests: passed.
- Synthetic one-epoch JSCM training with physical batch 2 and accumulation 2: passed.
- Synthetic one-epoch SSCC training with physical batch 2 and accumulation 2: passed.
- JSCM and SSCC checkpoints contain GradScaler state and accumulation configuration.
- Existing FM/GFSK, causality, spectrum, metric and plotting regressions: passed.

## CUDA boundary

The current environment did not contain an NVIDIA A6000, so CUDA throughput and
actual FP16 memory consumption were not benchmarked here. The CUDA implementation
uses standard `torch.autocast` and `torch.amp.GradScaler`; the calibrated FM physical
layer and the objective loss are explicitly evaluated in FP32.
