# Current System Architecture

## 1. Three-layer partition

```text
PyTorch neural layer
  JSCM: 20 ms speech frame -> continuous channel symbols
  SSCC: 20 ms speech frame -> quantized binary payload
        |
        | RadioPacket over ZeroMQ
        v
GNU Radio physical/link prototype layer
  BLE-like framing, synchronization, FM/GFSK modulation and demodulation,
  continuous-payload extraction for JSCM, hard decisions for SSCC/Opus
        |
        | complex IQ through UHD
        v
Two-USRP RF layer
  DAC/ADC, digital up/down conversion, RF transmission and reception
```

## 2. JSCM path

```text
16 kHz speech -> FreqCodec-style causal encoder -> continuous mapper
-> 120 float32 symbols per 20 ms frame -> ZeroMQ -> GNU Radio BLE-like framer
-> Gaussian-shaped FM -> USRP TX -> RF channel -> USRP RX
-> FM discriminator -> synchronization/deframing -> continuous float32 symbols
-> ZeroMQ -> neural channel demapper -> causal decoder -> reconstructed speech
```

The JSCM payload must remain continuous. Only synchronization and header fields are hard-decided.

## 3. SSCC path

```text
16 kHz speech -> same neural source backbone -> finite-rate quantizer -> bits
-> ZeroMQ -> BLE-like framing -> GFSK -> USRP -> GFSK hard demodulation
-> bits -> neural source decoder -> reconstructed speech
```

## 4. Opus path

```text
16 kHz speech -> Opus payload bytes -> BLE-like framing -> GFSK -> USRP
-> hard demodulation/deframing -> Opus decode or packet-loss handling
```

## 5. Training versus OTA

Training retains the differentiable PyTorch FM/AWGN approximation. OTA execution bypasses
that simulated channel and uses GNU Radio/UHD. Neural encoder and decoder interfaces are
therefore independent and stateful.

## 6. Current fixed assumptions

- Audio: 16 kHz mono.
- Source frame: 20 ms / 320 samples.
- Reference bitrate: 6 kbps.
- JSCM payload: 120 continuous symbols per frame.
- Symbol rate: 1 Mbaud.
- Samples per symbol: 4.
- GNU Radio/USRP sample rate: 4 MS/s.
- Gaussian BT: 0.5.
- Default modulation index: 0.5, subject to calibration.
- Prototype BLE-like framing only; standards compliance is not a goal.
