# JSCM-USRP Prototype

**Current version: v0.6.4**

A research prototype for joint source-channel speech communication with:

- a PyTorch neural speech codec/JSCM layer;
- an SSCC baseline and Opus-GFSK baseline;
- GNU Radio modulation, demodulation, framing and synchronization boundaries;
- a two-USRP RF prototype path;
- receiver-measured SNR and symbol-domain \(E_s/N_0\) calibration;
- automated KPI-versus-SNR figures and TX-gain-versus-SNR summaries.

The current project is intended for **JSCM prototype validation**, not standards-compliant Bluetooth transmission.

## 1. Current architecture

```text
JSCM transmit host
Audio/WAV
  -> PyTorch FreqCodec-style encoder
  -> continuous float32 channel symbols
  -> ZeroMQ RadioPacket
  -> GNU Radio BLE-like framing and FM modulation
  -> UHD USRP Sink
  -> USRP TX

RF cable or over-the-air channel

JSCM receive host
USRP RX
  -> UHD USRP Source
  -> GNU Radio synchronization, FM demodulation and continuous deframing
  -> ZeroMQ RadioPacket
  -> PyTorch channel demapper and decoder
  -> reconstructed audio/WAV
```

The SSCC and Opus paths use binary payloads and GFSK instead of continuous JSCM payloads.

Detailed documents:

- `docs/SYSTEM_ARCHITECTURE.md`: system architecture;
- `docs/GNURADIO_USRP_GUIDE.md`: GNU Radio and USRP integration;
- `docs/POWER_CONTROLLED_SNR.md`: power-controlled SNR methodology;
- `docs/REMAINING_WORK.md`: work still required;
- `docs/FILE_TREE.md`: project layout.

## 2. Important implementation status

Completed and software-validated:

- FreqCodec-style JSCM model;
- SSCC model and bitstream interface;
- 20 ms stateful streaming encoder/decoder interfaces;
- differentiable FM/AWGN training channel;
- GFSK software reference channel;
- BLE-like framing and detected deframing logic;
- RadioPacket serialization;
- ZeroMQ transport boundary;
- objective speech metrics;
- SNR and symbol-domain \(E_s/N_0\) estimation;
- TX-gain sweep aggregation and linear calibration;
- KPI-versus-SNR dashboard generation.

Not yet claimed as completed:

- executable and hardware-validated GNU Radio `.grc` flowgraphs;
- actual UHD/USRP cable-loopback and OTA results;
- real LibriSpeech model training results;
- deployment latency and power results.

The files under `gnuradio/grc/*.todo` are design placeholders, not validated flowgraphs.

## 3. Project layout

```text
jscm_usrp/
├── apps/                 # CLI entry points
│   ├── train/            # JSCM and SSCC training
│   ├── evaluation/       # benchmark, metrics and plots
│   ├── calibration/      # SNR, gain and bandwidth calibration
│   ├── ota/              # PyTorch OTA TX/RX applications
│   ├── simulation/       # smoke tests and PHY calibration
│   └── streaming/        # streaming inference
├── configs/              # model, radio, OTA and evaluation configs
├── docs/                 # architecture and experiment documentation
├── gnuradio/             # GNU Radio blocks and flowgraph scaffolding
├── src/jscm/             # core Python package
├── tests/                # unit and integration tests
├── usrp/                 # USRP configuration and helper tools
├── data/                 # manifests, audio and recorded IQ
├── checkpoints/          # trained JSCM/SSCC checkpoints
├── runs/                 # generated experiment outputs
└── artifacts/            # figures, tables, reports and audio samples
```

## 4. Installation

### 4.1 Core Python environment

Recommended Python version: 3.10 or 3.11.

```bash
cd jscm_usrp
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -e .
```

### 4.2 Optional dependencies

Install objective metrics, ZeroMQ and Opus support:

```bash
pip install -e ".[metrics,radio,opus]"
```

Alternatively:

```bash
pip install -r requirements.txt
pip install -r requirements-radio.txt
pip install -r requirements-opus.txt
```

GNU Radio, UHD and the USRP driver should normally be installed through the operating-system package manager or Ettus/National Instruments packages on the radio hosts. They are not installed by this Python project.

### 4.3 Verify the Python environment

Always invoke project applications as modules from the project root:

```bash
python -m apps.simulation.smoke_test
python -m apps.evaluation.validate_framework
```

Using `python -m apps...` avoids package-import errors that may occur when running nested script files directly.

## 5. Data preparation

The training and evaluation scripts accept JSONL manifests. Each line should describe one audio item and its file path according to the existing manifest loader.

Recommended locations:

```text
data/manifests/train.jsonl
data/manifests/dev.jsonl
data/manifests/test.jsonl
```

Audio requirements:

- mono;
- 16 kHz;
- training samples are cropped or padded to 1 s;
- streaming and OTA paths operate on 20 ms frames, i.e. 320 samples.

## 6. Train the JSCM model

Recommended single-A6000 configuration with physical batch size 50 and effective batch size 100:

```bash
python -m apps.train.train_jscm \
  --train-manifest data/manifests/train.jsonl \
  --val-manifest data/manifests/dev.jsonl \
  --output-dir runs/training/jscm_6k \
  --epochs 100 \
  --batch-size 50 \
  --gradient-accumulation-steps 2 \
  --num-workers 8 \
  --reference-bitrate 6000 \
  --model-dim 64 \
  --encoder-layers 2 \
  --decoder-layers 3 \
  --channel-sps 4 \
  --channel-bt 0.5 \
  --channel-modulation-index 0.5 \
  --amp auto \
  --amp-dtype float16 \
  --full-validation-every 5 \
  --quick-val-esn0 10 \
  --objective-validation-every 5 \
  --seed 2026
```

Resume training:

```bash
python -m apps.train.train_jscm \
  --train-manifest data/manifests/train.jsonl \
  --val-manifest data/manifests/dev.jsonl \
  --output-dir runs/training/jscm_6k \
  --resume runs/training/jscm_6k/last.pt
```

The main expected checkpoints are stored under the selected output directory, including the best bypass/FM models and the latest resumable state.

## 7. Train the SSCC baseline

```bash
python -m apps.train.train_sscc \
  --train-manifest data/manifests/train.jsonl \
  --val-manifest data/manifests/dev.jsonl \
  --output-dir runs/training/sscc_6k \
  --epochs 100 \
  --batch-size 50 \
  --gradient-accumulation-steps 2 \
  --num-workers 8 \
  --reference-bitrate 6000 \
  --quantizer-bits 6 \
  --model-dim 64 \
  --encoder-layers 2 \
  --decoder-layers 3 \
  --amp auto \
  --amp-dtype float16 \
  --validate-every 5 \
  --seed 2026
```

## 8. Run simulation benchmark

The benchmark compares JSCM-FM, SSCC-GFSK and Opus-GFSK when the required checkpoints and Opus dependency are available.

```bash
python -m apps.evaluation.benchmark \
  --checkpoint runs/training/jscm_6k/best_fm.pt \
  --sscc-checkpoint runs/training/sscc_6k/best.pt \
  --test-manifest data/manifests/test.jsonl \
  --output-dir runs/simulation/benchmark_6k \
  --esn0-list 0 5 10 15 20 \
  --max-segments 1000 \
  --batch-size 8 \
  --num-workers 4 \
  --framing-mode detected \
  --plot-formats png pdf
```

To skip Opus when `opuslib` is unavailable:

```bash
python -m apps.evaluation.benchmark \
  --checkpoint runs/training/jscm_6k/best_fm.pt \
  --test-manifest data/manifests/test.jsonl \
  --output-dir runs/simulation/benchmark_jscm_only \
  --skip-opus
```

Benchmark outputs include:

```text
metrics.csv
resource_report.json
examples/*.wav
figures/waveform_distance_vs_esn0.png
figures/segsnr_db_vs_esn0.png
figures/pesq_wb_vs_esn0.png
figures/si_sdr_db_vs_esn0.png
figures/stft_distance_vs_esn0.png
figures/stoi_vs_esn0.png
figures/kpi_vs_snr_dashboard.png
```

## 9. Plot KPI-versus-SNR figures from existing results

Prepare a benchmark metrics CSV and, optionally, a TX-gain sweep CSV/JSON.

```bash
python -m apps.evaluation.plot_metric_curves \
  --metrics-csv runs/simulation/benchmark_6k/metrics.csv \
  --gain-snr-file runs/ota/gain_sweep/summary/gain_sweep.csv \
  --output-dir runs/simulation/benchmark_6k/figures \
  --formats png pdf
```

The combined dashboard contains:

```text
left six panels:
- waveform distance vs SNR
- SegSNR vs SNR
- PESQ-WB vs SNR
- SI-SDR vs SNR
- STFT distance vs SNR
- STOI vs SNR

right two-row panel:
- TX gain vs sample-domain SNR
- TX gain vs symbol-domain Es/N0
```

The gain-SNR input should contain columns such as:

```csv
tx_gain_db,sample_snr_db,symbol_esn0_db,clipping_rate
0,1.8,1.4,0.0
5,6.7,6.3,0.0
10,11.6,11.1,0.0
```

## 10. Profile runtime

```bash
python -m apps.evaluation.profile_runtime \
  --checkpoint runs/training/jscm_6k/best_fm.pt \
  --batch-size 50 \
  --warmup 20 \
  --iterations 100 \
  --amp \
  --output runs/profiling/jscm_runtime.json
```

This measures encoder, channel, decoder, 1 s inference, 20 ms stream-step and training-step latency when supported by the local environment.

## 11. Streaming inference

```bash
python -m apps.streaming.stream_infer \
  --checkpoint runs/training/jscm_6k/best_fm.pt \
  --input data/audio/input.wav \
  --output runs/streaming/reconstructed.wav \
  --esn0-db 10 \
  --channel-mode fm \
  --framing-mode detected
```

## 12. GNU Radio and two-USRP prototype

### 12.1 System split

PyTorch sends/receives payloads through ZeroMQ:

- JSCM: continuous `float32` symbols;
- SSCC: binary `uint8` bits;
- Opus: bytes.

GNU Radio is responsible for:

- BLE-like framing;
- Gaussian shaping;
- FM/GFSK modulation and demodulation;
- synchronization and header recovery;
- UHD USRP Source/Sink.

### 12.2 Configure the radios

Edit:

```text
configs/radio/usrp_tx.yaml
configs/radio/usrp_rx.yaml
configs/radio/gnuradio_jscm.yaml
usrp/inventory.yaml
```

Set at least:

- TX and RX USRP serial numbers;
- center frequency;
- sample rate;
- symbol rate;
- SPS;
- TX gain;
- RX gain;
- RF bandwidth;
- antenna port.

Recommended initial parameters:

```text
symbol rate: 1 MHz
SPS: 4
sample rate: 4 MS/s
Gaussian BT: 0.5
modulation index: 0.5 or calibrated checkpoint value
AGC: disabled
```

### 12.3 PyTorch JSCM TX application

```bash
python -m apps.ota.ota_jscm_tx \
  --checkpoint runs/training/jscm_6k/best_fm.pt \
  --input data/audio/input.wav \
  --endpoint tcp://127.0.0.1:5555 \
  --device cuda
```

### 12.4 PyTorch JSCM RX application

```bash
python -m apps.ota.ota_jscm_rx \
  --checkpoint runs/training/jscm_6k/best_fm.pt \
  --output runs/ota/reconstructed.wav \
  --endpoint tcp://0.0.0.0:5556 \
  --frames 500 \
  --device cuda
```

The GNU Radio TX/RX processes must be running between these endpoints and the USRPs. See `docs/GNURADIO_USRP_GUIDE.md`.

### 12.5 Recommended validation order

1. GNU Radio software channel-model loopback;
2. two-USRP cable loopback through 40–60 dB attenuation;
3. short-range LOS OTA;
4. controlled TX-gain sweep;
5. LOS/NLOS prototype comparison.

Do not connect a USRP TX output directly to an RX input without sufficient attenuation.

## 13. Estimate SNR from one USRP run

The recommended received superframe includes a silent region and a known training sequence.

Required recorded arrays:

```text
active_iq.npy             # IQ from training/active region
noise_iq.npy              # IQ from silent region
reference_symbols.npy     # known training symbols
received_symbols.npy      # matched-filter/timing-corrected received symbols
```

Run:

```bash
python -m apps.calibration.estimate_usrp_snr \
  --active-iq runs/ota/gain_10/repeat_00/active_iq.npy \
  --noise-iq runs/ota/gain_10/repeat_00/noise_iq.npy \
  --reference-symbols runs/ota/gain_10/repeat_00/reference_symbols.npy \
  --received-symbols runs/ota/gain_10/repeat_00/received_symbols.npy \
  --tx-gain-db 10 \
  --clipping-threshold 0.95 \
  --output runs/ota/gain_10/repeat_00/snr_estimate.json
```

The script reports:

- sample-domain SNR;
- symbol-domain \(E_s/N_0\);
- EVM;
- signal, total and noise power;
- clipping rate;
- TX gain setting.

The formal experimental horizontal axis should be the **measured symbol-domain \(E_s/N_0\)**. TX gain is only the hardware control variable.

## 14. Aggregate repeated TX-gain sweeps

Recommended directory layout:

```text
runs/ota/gain_sweep/
├── gain_00/repeat_00/snr_estimate.json
├── gain_00/repeat_01/snr_estimate.json
├── gain_05/repeat_00/snr_estimate.json
├── gain_05/repeat_01/snr_estimate.json
└── gain_10/repeat_00/snr_estimate.json
```

Aggregate all runs:

```bash
python -m apps.calibration.aggregate_gain_sweep \
  --root runs/ota/gain_sweep \
  --output-dir runs/ota/gain_sweep/summary \
  --fit-snr-column symbol_esn0_db \
  --clipping-limit 1e-4 \
  --min-valid-runs 1 \
  --target-snr-db 0 5 10 15 20
```

Outputs:

```text
gain_sweep_runs.csv       # one row per physical run
gain_sweep.csv            # mean/std/count grouped by TX gain
tx_gain_calibration.json  # fitted gain-to-SNR relation and target gains
```

The fitting stage automatically excludes points whose clipping rate exceeds the configured limit.

## 15. Generate benchmark plots with automatic gain-sweep aggregation

The benchmark can directly scan an OTA gain-sweep directory:

```bash
python -m apps.evaluation.benchmark \
  --checkpoint runs/training/jscm_6k/best_fm.pt \
  --sscc-checkpoint runs/training/sscc_6k/best.pt \
  --test-manifest data/manifests/test.jsonl \
  --output-dir runs/simulation/benchmark_with_gain \
  --gain-sweep-root runs/ota/gain_sweep \
  --esn0-list 0 5 10 15 20
```

It will write the aggregated gain data under the benchmark output and use it for the right-side gain-versus-SNR dashboard panels.

## 16. Fit TX gain to measured SNR from an existing CSV

```bash
python -m apps.calibration.fit_tx_gain_snr \
  --csv runs/ota/gain_sweep/summary/gain_sweep.csv \
  --gain-column tx_gain_db \
  --snr-column symbol_esn0_db \
  --target-snr-db 0 5 10 15 20 \
  --output runs/ota/gain_sweep/summary/tx_gain_calibration.json
```

Do not assume that `TX gain = SNR`. The calibration relation is valid only within the measured linear, non-clipping region.

## 17. Bandwidth calibration

After a trained checkpoint is available:

```bash
python -m apps.calibration.calibrate_bandwidth \
  --checkpoint runs/training/jscm_6k/best_fm.pt \
  --test-manifest data/manifests/test.jsonl \
  --segments 20 \
  --min-index 0.1 \
  --max-index 1.2 \
  --candidates 23 \
  --tolerance 0.05 \
  --write-checkpoint checkpoints/jscm/best_fm_bw_calibrated.pt
```

This searches the FM modulation index to reduce the mismatch between JSCM-FM and GFSK 99% occupied bandwidth.

## 18. Tests

Run the full Python test suite from the project root:

```bash
PYTHONPATH=src python -m unittest discover -s tests -v
```

Run only the plotting and gain/SNR tests:

```bash
PYTHONPATH=src python -m unittest \
  tests.unit.test_metrics_and_plots \
  tests.unit.test_snr_estimation \
  tests.unit.test_gain_sweep_aggregation -v
```

Hardware tests require GNU Radio, UHD and connected USRPs and are not expected to pass in a generic Python-only environment.

## 19. Recommended experiment procedure

For reproducible power-controlled USRP experiments:

1. disable AGC;
2. fix RX gain, RF bandwidth, sample rate, antennas, frequency and propagation path;
3. change only TX gain or external attenuation;
4. transmit the same training sequence and speech set at every point;
5. estimate noise power from the silent interval;
6. estimate symbol-domain \(E_s/N_0\) from the known training symbols;
7. reject clipped or nonlinear points;
8. repeat each TX gain at least three times;
9. aggregate mean and standard deviation;
10. plot speech KPIs against measured \(E_s/N_0\), not nominal TX gain.

## 20. Known limitations

- GNU Radio flowgraphs still require target-host construction and validation.
- The BLE-like framing is intentionally simplified and not standards-compliant BLE.
- Current detected framing assumes a simplified synchronization path; full RF timing recovery remains part of hardware integration.
- No real trained checkpoint or OTA result is included in this archive.
- No claim of real-time operation or deployment efficiency is made before hardware profiling.

## 21. Citation and reporting terminology

Use the following names consistently:

- **JSCM-FM**: continuous joint source-channel speech communication;
- **SSCC-GFSK**: separate source-channel coding baseline;
- **Opus-GFSK**: conventional speech codec baseline;
- **BLE-like framing**: simplified prototype framing, not standards-compliant BLE;
- **measured symbol-domain \(E_s/N_0\)**: preferred OTA link-quality axis.
