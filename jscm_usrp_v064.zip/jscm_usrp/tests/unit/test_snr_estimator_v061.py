import unittest

import numpy as np

from jscm.calibration import estimate_sample_snr, estimate_symbol_esn0, fit_gain_calibration


class SnrEstimatorTests(unittest.TestCase):
    def test_sample_snr_matches_constructed_power(self):
        rng = np.random.default_rng(2026)
        n_active = (rng.normal(size=200000) + 1j * rng.normal(size=200000)) / np.sqrt(2)
        n_quiet = (rng.normal(size=200000) + 1j * rng.normal(size=200000)) / np.sqrt(2)
        noise_power = 0.01
        signal_power = 0.1
        active = np.sqrt(signal_power) + np.sqrt(noise_power) * n_active
        quiet = np.sqrt(noise_power) * n_quiet
        estimate = estimate_sample_snr(active, quiet)
        self.assertTrue(estimate.valid)
        self.assertAlmostEqual(estimate.snr_db, 10.0, delta=0.15)

    def test_symbol_esn0_handles_complex_gain(self):
        rng = np.random.default_rng(2027)
        x = rng.choice([-1.0, 1.0], size=200000).astype(np.complex128)
        h = 0.7 * np.exp(1j * 0.4)
        target_db = 15.0
        signal_energy = abs(h) ** 2
        noise_energy = signal_energy / (10 ** (target_db / 10))
        noise = np.sqrt(noise_energy / 2) * (
            rng.normal(size=x.size) + 1j * rng.normal(size=x.size)
        )
        estimate = estimate_symbol_esn0(x, h * x + noise)
        self.assertTrue(estimate.valid)
        self.assertAlmostEqual(estimate.esn0_db, target_db, delta=0.15)

    def test_gain_fit_and_inverse(self):
        calibration = fit_gain_calibration([0, 5, 10, 15], [2, 7, 12, 17])
        self.assertAlmostEqual(calibration.slope_db_per_gain_db, 1.0, places=7)
        self.assertAlmostEqual(calibration.gain_for_target_snr_db(10), 8.0, places=7)
        self.assertAlmostEqual(calibration.r_squared, 1.0, places=7)


if __name__ == "__main__":
    unittest.main()
