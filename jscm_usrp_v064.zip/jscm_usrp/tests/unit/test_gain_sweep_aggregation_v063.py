from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from apps.calibration.aggregate_gain_sweep import aggregate_rows, discover_rows, fit_calibration


class GainSweepAggregationTests(unittest.TestCase):
    def test_discovers_aggregates_and_fits_repeated_gain_runs(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for gain in (0.0, 5.0, 10.0):
                for repeat in (0, 1):
                    run_dir = root / f"gain_{gain:g}" / f"repeat_{repeat}"
                    run_dir.mkdir(parents=True)
                    snr = 0.95 * gain + 1.0 + 0.1 * repeat
                    payload = {
                        "tx_gain_db": gain,
                        "sample_snr": {"snr_db": snr + 0.4, "valid": True},
                        "symbol_esn0": {"esn0_db": snr, "evm_rms": 0.1, "valid": True},
                        "total_power_dbfs": -40.0 + gain,
                        "noise_power_dbfs": -70.0,
                        "signal_power_dbfs": -40.0 + gain,
                        "clipping_rate": 0.0,
                    }
                    (run_dir / "snr_estimate.json").write_text(json.dumps(payload), encoding="utf-8")

            rows = discover_rows(root)
            self.assertEqual(len(rows), 6)
            aggregated = aggregate_rows(rows)
            self.assertEqual(len(aggregated), 3)
            self.assertEqual(aggregated[0]["runs"], 2)
            self.assertGreater(aggregated[0]["symbol_esn0_db_std"], 0.0)

            calibration = fit_calibration(
                aggregated,
                snr_key="symbol_esn0_db",
                clipping_limit=1e-4,
                min_valid_runs=1,
            )
            self.assertIsNotNone(calibration)
            assert calibration is not None
            self.assertAlmostEqual(calibration["slope_db_per_gain_db"], 0.95, places=6)
            self.assertGreater(calibration["r_squared"], 0.999)

    def test_clipped_points_are_excluded(self) -> None:
        aggregated = [
            {"tx_gain_db": 0.0, "symbol_esn0_db": 1.0, "symbol_esn0_valid_count": 1, "clipping_rate": 0.0},
            {"tx_gain_db": 5.0, "symbol_esn0_db": 6.0, "symbol_esn0_valid_count": 1, "clipping_rate": 0.0},
            {"tx_gain_db": 10.0, "symbol_esn0_db": 30.0, "symbol_esn0_valid_count": 1, "clipping_rate": 0.1},
        ]
        calibration = fit_calibration(aggregated, "symbol_esn0_db", 1e-4, 1)
        self.assertIsNotNone(calibration)
        assert calibration is not None
        self.assertEqual(calibration["points_used"], 2)
        self.assertAlmostEqual(calibration["slope_db_per_gain_db"], 1.0, places=6)


if __name__ == "__main__":
    unittest.main()
