# V0.6.4 Validation Report

## Scope

This release consolidates the v0.6.3 codebase into a user-facing archive and rewrites the root README with complete usage instructions.

## README coverage

The README now documents:

- system architecture and current implementation status;
- core and optional installation;
- required module-style CLI invocation;
- JSCM and SSCC training;
- simulation benchmark and KPI plotting;
- runtime profiling and streaming inference;
- GNU Radio/two-USRP system split;
- JSCM OTA TX/RX application commands;
- receiver-side sample SNR and symbol Es/N0 estimation;
- repeated TX-gain sweep aggregation;
- automatic KPI dashboard generation;
- gain-to-SNR fitting;
- bandwidth calibration;
- test commands;
- recommended USRP experiment procedure and known limitations.

## Validation

- Python syntax compilation: passed for the modified benchmark and plotting modules.
- Metrics/plotting unit tests: 5/5 passed.
- SNR and gain-sweep focused tests: passed in the previous v0.6.3 validation.
- Root README command style checked using `python -m apps...` from the project root.

## Hardware status

GNU Radio/UHD flowgraphs and physical USRP operation are not claimed as validated in this environment. The archive contains interfaces, blocks, configuration templates and experiment procedures for target-host integration.
