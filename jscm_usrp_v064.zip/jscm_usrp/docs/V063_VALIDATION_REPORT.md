# V0.6.3 Validation Report

## New automated OTA gain/SNR workflow

The project now supports an end-to-end data path from per-run USRP recordings to the KPI dashboard:

1. `estimate_usrp_snr.py` creates one `snr_estimate.json` for every TX-gain run.
2. `aggregate_gain_sweep.py` recursively discovers those files.
3. Repeated runs at the same TX gain are aggregated as mean, standard deviation, count, and validity count.
4. Gain points with clipping above the configured limit are excluded from linear calibration.
5. The script writes:
   - `gain_sweep_runs.csv` — one row per physical run;
   - `gain_sweep.csv` — one row per TX gain;
   - `tx_gain_calibration.json` — fitted gain/SNR model and target gain table.
6. `benchmark.py --gain-sweep-root ...` can perform the aggregation automatically and pass the result to `kpi_vs_snr_dashboard.png`.

## Per-run clipping measurement

`estimate_usrp_snr.py` now records:

- `clipping_threshold`;
- `clipping_rate`.

The default threshold is `0.95` in normalized complex-sample magnitude.

## Tests

- gain-sweep discovery and repeated-run aggregation: passed;
- mean/std/count calculation: passed;
- linear gain-to-SNR calibration: passed;
- automatic exclusion of clipped gain points: passed;
- KPI plotting tests: passed;
- syntax compilation for changed scripts: passed.
