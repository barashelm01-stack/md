# v0.6.1 Validation Report

## Scope

This release adds receiver-measured SNR/EsN0 support for power-controlled two-USRP
experiments. It does not claim hardware execution because GNU Radio, UHD and the two USRPs
were not available in the build environment.

## Added

- sample-domain SNR estimator using active and silent IQ regions;
- symbol-domain Es/N0 estimator using a least-squares complex channel coefficient;
- TX-gain versus measured-SNR linear calibration and inverse lookup;
- offline calibration command-line tools;
- controlled-SNR experiment configuration;
- documentation of the required superframe regions and reporting rules.

## Validation

- Python compile check passed for `src`, `apps` and `tests`.
- Three estimator/calibration unit tests passed.
- Eight selected SNR and GNU Radio boundary tests passed.
- Sample-domain estimator recovered a constructed 10 dB SNR within 0.15 dB.
- Symbol-domain estimator recovered a constructed 15 dB Es/N0 under complex gain within 0.15 dB.
- Gain calibration correctly fitted and inverted a linear sweep.

A complete `pytest` run was started but exceeded the execution window because some existing
legacy tests are slow. No failure was observed before timeout. This report therefore does not
claim that every historical test completed in this environment.
