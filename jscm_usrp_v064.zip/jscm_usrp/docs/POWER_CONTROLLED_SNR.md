# Power-Controlled SNR Procedure

## Purpose

The two-USRP prototype controls link quality by changing TX gain while fixing RX gain,
sample rate, RF bandwidth, center frequency, antennas and propagation path. TX gain is only
a control input. The SNR used in figures is measured at the receiver for each run.

## Required superframe regions

```text
20 ms silence | 128 known balanced training symbols | payload packets | 20 ms silence
```

The quiet region estimates receiver noise. The training region estimates signal power,
complex channel gain and effective symbol-domain noise.

## Measurement sequence

1. Disable AGC and fix RX gain.
2. Select a TX-gain sweep that does not clip at the highest value.
3. For each gain, transmit the same balanced training sequence and payload.
4. Record raw complex IQ before demodulation.
5. Estimate sample-domain SNR from active and silent IQ regions.
6. Perform CFO correction, matched filtering and timing selection.
7. Estimate symbol-domain Es/N0 from the reference and received training symbols.
8. Reject runs with clipping rate above the configured threshold.
9. Fit the approximately linear TX-gain-to-Es/N0 region.
10. Use the fitted curve only to choose initial gain values; remeasure Es/N0 in every formal run.

## Commands

Estimate one recorded run:

```bash
python apps/calibration/estimate_usrp_snr.py \
  --active-iq runs/ota/gain_10/active_iq.npy \
  --noise-iq runs/ota/gain_10/noise_iq.npy \
  --reference-symbols runs/ota/gain_10/reference_symbols.npy \
  --received-symbols runs/ota/gain_10/received_symbols.npy \
  --tx-gain-db 10 \
  --output runs/ota/gain_10/snr_estimate.json
```

Fit a calibration table from a gain sweep:

```bash
python apps/calibration/fit_tx_gain_snr.py \
  --csv runs/ota/gain_sweep.csv \
  --snr-column symbol_esn0_db \
  --target-snr-db 0 5 10 15 20 \
  --output runs/ota/tx_gain_calibration.json
```

## Reporting rules

- Do not state that a TX gain of 10 dB means an SNR of 10 dB.
- Do not subtract dB powers to isolate signal power.
- Keep RX gain and bandwidth fixed throughout a sweep.
- Report measured Es/N0, TX gain, RX gain, received signal dBFS, noise dBFS and clipping rate.
- Use the same training sequence and estimator for JSCM, SSCC and Opus.

## Automatic gain-sweep aggregation

Store each physical run under any nested directory, provided that each run contains a file named `snr_estimate.json`:

```text
runs/ota/gain_sweep/
├── gain_00/repeat_00/snr_estimate.json
├── gain_00/repeat_01/snr_estimate.json
├── gain_05/repeat_00/snr_estimate.json
└── gain_10/repeat_00/snr_estimate.json
```

Aggregate all runs:

```bash
python apps/calibration/aggregate_gain_sweep.py \
  --root runs/ota/gain_sweep \
  --output-dir runs/ota/gain_sweep/summary \
  --fit-snr-column symbol_esn0_db \
  --target-snr-db 0 5 10 15 20
```

The benchmark can discover and aggregate the same directory directly:

```bash
python apps/evaluation/benchmark.py \
  --checkpoint checkpoints/jscm/best_fm.pt \
  --test-manifest data/manifests/test.jsonl \
  --gain-sweep-root runs/ota/gain_sweep \
  --output-dir runs/benchmark
```

This produces the KPI dashboard and copies the aggregated gain tables to:

```text
runs/benchmark/calibration/gain_sweep_runs.csv
runs/benchmark/calibration/gain_sweep.csv
```
