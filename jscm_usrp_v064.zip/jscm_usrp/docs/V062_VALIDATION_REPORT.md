# V0.6.2 Validation Report

## New feature

The evaluation/plotting path now generates:

1. per-metric KPI-vs-SNR figures;
2. a combined dashboard figure `kpi_vs_snr_dashboard.png`;
3. a right-side two-row panel in the dashboard for **TX gain vs measured sample-domain SNR** and **TX gain vs measured symbol-domain Es/N0**.

## Code changes

- `apps/evaluation/plot_metric_curves.py`
  - added combined dashboard plotting;
  - added optional `gain_snr_rows` support;
  - added CSV/JSON gain-SNR file reader;
  - added CLI argument `--gain-snr-file`.
- `apps/evaluation/benchmark.py`
  - added `--gain-snr-file` passthrough to plotting.
- `tests/unit/test_metrics_and_plots.py`
  - updated expected figure count;
  - added dashboard-with-gain-data coverage.

## Validation executed

- Python syntax compilation for updated files: passed.
- Unit tests for metrics and plotting: 5/5 passed.
- Generated outputs verified:
  - six KPI figures;
  - one combined dashboard figure.

## Expected outputs

The plotting script now writes:

- `waveform_distance_vs_esn0.png`
- `segsnr_db_vs_esn0.png`
- `pesq_wb_vs_esn0.png`
- `si_sdr_db_vs_esn0.png`
- `stft_distance_vs_esn0.png`
- `stoi_vs_esn0.png`
- `kpi_vs_snr_dashboard.png`

The dashboard contains a right-most two-row panel:

- top: `TX Gain vs Sample-domain SNR`
- bottom: `TX Gain vs Symbol-domain Es/N0`
