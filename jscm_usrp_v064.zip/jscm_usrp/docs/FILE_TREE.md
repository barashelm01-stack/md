# Project File Tree

```text
jscm_usrp/
├── apps/
│   ├── calibration/
│   │   ├── __init__.py
│   │   └── calibrate_bandwidth.py
│   ├── evaluation/
│   │   ├── __init__.py
│   │   ├── benchmark.py
│   │   ├── eval_jscm.py
│   │   ├── eval_opus_gfsk.py
│   │   ├── eval_sscc.py
│   │   ├── measure_spectrum.py
│   │   ├── plot_metric_curves.py
│   │   ├── profile_runtime.py
│   │   └── validate_framework.py
│   ├── ota/
│   │   ├── __init__.py
│   │   ├── ota_jscm_rx.py
│   │   └── ota_jscm_tx.py
│   ├── simulation/
│   │   ├── __init__.py
│   │   ├── calibrate_phy.py
│   │   ├── run_ablations.py
│   │   └── smoke_test.py
│   ├── streaming/
│   │   ├── __init__.py
│   │   └── stream_infer.py
│   ├── train/
│   │   ├── __init__.py
│   │   ├── train_jscm.py
│   │   └── train_sscc.py
│   └── __init__.py
├── artifacts/
│   ├── audio_samples/
│   │   └── .gitkeep
│   ├── figures/
│   │   └── .gitkeep
│   ├── reports/
│   │   └── .gitkeep
│   └── tables/
│       └── .gitkeep
├── checkpoints/
│   ├── jscm/
│   │   └── .gitkeep
│   └── sscc/
│       └── .gitkeep
├── configs/
│   ├── evaluation/
│   │   └── benchmark.yaml
│   ├── model/
│   │   ├── jscm_6k.yaml
│   │   └── sscc_6k.yaml
│   ├── ota/
│   │   └── cable_loopback.yaml
│   ├── radio/
│   │   ├── gnuradio_jscm.yaml
│   │   ├── usrp_rx.yaml
│   │   └── usrp_tx.yaml
│   ├── simulation/
│   └── training/
├── data/
│   ├── audio/
│   │   └── .gitkeep
│   ├── iq/
│   │   └── .gitkeep
│   ├── manifests/
│   │   └── .gitkeep
│   └── raw/
│       └── .gitkeep
├── docs/
│   ├── CHANGELOG_V042.md
│   ├── FILE_TREE.md
│   ├── GNURADIO_USRP_GUIDE.md
│   ├── NEURAL_ARCHITECTURE_HISTORY.md
│   ├── REMAINING_WORK.md
│   ├── SYSTEM_ARCHITECTURE.md
│   ├── system_spec.json
│   ├── V041_VALIDATION_REPORT.md
│   ├── V042_VALIDATION_REPORT.md
│   ├── V050_VALIDATION_REPORT.md
│   └── V051_VALIDATION_REPORT.md
├── experiments/
│   ├── analysis/
│   ├── manifests/
│   ├── ota_protocols/
│   └── sweep/
├── gnuradio/
│   ├── blocks/
│   │   └── continuous_blocks.py
│   ├── grc/
│   │   ├── jscm_rx.grc.todo
│   │   ├── jscm_tx.grc.todo
│   │   ├── opus_rx.grc.todo
│   │   ├── opus_tx.grc.todo
│   │   ├── software_loopback.grc.todo
│   │   ├── sscc_rx.grc.todo
│   │   └── sscc_tx.grc.todo
│   ├── python/
│   │   ├── jscm_rx_flowgraph.py
│   │   ├── jscm_tx_flowgraph.py
│   │   ├── opus_rx_flowgraph.py
│   │   ├── opus_tx_flowgraph.py
│   │   ├── sscc_rx_flowgraph.py
│   │   └── sscc_tx_flowgraph.py
│   ├── scripts/
│   └── README.md
├── runs/
│   ├── calibration/
│   │   └── .gitkeep
│   ├── ota/
│   │   └── .gitkeep
│   ├── profiling/
│   │   └── .gitkeep
│   ├── simulation/
│   │   └── .gitkeep
│   └── training/
│       └── .gitkeep
├── scripts/
├── src/
│   └── jscm/
│       ├── calibration/
│       │   ├── __init__.py
│       │   ├── bandwidth_calibrator.py
│       │   └── fm_gain_calibrator.py
│       ├── channels/
│       │   ├── __init__.py
│       │   ├── awgn.py
│       │   ├── filters.py
│       │   ├── fm.py
│       │   ├── gfsk.py
│       │   └── power_normalization.py
│       ├── data/
│       │   ├── __init__.py
│       │   ├── audio_io.py
│       │   ├── augmentation.py
│       │   ├── collate.py
│       │   ├── librispeech.py
│       │   ├── manifests.py
│       │   └── segmentation.py
│       ├── metrics/
│       │   ├── __init__.py
│       │   ├── metric_utils.py
│       │   ├── objective_metrics.py
│       │   ├── resource_report.py
│       │   └── spectrum_metrics.py
│       ├── neural/
│       │   ├── __init__.py
│       │   ├── freqcodec_backbone.py
│       │   ├── jscm_model.py
│       │   ├── losses.py
│       │   ├── sscc_model.py
│       │   └── stream_state.py
│       ├── profiling/
│       │   ├── __init__.py
│       │   └── runtime_profiler.py
│       ├── protocol/
│       │   ├── __init__.py
│       │   ├── ble_like.py
│       │   ├── constants.py
│       │   ├── deframing.py
│       │   ├── framing.py
│       │   ├── headers.py
│       │   └── radio_packet.py
│       ├── radio/
│       │   ├── __init__.py
│       │   ├── ipc.py
│       │   ├── packet_codec.py
│       │   ├── radio_types.py
│       │   └── zmq_transport.py
│       ├── sync/
│       │   ├── __init__.py
│       │   ├── amplitude_normalizer.py
│       │   ├── cfo_estimator.py
│       │   ├── dc_block.py
│       │   ├── preamble_detector.py
│       │   ├── sync_metrics.py
│       │   └── timing_search.py
│       ├── utils/
│       │   ├── __init__.py
│       │   ├── checkpoint.py
│       │   ├── environment.py
│       │   ├── logging.py
│       │   └── reproducibility.py
│       ├── __init__.py
│       ├── ble_like.py
│       ├── channel_impl.py
│       ├── data_impl.py
│       ├── experiment_utils.py
│       ├── freqcodec_backbone.py
│       ├── gfsk.py
│       ├── gnuradio_blocks.py
│       ├── losses.py
│       ├── manifest.py
│       ├── metric_utils.py
│       ├── models.py
│       ├── objective_metrics.py
│       ├── radio_ipc.py
│       ├── radio_protocol.py
│       ├── resource_report.py
│       ├── spectrum.py
│       ├── sscc.py
│       └── training_runtime.py
├── tests/
│   ├── hardware/
│   ├── integration/
│   │   ├── test_gnuradio_split_v051.py
│   │   └── test_streaming_v05.py
│   ├── unit/
│   │   ├── test_ble_like_v05.py
│   │   ├── test_causality.py
│   │   ├── test_fm_calibration.py
│   │   ├── test_gfsk_calibration.py
│   │   ├── test_loss_aux_v03.py
│   │   ├── test_manifest_sizes_v031.py
│   │   ├── test_manifest_v03.py
│   │   ├── test_metric_aggregation.py
│   │   ├── test_metrics_and_plots.py
│   │   ├── test_model_ablations_v03.py
│   │   ├── test_multisnr_selection_v032.py
│   │   ├── test_objective_metrics_v03.py
│   │   ├── test_opus_noiseless.py
│   │   ├── test_reproducibility_v033.py
│   │   ├── test_resource_report_v03.py
│   │   ├── test_resource_semantics_v033.py
│   │   ├── test_resume_config_v033.py
│   │   ├── test_spectrum_v032.py
│   │   ├── test_sscc.py
│   │   ├── test_training_runtime_v041.py
│   │   ├── test_training_stage.py
│   │   └── test_training_stage_v03.py
│   └── conftest.py
├── usrp/
│   ├── inventory.yaml
│   └── README.md
├── .gitignore
├── pyproject.toml
├── README.md
├── requirements-opus.txt
├── requirements-radio.txt
└── requirements.txt
```

### v0.6.1 SNR-control additions

```text
configs/ota/power_controlled_snr.yaml
src/jscm/calibration/snr_estimator.py
src/jscm/calibration/tx_gain_calibrator.py
apps/calibration/estimate_usrp_snr.py
apps/calibration/fit_tx_gain_snr.py
tests/unit/test_snr_estimator_v061.py
docs/POWER_CONTROLLED_SNR.md
```
