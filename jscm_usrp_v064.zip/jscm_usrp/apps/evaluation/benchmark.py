from __future__ import annotations
from pathlib import Path
import sys
_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(_ROOT / "src"))

import argparse
import json
import math
from pathlib import Path
from typing import Any

import numpy as np
import soundfile as sf
import torch
from torch.utils.data import DataLoader

from apps.evaluation.eval_opus_gfsk import (
    bytes_to_pcm16,
    create_opus_pair,
    opuslib,
    pcm16_bytes,
    transmit_opus_frame,
)
from jscm.experiment_utils import (
    build_model_from_checkpoint,
    build_speech_dataset,
    set_seed,
    write_csv_rows,
)
from jscm.metric_utils import aggregate_metric_records
from jscm.objective_metrics import MetricAccumulator, compute_objective_metrics, dependency_status
from apps.evaluation.eval_sscc import build_sscc_from_checkpoint, evaluate_sscc
from jscm.resource_report import jscm_resource_report, opus_resource_report
from apps.evaluation.plot_metric_curves import plot_metric_curves, read_gain_snr_rows
from apps.calibration.aggregate_gain_sweep import discover_rows, aggregate_rows, write_csv


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run the JSCM-USRP benchmark including SSCC and Opus baselines")
    parser.add_argument("--test-manifest", type=str, default="")
    parser.add_argument("--data-root", type=str, default="")
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--output-dir", default="runs/simulation/benchmark")
    parser.add_argument("--esn0-list", nargs="+", type=float, default=[0, 5, 10, 15, 20])
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--num-workers", type=int, default=4)
    parser.add_argument("--max-segments", type=int, default=1000)
    parser.add_argument("--save-examples", type=int, default=3)
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--framing-mode", choices=["oracle", "detected"], default="detected")
    parser.add_argument("--max-sync-errors", type=int, default=0)
    parser.add_argument("--leading-idle-bits", type=int, default=0)
    parser.add_argument("--skip-opus", action="store_true")
    parser.add_argument(
        "--sscc-checkpoint", type=str, default="",
        help="Optional checkpoint produced by train_sscc.py.",
    )
    parser.add_argument("--allow-non-fm-checkpoint", action="store_true")
    parser.add_argument("--no-plots", action="store_true", help="Do not generate metric-vs-SNR figures")
    parser.add_argument("--plot-formats", nargs="+", default=["png"], choices=["png", "pdf", "svg"])
    parser.add_argument("--gain-snr-file", type=str, default="", help="Optional CSV/JSON with tx_gain_db, sample_snr_db, and/or symbol_esn0_db for the dashboard right panel")
    parser.add_argument("--gain-sweep-root", type=str, default="", help="Optional root containing per-run snr_estimate.json files; automatically aggregated when --gain-snr-file is omitted")
    return parser.parse_args()


def _save_waveform(path: Path, waveform: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    sf.write(path, waveform, 16_000)


def _jscm_row_resources(model, channel_applied: bool) -> dict[str, Any]:
    if not channel_applied:
        return {
            "samples_per_symbol": None,
            "payload_channel_uses_per_frame": None,
            "total_channel_uses_per_frame": None,
            "payload_channel_uses_per_second": None,
            "total_channel_uses_per_second": None,
        }
    return {
        "samples_per_symbol": model.channel.samples_per_symbol,
        "payload_channel_uses_per_frame": model.payload_symbols_per_frame,
        "total_channel_uses_per_frame": model.payload_symbols_per_frame + model.channel.header_symbols,
        "payload_channel_uses_per_second": model.payload_channel_uses_per_second,
        "total_channel_uses_per_second": model.channel_uses_per_second,
    }


def evaluate_jscm(
    model,
    loader: DataLoader,
    output_dir: Path,
    channel_mode: str,
    esn0_db: float | None,
    seed: int,
    save_examples: int,
    framing_mode: str = "oracle",
) -> dict[str, Any]:
    set_seed(seed)
    objective = MetricAccumulator()
    auxiliary_records: list[dict[str, float]] = []
    segment_count = 0
    saved = 0
    with torch.no_grad():
        for batch in loader:
            device = next(model.parameters()).device
            clean = batch["waveform"].to(device, non_blocking=True)
            valid = batch["valid_samples"].to(device, non_blocking=True)
            estimate, aux = model(
                clean,
                esn0_db,
                channel_mode=channel_mode,
                return_aux=True,
                framing_mode=framing_mode,
            )
            auxiliary_record: dict[str, float] = {
                "_num_samples": float(clean.shape[0])
            }
            for key in (
                "latent_mean",
                "latent_rms",
                "latent_peak",
                "tanh_saturation_ratio",
                "tx_symbol_energy",
                "phase_increment_max",
                "phase_increment_limit",
                "frame_success_rate",
            ):
                if key in aux:
                    raw_value = aux[key]
                    value = (
                        float(raw_value.detach())
                        if torch.is_tensor(raw_value)
                        else float(raw_value)
                    )
                    if math.isfinite(value):
                        auxiliary_record[key] = value
            if len(auxiliary_record) > 1:
                auxiliary_records.append(auxiliary_record)

            clean_np = clean.detach().cpu().numpy()
            estimate_np = estimate.detach().cpu().numpy()
            valid_np = valid.detach().cpu().numpy()
            for clean_item, estimate_item, valid_item in zip(
                clean_np, estimate_np, valid_np, strict=True
            ):
                valid_length = int(valid_item)
                reference = clean_item[0, :valid_length]
                reconstructed = estimate_item[0, :valid_length]
                objective.update(compute_objective_metrics(reconstructed, reference))
                if saved < save_examples:
                    suffix = "bypass" if esn0_db is None else f"esn0_{esn0_db:g}"
                    _save_waveform(
                        output_dir / "examples" / f"jscm_{suffix}_{saved:03d}.wav",
                        reconstructed,
                    )
                    saved += 1
                segment_count += 1

    row: dict[str, Any] = {
        "method": "jscm_bypass" if channel_mode == "bypass" else "jscm_fm",
        "channel_applied": channel_mode == "fm",
        "framing_mode": framing_mode if channel_mode == "fm" else "none",
        "reference_bitrate": model.reference_bitrate,
        "esn0_db": esn0_db,
        "segments": segment_count,
        **_jscm_row_resources(model, channel_mode == "fm"),
        **objective.mean(),
        **(aggregate_metric_records(auxiliary_records) if auxiliary_records else {}),
        "ber": float("nan"),
        "decode_failure_rate": (
            1.0 - float(aggregate_metric_records(auxiliary_records).get("frame_success_rate", 1.0))
            if channel_mode == "fm" and auxiliary_records else float("nan")
        ),
    }
    return row


def _opus_codec_frame(frame: np.ndarray, encoder, decoder, bitrate: int) -> tuple[np.ndarray, int, bool]:
    encoder_packet = encoder.encode(pcm16_bytes(frame), frame.size)
    failed = False
    try:
        decoded = decoder.decode(encoder_packet, frame.size, decode_fec=False)
    except Exception:
        failed = True
        decoded = bytes(frame.size * 2)
    return bytes_to_pcm16(decoded, frame.size), len(encoder_packet) * 8, failed


def evaluate_opus(
    dataset,
    output_dir: Path,
    bitrate: int,
    samples_per_symbol: int,
    esn0_db: float | None,
    seed: int,
    save_examples: int,
    framing_mode: str = "detected",
    max_sync_errors: int = 0,
    leading_idle_bits: int = 0,
) -> tuple[dict[str, Any], dict[str, Any]]:
    if opuslib is None:
        raise RuntimeError("opuslib is required for Opus benchmark methods")
    rng = np.random.default_rng(seed)
    objective = MetricAccumulator()
    total_errors = 0
    total_channel_bits = 0
    total_payload_bits = 0
    total_frames = 0
    decode_failures = 0

    for item_index in range(len(dataset)):
        sample = dataset[item_index]
        valid_samples = int(sample["valid_samples"].item())
        clean_padded = sample["waveform"].squeeze(0).numpy()
        encoder, decoder = create_opus_pair(bitrate)
        reconstructed: list[np.ndarray] = []
        for start in range(0, clean_padded.size, 320):
            frame = clean_padded[start : start + 320]
            if esn0_db is None:
                decoded, payload_bits, failed = _opus_codec_frame(
                    frame, encoder, decoder, bitrate
                )
                channel_bits = payload_bits
                errors = 0
            else:
                decoded, errors, channel_bits, payload_bits, failed = transmit_opus_frame(
                    frame,
                    encoder,
                    decoder,
                    bitrate,
                    float(esn0_db),
                    rng,
                    samples_per_symbol,
                    framing_mode=framing_mode,
                    max_sync_errors=max_sync_errors,
                    leading_idle_bits=leading_idle_bits,
                )
            reconstructed.append(decoded)
            total_errors += errors
            total_channel_bits += channel_bits
            total_payload_bits += payload_bits
            total_frames += 1
            decode_failures += int(failed)

        estimate_padded = np.concatenate(reconstructed)[: clean_padded.size]
        reference = clean_padded[:valid_samples]
        estimate = estimate_padded[:valid_samples]
        objective.update(compute_objective_metrics(estimate, reference))
        if item_index < save_examples:
            suffix = "only" if esn0_db is None else f"gfsk_esn0_{esn0_db:g}"
            _save_waveform(
                output_dir / "examples" / f"opus_{suffix}_{item_index:03d}.wav",
                estimate,
            )

    mean_payload = total_payload_bits / max(total_frames, 1)
    mean_total = total_channel_bits / max(total_frames, 1)
    row: dict[str, Any] = {
        "method": "opus_only" if esn0_db is None else "opus_gfsk",
        "channel_applied": esn0_db is not None,
        "framing_mode": framing_mode if esn0_db is not None else "none",
        "reference_bitrate": bitrate,
        "esn0_db": esn0_db,
        "samples_per_symbol": samples_per_symbol if esn0_db is not None else None,
        "segments": len(dataset),
        "payload_channel_uses_per_frame": mean_payload if esn0_db is not None else None,
        "total_channel_uses_per_frame": mean_total if esn0_db is not None else None,
        "payload_channel_uses_per_second": mean_payload * 50.0 if esn0_db is not None else None,
        "total_channel_uses_per_second": mean_total * 50.0 if esn0_db is not None else None,
        "source_payload_bits_per_frame": mean_payload,
        **objective.mean(),
        "ber": total_errors / max(total_channel_bits, 1) if esn0_db is not None else float("nan"),
        "decode_failure_rate": decode_failures / max(total_frames, 1),
    }
    report = opus_resource_report(
        bitrate,
        samples_per_symbol,
        mean_payload_bits_per_frame=mean_payload,
        mean_total_bits_per_frame=(mean_total if esn0_db is not None else mean_payload + 56.0),
    )
    return row, report


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    output_dir = Path(args.output_dir).expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    print(f"objective metric dependencies={dependency_status()}")

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    checkpoint = torch.load(args.checkpoint, map_location=device, weights_only=False)
    if checkpoint.get("stage") == "bypass" and not args.allow_non_fm_checkpoint:
        raise RuntimeError("Use best_fm.pt or pass --allow-non-fm-checkpoint intentionally")
    model = build_model_from_checkpoint(checkpoint, device)

    dataset = build_speech_dataset(
        manifest_path=args.test_manifest or None,
        data_root=args.data_root or None,
        subset="test-clean",
        training=False,
        max_segments=args.max_segments,
        random_gain_db=0.0,
    )
    loader = DataLoader(
        dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,
        pin_memory=device.type == "cuda",
        persistent_workers=args.num_workers > 0,
    )

    rows: list[dict[str, Any]] = []
    rows.append(
        evaluate_jscm(
            model,
            loader,
            output_dir,
            channel_mode="bypass",
            esn0_db=None,
            seed=args.seed,
            save_examples=args.save_examples,
            framing_mode="oracle",
        )
    )
    for esn0 in args.esn0_list:
        rows.append(
            evaluate_jscm(
                model,
                loader,
                output_dir,
                channel_mode="fm",
                esn0_db=float(esn0),
                seed=args.seed,
                save_examples=args.save_examples,
                framing_mode=args.framing_mode,
            )
        )

    resource_reports: dict[str, Any] = {"jscm": jscm_resource_report(model)}

    if args.sscc_checkpoint:
        sscc_checkpoint_data = torch.load(
            args.sscc_checkpoint, map_location=device, weights_only=False
        )
        sscc_model = build_sscc_from_checkpoint(sscc_checkpoint_data, device)
        if sscc_model.reference_bitrate != model.reference_bitrate:
            raise ValueError("JSCM and SSCC checkpoints must use the same reference bitrate")
        rows.append(
            evaluate_sscc(
                sscc_model, loader, output_dir, None,
                model.channel.samples_per_symbol, args.seed, args.save_examples,
                framing_mode=args.framing_mode,
                max_sync_errors=args.max_sync_errors,
                leading_idle_bits=args.leading_idle_bits,
            )
        )
        for esn0 in args.esn0_list:
            rows.append(
                evaluate_sscc(
                    sscc_model, loader, output_dir, float(esn0),
                    model.channel.samples_per_symbol, args.seed, args.save_examples
                )
            )
        resource_reports["sscc"] = {
            **sscc_model.config(),
            "samples_per_symbol": model.channel.samples_per_symbol,
            "overhead_channel_uses_per_frame": 56,
            "total_channel_uses_per_second": (sscc_model.used_payload_bits_per_frame + 56) * 50,
        }
    if not args.skip_opus:
        opus_only, opus_report = evaluate_opus(
            dataset,
            output_dir,
            bitrate=model.reference_bitrate,
            samples_per_symbol=model.channel.samples_per_symbol,
            esn0_db=None,
            seed=args.seed,
            save_examples=args.save_examples,
            framing_mode="oracle",
        )
        rows.append(opus_only)
        for esn0 in args.esn0_list:
            opus_row, opus_report = evaluate_opus(
                dataset,
                output_dir,
                bitrate=model.reference_bitrate,
                samples_per_symbol=model.channel.samples_per_symbol,
                esn0_db=float(esn0),
                seed=args.seed,
                save_examples=args.save_examples,
                framing_mode=args.framing_mode,
                max_sync_errors=args.max_sync_errors,
                leading_idle_bits=args.leading_idle_bits,
            )
            rows.append(opus_row)
        resource_reports["opus"] = opus_report

    write_csv_rows(rows, output_dir / "metrics.csv")
    if not args.no_plots:
        gain_snr_rows: list[dict[str, Any]] = []
        if args.gain_snr_file:
            gain_snr_rows = read_gain_snr_rows(args.gain_snr_file)
        elif args.gain_sweep_root:
            run_rows = discover_rows(args.gain_sweep_root)
            gain_snr_rows = aggregate_rows(run_rows)
            calibration_dir = output_dir / "calibration"
            write_csv(run_rows, calibration_dir / "gain_sweep_runs.csv")
            write_csv(gain_snr_rows, calibration_dir / "gain_sweep.csv")
        plot_metric_curves(
            rows,
            output_dir / "figures",
            gain_snr_rows=gain_snr_rows,
            formats=tuple(args.plot_formats),
        )
    (output_dir / "resource_report.json").write_text(
        json.dumps(resource_reports, indent=2), encoding="utf-8"
    )
    for row in rows:
        print(
            f"{row['method']:12s} Es/N0={str(row['esn0_db']):>5s} "
            f"Wave={float(row.get('waveform_distance', float('nan'))):.4f} "
            f"SegSNR={float(row.get('segsnr_db', float('nan'))):.2f}dB "
            f"PESQ={float(row.get('pesq_wb', float('nan'))):.3f} "
            f"SI-SDR={float(row.get('si_sdr_db', float('nan'))):.2f}dB "
            f"STFT={float(row.get('stft_distance', float('nan'))):.3f} "
            f"STOI={float(row.get('stoi', float('nan'))):.3f} "
            f"BER={float(row.get('ber', float('nan'))):.3e}"
        )


if __name__ == "__main__":
    main()
