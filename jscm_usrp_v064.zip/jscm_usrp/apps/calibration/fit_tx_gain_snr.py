#!/usr/bin/env python3
"""Fit TX gain versus measured SNR/EsN0 from a CSV sweep."""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

from jscm.calibration import fit_gain_calibration


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--csv", required=True)
    parser.add_argument("--gain-column", default="tx_gain_db")
    parser.add_argument("--snr-column", default="symbol_esn0_db")
    parser.add_argument("--target-snr-db", type=float, nargs="*", default=[])
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    gains: list[float] = []
    snrs: list[float] = []
    with open(args.csv, newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            gains.append(float(row[args.gain_column]))
            snrs.append(float(row[args.snr_column]))

    calibration = fit_gain_calibration(gains, snrs)
    result = calibration.to_dict()
    result["target_gain_table"] = [
        {
            "target_snr_db": target,
            "recommended_tx_gain_db": calibration.gain_for_target_snr_db(target),
        }
        for target in args.target_snr_db
    ]
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
