#!/usr/bin/env python3
"""Aggregate per-run USRP SNR estimates into gain-sweep tables.

The script recursively finds ``snr_estimate.json`` files, flattens the receiver
estimates, groups repeated runs by TX gain, and optionally fits a linear
TX-gain-to-SNR calibration over the valid unclipped operating region.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
from collections import defaultdict
from pathlib import Path
from typing import Any

import numpy as np

from jscm.calibration import fit_gain_calibration


def _as_float(value: Any) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return float("nan")


def _nested(data: dict[str, Any], *keys: str) -> Any:
    value: Any = data
    for key in keys:
        if not isinstance(value, dict):
            return None
        value = value.get(key)
    return value


def flatten_estimate(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    sample = data.get("sample_snr") if isinstance(data.get("sample_snr"), dict) else {}
    symbol = data.get("symbol_esn0") if isinstance(data.get("symbol_esn0"), dict) else {}
    metadata = data.get("metadata") if isinstance(data.get("metadata"), dict) else {}

    row: dict[str, Any] = {
        "run_dir": str(path.parent),
        "estimate_file": str(path),
        "tx_gain_db": _as_float(data.get("tx_gain_db", metadata.get("tx_gain_db"))),
        "sample_snr_db": _as_float(sample.get("snr_db")),
        "sample_snr_valid": bool(sample.get("valid", math.isfinite(_as_float(sample.get("snr_db"))))),
        "symbol_esn0_db": _as_float(symbol.get("esn0_db")),
        "symbol_esn0_valid": bool(symbol.get("valid", math.isfinite(_as_float(symbol.get("esn0_db"))))),
        "evm_rms": _as_float(symbol.get("evm_rms")),
        "total_power_dbfs": _as_float(data.get("total_power_dbfs")),
        "noise_power_dbfs": _as_float(data.get("noise_power_dbfs")),
        "signal_power_dbfs": _as_float(data.get("signal_power_dbfs")),
        "clipping_rate": _as_float(data.get("clipping_rate", metadata.get("clipping_rate"))),
        "method": str(data.get("method", metadata.get("method", ""))),
        "sequence_id": data.get("sequence_id", metadata.get("sequence_id", "")),
    }
    return row


def discover_rows(root: str | Path, pattern: str = "**/snr_estimate.json") -> list[dict[str, Any]]:
    root = Path(root)
    paths = sorted(root.glob(pattern))
    return [flatten_estimate(path) for path in paths]


def _finite_values(rows: list[dict[str, Any]], key: str) -> np.ndarray:
    values = np.asarray([_as_float(row.get(key)) for row in rows], dtype=np.float64)
    return values[np.isfinite(values)]


def aggregate_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[float, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        gain = _as_float(row.get("tx_gain_db"))
        if math.isfinite(gain):
            grouped[gain].append(row)

    output: list[dict[str, Any]] = []
    for gain in sorted(grouped):
        group = grouped[gain]
        result: dict[str, Any] = {
            "tx_gain_db": gain,
            "runs": len(group),
        }
        for key in (
            "sample_snr_db",
            "symbol_esn0_db",
            "evm_rms",
            "total_power_dbfs",
            "noise_power_dbfs",
            "signal_power_dbfs",
            "clipping_rate",
        ):
            values = _finite_values(group, key)
            result[key] = float(np.mean(values)) if values.size else float("nan")
            result[f"{key}_std"] = float(np.std(values, ddof=1)) if values.size > 1 else 0.0 if values.size == 1 else float("nan")
            result[f"{key}_count"] = int(values.size)
        result["sample_snr_valid_count"] = int(sum(bool(row.get("sample_snr_valid")) for row in group))
        result["symbol_esn0_valid_count"] = int(sum(bool(row.get("symbol_esn0_valid")) for row in group))
        output.append(result)
    return output


def write_csv(rows: list[dict[str, Any]], path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields: list[str] = []
    for row in rows:
        for key in row:
            if key not in fields:
                fields.append(key)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def fit_calibration(
    aggregated: list[dict[str, Any]],
    snr_key: str,
    clipping_limit: float,
    min_valid_runs: int,
) -> dict[str, Any] | None:
    selected: list[dict[str, Any]] = []
    for row in aggregated:
        gain = _as_float(row.get("tx_gain_db"))
        snr = _as_float(row.get(snr_key))
        clipping = _as_float(row.get("clipping_rate"))
        count_key = "symbol_esn0_valid_count" if snr_key == "symbol_esn0_db" else "sample_snr_valid_count"
        count = int(row.get(count_key, 0))
        clipping_ok = not math.isfinite(clipping) or clipping <= clipping_limit
        if math.isfinite(gain) and math.isfinite(snr) and count >= min_valid_runs and clipping_ok:
            selected.append(row)
    if len(selected) < 2:
        return None
    calibration = fit_gain_calibration(
        [float(row["tx_gain_db"]) for row in selected],
        [float(row[snr_key]) for row in selected],
    )
    result = calibration.to_dict()
    result["snr_column"] = snr_key
    result["clipping_limit"] = clipping_limit
    result["selected_points"] = [
        {"tx_gain_db": row["tx_gain_db"], snr_key: row[snr_key]}
        for row in selected
    ]
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description="Aggregate USRP gain-sweep SNR estimates")
    parser.add_argument("--root", required=True, help="Root directory containing per-run snr_estimate.json files")
    parser.add_argument("--pattern", default="**/snr_estimate.json")
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--fit-snr-column", choices=["sample_snr_db", "symbol_esn0_db"], default="symbol_esn0_db")
    parser.add_argument("--clipping-limit", type=float, default=1e-4)
    parser.add_argument("--min-valid-runs", type=int, default=1)
    parser.add_argument("--target-snr-db", type=float, nargs="*", default=[0, 5, 10, 15, 20])
    args = parser.parse_args()

    rows = discover_rows(args.root, args.pattern)
    if not rows:
        raise RuntimeError(f"No SNR estimate files matched {Path(args.root) / args.pattern}")
    aggregated = aggregate_rows(rows)

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    write_csv(rows, output_dir / "gain_sweep_runs.csv")
    write_csv(aggregated, output_dir / "gain_sweep.csv")

    calibration = fit_calibration(
        aggregated,
        args.fit_snr_column,
        args.clipping_limit,
        args.min_valid_runs,
    )
    result: dict[str, Any] = {
        "root": str(Path(args.root).resolve()),
        "estimate_files": len(rows),
        "gain_points": len(aggregated),
        "fit_snr_column": args.fit_snr_column,
        "measured_points": aggregated,
        "calibration": calibration,
    }
    if calibration is not None:
        slope = float(calibration["slope_db_per_gain_db"])
        intercept = float(calibration["intercept_db"])
        min_gain = float(calibration["min_gain_db"])
        max_gain = float(calibration["max_gain_db"])
        result["target_gain_table"] = [
            {
                "target_snr_db": target,
                "recommended_tx_gain_db": float(np.clip((target - intercept) / slope, min_gain, max_gain)),
            }
            for target in args.target_snr_db
        ]
    else:
        result["target_gain_table"] = []

    json_path = output_dir / "tx_gain_calibration.json"
    json_path.write_text(json.dumps(result, indent=2, allow_nan=True), encoding="utf-8")
    print(json.dumps({
        "gain_sweep_runs_csv": str(output_dir / "gain_sweep_runs.csv"),
        "gain_sweep_csv": str(output_dir / "gain_sweep.csv"),
        "calibration_json": str(json_path),
        "estimate_files": len(rows),
        "gain_points": len(aggregated),
    }, indent=2))


if __name__ == "__main__":
    main()
