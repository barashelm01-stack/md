# JSCM / SSCC / Opus 双X310端到端原型

本工程面向以下固定环境：

- Python 3.9
- PyTorch 2.5.1，FP32
- GNU Radio 3.10.12.0
- 两台USRP X310，`type=x300`，FPGA镜像`HG`
- TX USRP：`192.168.10.1`
- RX USRP：`192.168.10.2`
- LibriSpeech根目录：`/home/data`

工程只保留一条真实端到端组帧/解帧路径。协议仅参考BLE的前导码与Access Address结构，不实现CRC、白化、跳频、ACK或严格BLE链路层。

## 1. 统一真实帧协议

所有JSCM、SSCC和Opus数据共用：

```text
Preamble 8 symbols
Access Address 32 symbols
Header 32 symbols
Payload variable length
Idle symbols
```

Header：

```text
mode            2 bits
control         2 bits
sequence_id    12 bits
payload_length 16 bits
```

模式：

```text
0 = JSCM continuous symbols
1 = SSCC bits
2 = Opus bits
```

控制帧：

```text
0 = DATA
1 = START
2 = END
```

接收端必须依次完成同步搜索、同步字段仿射校正、Header硬判决、长度解析和Payload提取。JSCM的Payload保持连续值；SSCC和Opus的Payload做0/1硬判决。

## 2. 极简工程结构

```text
jscm_usrp/
├── apps/
│   ├── build_grc.py
│   ├── source_tx.py
│   ├── source_rx.py
│   ├── run_e2e_sweep.py
│   └── plot_e2e_results.py
├── configs/
│   └── e2e_x310.yaml
├── gnuradio/
│   ├── grc/e2e_tx.grc
│   ├── grc/e2e_rx.grc
│   ├── grc_blocks/
│   ├── blocks/packet_blocks.py
│   └── scripts/setup_env.sh
├── src/jscm/
│   ├── prototype_framing.py
│   ├── radio_protocol.py
│   ├── radio_ipc.py
│   ├── models.py
│   ├── sscc.py
│   └── objective_metrics.py
└── tests/test_prototype_e2e.py
```

## 3. 安装

```bash
cd jscm_usrp
python3.9 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
pip install -r requirements-opus.txt
```

GNU Radio和UHD应由目标系统安装。确认版本：

```bash
gnuradio-config-info --version
uhd_config_info --version
```

加载工程环境：

```bash
source gnuradio/scripts/setup_env.sh
```

## 4. 检查两台X310

```bash
uhd_usrp_probe --args "addr=192.168.10.1"
uhd_usrp_probe --args "addr=192.168.10.2"
```

必须确认两条命令分别找到TX和RX设备。若`192.168.10.1`实际是主机网卡地址，应先修正USRP地址与配置文件。

推荐有线原型连接：

```text
X310 TX -> 40–60 dB射频衰减 -> X310 RX
```

不要直接将两台USRP射频端口无衰减连接。

## 5. 在GNU Radio Companion中打开流图

```bash
source gnuradio/scripts/setup_env.sh
gnuradio-companion gnuradio/grc/e2e_tx.grc
gnuradio-companion gnuradio/grc/e2e_rx.grc
```

只有两份流图：

- `e2e_tx.grc`：统一组帧符号流、Gaussian成形、FM/GFSK调制、X310发送；
- `e2e_rx.grc`：X310接收、鉴频、匹配滤波、真实同步和Header解析。

## 6. GRC编译

自动扫点前，控制器会为每个TX Gain复制并修改GRC文件，再调用`grcc`生成实际执行脚本。也可手动测试：

```bash
python -m apps.build_grc \
  --build-dir runs/grc_test \
  --tx-gain 10 \
  --rx-gain 20 \
  --center-freq 2.45e9
```

生成：

```text
runs/grc_test/e2e_tx.py
runs/grc_test/e2e_rx.py
```

## 7. 配置端到端扫描

编辑：

```text
configs/e2e_x310.yaml
```

至少修改：

```yaml
test_audio: data/test.wav
checkpoints:
  jscm: runs/jscm_6k/best_fm.pt
  sscc: runs/sscc_6k/best.pt
```

`snr_points`中的`tx_gain_db`应来自提前完成的Gain–SNR标定，而不是把Gain值直接当作SNR：

```yaml
snr_points:
  - {target_snr_db: 0,  tx_gain_db: 2.4}
  - {target_snr_db: 5,  tx_gain_db: 7.1}
  - {target_snr_db: 10, tx_gain_db: 11.9}
  - {target_snr_db: 15, tx_gain_db: 16.7}
  - {target_snr_db: 20, tx_gain_db: 21.5}
```

正式绘图横轴使用同步训练字段测得的`measured_esn0_db`。

## 8. 一键执行三方法全SNR扫描

```bash
source gnuradio/scripts/setup_env.sh
python -m apps.run_e2e_sweep --config configs/e2e_x310.yaml
```

每个测试点会执行：

```text
启动源解码器
-> grcc编译RX/TX GRC
-> 启动RX GRC生成脚本
-> 启动TX GRC生成脚本
-> 启动对应JSCM/SSCC/Opus源编码器
-> 发送START/DATA/END真实帧
-> 接收并真实解帧
-> 保存恢复语音和链路记录
-> 计算语音KPI
-> 汇总并绘图
```

扫描维度：

```text
method ∈ {jscm, sscc, opus}
target SNR ∈ configs/e2e_x310.yaml
repeat ∈ [0, repeats-1]
```

## 9. 输出

```text
runs/e2e_x310/
├── jscm/
├── sscc/
├── opus/
├── summary.csv
└── figures/
    ├── kpi_vs_snr_dashboard.png
    └── kpi_vs_snr_dashboard.pdf
```

单次实验目录包含：

```text
recovered.wav
frame_records.csv
link_metrics.json
metrics.json
source_tx.log
source_rx.log
gr_tx.log
gr_rx.log
grc_build/
```

KPI包括：

- waveform distance；
- SegSNR；
- PESQ-WB；
- SI-SDR；
- multi-resolution STFT distance；
- STOI。

链路记录包括：

- TX Gain；
- 目标SNR；
- 同步字段实测符号域Es/N0；
- 同步幅度比例；
- 鉴频偏置；
- 接收帧数。

## 10. 图像结构

`kpi_vs_snr_dashboard`左侧为六项KPI，三条曲线分别表示JSCM、SSCC和Opus；右侧上图为TX Gain与实测Es/N0，右侧下图为接收帧数与实测Es/N0。

## 11. 测试

无需GNU Radio硬件的协议测试：

```bash
PYTHONPATH=src python -m unittest tests.test_prototype_e2e
```

检查内容：

- 三种模式均经过真实Header路径；
- START/DATA/END协议序列化；
- 同步字段幅度和偏置恢复；
- 工程中只存在两份GRC流图；
- GRC YAML结构可解析。

## 12. 已知边界

当前环境未连接GNU Radio 3.10.12、UHD或X310，因此工程已完成静态实现和协议测试，但以下内容必须在目标主机验证：

- `grcc`对自定义块定义的实际加载；
- X310子板名称和天线端口；
- TX/RX IP可达性；
- 定时相位；
- 高斯滤波器群时延；
- UHD underflow/overflow；
- Gain–SNR标定曲线；
- 实际KPI结果。

## USRP链路全面验证（v0.8.1）

在安装GNU Radio 3.10.12.0、UHD并连接两台X310的主机上运行：

```bash
cd jscm_usrp
source gnuradio/scripts/setup_env.sh
python -m apps.validate_usrp_link --root . --runtime
```

该命令依次检查：

1. 所有Python文件能否被Python 3.9解析；
2. 两份GRC是否包含完整TX/RX链路及正确连接；
3. TX/RX设备地址是否分别为`192.168.10.1`和`192.168.10.2`；
4. TX高斯插值滤波增益是否按SPS补偿；
5. RX是否包含可配置的`timing_phase`；
6. GNU Radio版本是否为3.10.12.0；
7. `uhd_find_devices`及两台X310的`uhd_usrp_probe`；
8. `grcc`能否从`e2e_tx.grc`和`e2e_rx.grc`生成Python流图。

报告保存到：

```text
runs/usrp_link_validation/report.yaml
```

### 为什么两份流图可以复用

三种方法的差异位于源编码/解码和Payload表示层，而不是射频前端：

- JSCM产生连续实值Payload；
- SSCC产生0/1比特Payload；
- Opus产生字节，再转换成0/1比特Payload。

统一TX流图将三种Payload都转换为一个实值频率控制序列：JSCM连续值直接使用，SSCC/Opus比特映射为`-1/+1`。随后三者共用相同的同步字段、Header、高斯成形、FM/GFSK调制、USRP Sink和射频参数。

统一RX流图先完成公共的USRP接收、鉴频、匹配滤波、符号抽取、同步搜索和Header解析。Header中的`mode`字段决定Payload后处理：JSCM保留连续值，SSCC/Opus执行硬判决。因此无需为每种源编码器复制一套射频流图。

复用成立的前提是三种方法使用相同：

- 采样率、符号率和SPS；
- 高斯滤波BT和调制指数；
- 40符号同步字段与32位Header；
- USRP中心频率、带宽及天线端口；
- TX Gain控制与SNR标定流程。

### 本次修正

- TX高斯插值滤波器改为`gain=sps`，补偿插值器插零造成的幅度缩小，保证配置的调制指数`h`与实际频偏一致；
- RX高斯滤波器保持单位直流增益；
- RX GRC增加`timing_phase`与`Skip Head`，支持SPS=4时选择0至3的抽样相位；
- `build_grc.py`增加IP、采样率、符号率、带宽和抽样相位参数校验；
- `grcc`生成失败或未产生Python文件时立即报错；
- 新增`validate_usrp_link.py`，统一执行静态与硬件运行时检查。

## v0.8.2 OTA test safeguards

The automated OTA path now includes repeated START/END controls, finite ZeroMQ linger, receiver timeout, sequence-gap concealment, exact recovered-audio length, and packet-success metrics.

Recommended configuration fields:

```yaml
startup_rx_sec: 3
startup_tx_sec: 2
control_repeats: 3
control_interval_sec: 0.05
tx_drain_sec: 1.0
calibration_json: ""  # optional Gain-to-SNR calibration JSON
```

When `calibration_json` is supplied, an SNR point may omit `tx_gain_db`; the controller derives the gain from the fitted calibration. The final plot always uses measured symbol-domain Es/N0 as its x-axis.

The final figure directory contains:

```text
figures/
├── kpi_vs_snr_dashboard.png
├── kpi_vs_snr_dashboard.pdf
└── aggregated_kpi.csv
```

Run the static audit before OTA operation:

```bash
source gnuradio/scripts/setup_env.sh
python -m apps.validate_usrp_link --root .
```

Run the full target-host audit, including GNU Radio/UHD checks:

```bash
python -m apps.validate_usrp_link --root . --runtime
```
