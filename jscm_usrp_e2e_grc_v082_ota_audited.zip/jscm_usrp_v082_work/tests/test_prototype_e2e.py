from __future__ import annotations
import tempfile,unittest
from pathlib import Path
import numpy as np,yaml
from jscm.prototype_framing import PrototypeMode,ControlType,SYNC_BITS,HEADER_BITS,frame_symbols,find_sync,affine_sync_normalize,parse_header
from jscm.radio_protocol import RadioMode,RadioPacket,ControlType as IPCControl,serialize_packet,deserialize_packet

class PrototypeFrameTests(unittest.TestCase):
    def test_all_modes_real_header_path(self):
        for mode,payload in [(PrototypeMode.JSCM,np.array([.2,-.3,.7],np.float32)),(PrototypeMode.SSCC,np.array([0,1,1,0],np.uint8)),(PrototypeMode.OPUS,np.array([1,0,1],np.uint8))]:
            frame=frame_symbols(mode,ControlType.DATA,23,payload); self.assertEqual(find_sync(frame,0),0)
            normalized,_,_,_=affine_sync_normalize(frame); header=parse_header(normalized[SYNC_BITS:SYNC_BITS+HEADER_BITS]); self.assertEqual(header.mode,mode);self.assertEqual(header.sequence_id,23);self.assertEqual(header.payload_length,payload.size)
    def test_affine_channel_is_removed(self):
        frame=frame_symbols(PrototypeMode.JSCM,ControlType.DATA,1,np.array([.1,-.2],np.float32)); observed=1.7*frame+.25
        normalized,scale,bias,esn0=affine_sync_normalize(observed); self.assertAlmostEqual(scale,1.7,places=5);self.assertAlmostEqual(bias,.25,places=5);self.assertGreater(esn0,80)
    def test_ipc_control_round_trip(self):
        packet=RadioPacket(RadioMode.SSCC_BITS,3,np.array([0,1],np.uint8),16000,1,{'x':1},IPCControl.END); restored=deserialize_packet(serialize_packet(packet));self.assertEqual(restored.control,IPCControl.END);self.assertTrue(np.array_equal(restored.payload,packet.payload))
    def test_only_two_grc_files(self):
        files=sorted(p.name for p in Path('gnuradio/grc').glob('*.grc'));self.assertEqual(files,['e2e_rx.grc','e2e_tx.grc'])
        for p in Path('gnuradio/grc').glob('*.grc'): yaml.safe_load(p.read_text())

if __name__=='__main__':unittest.main()
