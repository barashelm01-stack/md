from __future__ import annotations
import enum, json, struct
from dataclasses import dataclass
from typing import Any, Optional
import numpy as np

MAGIC=b"JSCM"; VERSION=2; _HEADER=struct.Struct("<4sBBHIIQ")
class RadioMode(enum.IntEnum):
    JSCM_CONTINUOUS=0; SSCC_BITS=1; OPUS_BYTES=2
class ControlType(enum.IntEnum):
    DATA=0; START=1; END=2
@dataclass(frozen=True)
class RadioPacket:
    mode: RadioMode; sequence_id: int; payload: np.ndarray
    sample_rate: int=0; timestamp_ns: int=0; metadata: Optional[dict[str,Any]]=None
    control: ControlType=ControlType.DATA
    def normalized_payload(self):
        return np.ascontiguousarray(self.payload, dtype=np.float32 if self.mode==RadioMode.JSCM_CONTINUOUS else np.uint8).reshape(-1)
def serialize_packet(packet: RadioPacket)->bytes:
    payload=packet.normalized_payload(); meta=dict(packet.metadata or {}); meta["control"]=int(packet.control)
    metadata=json.dumps(meta,separators=(",",":")).encode(); header=_HEADER.pack(MAGIC,VERSION,int(packet.mode),len(metadata),payload.size,int(packet.sequence_id),int(packet.timestamp_ns))
    return header+struct.pack("<I",int(packet.sample_rate))+metadata+payload.tobytes()
def deserialize_packet(data:bytes)->RadioPacket:
    minimum=_HEADER.size+4
    if len(data)<minimum: raise ValueError("packet truncated")
    magic,version,mode_value,metadata_len,count,seq,ts=_HEADER.unpack_from(data)
    if magic!=MAGIC or version!=VERSION: raise ValueError("invalid protocol")
    sr=struct.unpack_from("<I",data,_HEADER.size)[0]; start=minimum; end=start+metadata_len
    meta=json.loads(data[start:end].decode()) if metadata_len else {}; control=ControlType(int(meta.pop("control",0)))
    mode=RadioMode(mode_value); dtype=np.float32 if mode==RadioMode.JSCM_CONTINUOUS else np.uint8
    expected=count*np.dtype(dtype).itemsize
    if len(data)-end!=expected: raise ValueError("payload size mismatch")
    return RadioPacket(mode,seq,np.frombuffer(data,dtype=dtype,offset=end,count=count).copy(),sr,ts,meta,control)
