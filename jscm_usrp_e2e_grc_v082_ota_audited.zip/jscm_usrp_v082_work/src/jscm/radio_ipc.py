from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from .radio_protocol import RadioPacket, deserialize_packet, serialize_packet


def _zmq():
    try:
        import zmq
    except ImportError as exc:
        raise RuntimeError("ZeroMQ support requires: pip install pyzmq") from exc
    return zmq


@dataclass
class PacketSender:
    endpoint: str
    bind: bool = False
    high_water_mark: int = 100
    linger_ms: int = 2000

    def __post_init__(self) -> None:
        zmq = _zmq()
        self._context = zmq.Context.instance()
        self._socket = self._context.socket(zmq.PUSH)
        self._socket.setsockopt(zmq.SNDHWM, int(self.high_water_mark))
        self._socket.setsockopt(zmq.LINGER, int(self.linger_ms))
        (self._socket.bind if self.bind else self._socket.connect)(self.endpoint)

    def send(self, packet: RadioPacket) -> None:
        self._socket.send(serialize_packet(packet), copy=False)

    def close(self) -> None:
        self._socket.close(linger=int(self.linger_ms))


@dataclass
class PacketReceiver:
    endpoint: str
    bind: bool = True
    high_water_mark: int = 100
    timeout_ms: Optional[int] = None

    def __post_init__(self) -> None:
        zmq = _zmq()
        self._context = zmq.Context.instance()
        self._socket = self._context.socket(zmq.PULL)
        self._socket.setsockopt(zmq.RCVHWM, int(self.high_water_mark))
        if self.timeout_ms is not None:
            self._socket.setsockopt(zmq.RCVTIMEO, int(self.timeout_ms))
        (self._socket.bind if self.bind else self._socket.connect)(self.endpoint)

    def recv(self) -> RadioPacket:
        zmq = _zmq()
        try:
            data = self._socket.recv()
        except zmq.Again as exc:
            raise TimeoutError(f"timed out waiting for packet on {self.endpoint}") from exc
        return deserialize_packet(data)

    def recv_nonblocking(self) -> Optional[RadioPacket]:
        zmq = _zmq()
        try:
            data = self._socket.recv(flags=zmq.NOBLOCK)
        except zmq.Again:
            return None
        return deserialize_packet(data)

    def close(self) -> None:
        self._socket.close(linger=0)
