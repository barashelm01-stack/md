"""Executable unified X310 TX/RX flowgraphs for GNU Radio 3.10.12."""
from __future__ import annotations
import argparse, signal, sys
from pathlib import Path
_ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(_ROOT/'src')); sys.path.insert(0,str(_ROOT/'gnuradio'/'blocks'))
from gnuradio import analog, blocks, filter, gr, uhd
from gnuradio.filter import firdes
from packet_blocks import UnifiedPacketSource, UnifiedPacketSink

TX_IP='192.168.10.1'; RX_IP='192.168.10.2'; CENTER=2.45e9; FS=4e6; RS=1e6; MCR=200e6

def tx_gaussian_taps(sps, bt):
    # Interpolator inserts sps-1 zeros. DC gain=sps preserves symbol amplitude.
    return list(firdes.gaussian(float(sps), int(sps), float(bt), 4 * int(sps) + 1))

def rx_gaussian_taps(sps, bt):
    # Unit-DC-gain receive matched/low-pass filter.
    return list(firdes.gaussian(1.0, int(sps), float(bt), 4 * int(sps) + 1))

class E2ETX(gr.top_block):
    def __init__(self,endpoint='tcp://127.0.0.1:5555',device_ip=TX_IP,center_freq=CENTER,sample_rate=FS,symbol_rate=RS,tx_gain=10,rf_bandwidth=4e6,antenna='TX/RX',subdev='A:0',bt=.5,h=.5,amplitude=.5,idle_symbols=64):
        gr.top_block.__init__(self,'Unified E2E X310 TX',catch_exceptions=True)
        sps=int(round(sample_rate/symbol_rate)); sensitivity=3.141592653589793*h/sps
        self.source=UnifiedPacketSource(endpoint,True,idle_symbols); self.shape=filter.interp_fir_filter_fff(sps,tx_gaussian_taps(sps,bt)); self.mod=analog.frequency_modulator_fc(sensitivity); self.amp=blocks.multiply_const_cc(amplitude)
        self.usrp=uhd.usrp_sink('addr=%s,master_clock_rate=%g'%(device_ip,MCR),uhd.stream_args(cpu_format='fc32',otw_format='sc16',channels=[0]),'')
        self.usrp.set_subdev_spec(subdev,0); self.usrp.set_samp_rate(sample_rate); self.usrp.set_center_freq(uhd.tune_request(center_freq),0); self.usrp.set_gain(tx_gain,0); self.usrp.set_bandwidth(rf_bandwidth,0); self.usrp.set_antenna(antenna,0)
        self.connect(self.source,self.shape,self.mod,self.amp,self.usrp)

class E2ERX(gr.top_block):
    def __init__(self,endpoint='tcp://127.0.0.1:5556',device_ip=RX_IP,center_freq=CENTER,sample_rate=FS,symbol_rate=RS,rx_gain=20,rf_bandwidth=4e6,antenna='RX2',subdev='A:0',bt=.5,h=.5,timing_phase=0,max_sync_errors=4,iq_record=''):
        gr.top_block.__init__(self,'Unified E2E X310 RX',catch_exceptions=True)
        sps=int(round(sample_rate/symbol_rate)); sensitivity=3.141592653589793*h/sps
        self.usrp=uhd.usrp_source('addr=%s,master_clock_rate=%g'%(device_ip,MCR),uhd.stream_args(cpu_format='fc32',otw_format='sc16',channels=[0]),'')
        self.usrp.set_subdev_spec(subdev,0); self.usrp.set_samp_rate(sample_rate); self.usrp.set_center_freq(uhd.tune_request(center_freq),0); self.usrp.set_gain(rx_gain,0); self.usrp.set_bandwidth(rf_bandwidth,0); self.usrp.set_antenna(antenna,0)
        self.demod=analog.quadrature_demod_cf(1.0/sensitivity); self.skip=blocks.skiphead(gr.sizeof_float,int(timing_phase)); self.match=filter.fir_filter_fff(sps,rx_gaussian_taps(sps,bt)); self.sink=UnifiedPacketSink(endpoint,False,max_sync_errors)
        self.connect(self.usrp,self.demod,self.skip,self.match,self.sink)
        if iq_record:
            self.file=blocks.file_sink(gr.sizeof_gr_complex,iq_record,False); self.connect(self.usrp,self.file)

def run(tb):
    def stop(*_): tb.stop(); tb.wait(); raise SystemExit(0)
    signal.signal(signal.SIGINT,stop); signal.signal(signal.SIGTERM,stop); tb.start(); tb.wait()

def main():
    p=argparse.ArgumentParser(); p.add_argument('direction',choices=['tx','rx']); p.add_argument('--endpoint'); p.add_argument('--tx-gain',type=float,default=10); p.add_argument('--rx-gain',type=float,default=20); p.add_argument('--center-freq',type=float,default=CENTER); p.add_argument('--timing-phase',type=int,default=0); p.add_argument('--iq-record',default=''); a=p.parse_args()
    if a.direction=='tx': run(E2ETX(endpoint=a.endpoint or 'tcp://127.0.0.1:5555',tx_gain=a.tx_gain,center_freq=a.center_freq))
    else: run(E2ERX(endpoint=a.endpoint or 'tcp://127.0.0.1:5556',rx_gain=a.rx_gain,center_freq=a.center_freq,timing_phase=a.timing_phase,iq_record=a.iq_record))
if __name__=='__main__': main()
