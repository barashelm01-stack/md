from __future__ import annotations

import argparse
import time

import numpy as np
import soundfile as sf
import torch

from jscm.experiment_utils import load_checkpoint
from jscm.models import JSCMSystem
from jscm.radio_ipc import PacketSender
from jscm.radio_protocol import ControlType, RadioMode, RadioPacket
from jscm.sscc import SSCCSystem


def _load_model(cls, path, device):
    if not path:
        raise ValueError(f"checkpoint is required for {cls.__name__}")
    checkpoint = load_checkpoint(path, map_location=device)
    config = checkpoint.get("model_config", checkpoint.get("config", {}))
    kwargs = {key: value for key, value in config.items() if key in cls.__init__.__code__.co_varnames}
    model = cls(**kwargs)
    model.load_state_dict(checkpoint["model"])
    return model.to(device).eval()


def _send_control(sender, mode, control, repeats, interval_sec, audio_samples=0):
    dtype = np.float32 if mode == RadioMode.JSCM_CONTINUOUS else np.uint8
    for _ in range(max(1, repeats)):
        sender.send(
            RadioPacket(
                mode=mode,
                sequence_id=0,
                payload=np.empty(0, dtype=dtype),
                sample_rate=16000,
                timestamp_ns=time.time_ns(),
                metadata={"audio_samples": int(audio_samples)},
                control=control,
            )
        )
        if interval_sec > 0:
            time.sleep(interval_sec)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--method", choices=["jscm", "sscc", "opus"], required=True)
    parser.add_argument("--checkpoint", default="")
    parser.add_argument("--input", required=True)
    parser.add_argument("--endpoint", default="tcp://127.0.0.1:5555")
    parser.add_argument("--bitrate", type=int, default=6000)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--control-repeats", type=int, default=3)
    parser.add_argument("--control-interval-sec", type=float, default=0.05)
    parser.add_argument("--drain-sec", type=float, default=1.0)
    args = parser.parse_args()

    audio, sample_rate = sf.read(args.input, dtype="float32", always_2d=False)
    audio = audio.mean(1) if audio.ndim > 1 else audio
    if sample_rate != 16000:
        raise ValueError("input must be 16 kHz")

    sender = PacketSender(args.endpoint, bind=False, high_water_mark=2000, linger_ms=3000)
    mode = {
        "jscm": RadioMode.JSCM_CONTINUOUS,
        "sscc": RadioMode.SSCC_BITS,
        "opus": RadioMode.OPUS_BYTES,
    }[args.method]
    frame_samples = 320

    try:
        _send_control(
            sender,
            mode,
            ControlType.START,
            args.control_repeats,
            args.control_interval_sec,
            audio_samples=int(audio.size),
        )

        if args.method == "jscm":
            model = _load_model(JSCMSystem, args.checkpoint, args.device)
            state = model.init_encoder_stream_state(
                1, torch.device(args.device), next(model.parameters()).dtype
            )
            with torch.inference_mode():
                for frame_index, start in enumerate(range(0, audio.size, frame_samples)):
                    chunk = audio[start : start + frame_samples]
                    frame = np.zeros(frame_samples, np.float32)
                    frame[: chunk.size] = chunk
                    symbols, state = model.encode_source_stream(
                        torch.from_numpy(frame).view(1, 1, -1).to(args.device), state
                    )
                    sender.send(
                        RadioPacket(
                            mode,
                            frame_index & 0xFFF,
                            symbols.squeeze().float().cpu().numpy(),
                            16000,
                            time.time_ns(),
                            {},
                            ControlType.DATA,
                        )
                    )
        elif args.method == "sscc":
            model = _load_model(SSCCSystem, args.checkpoint, args.device)
            state = model.init_encoder_stream_state(
                1, torch.device(args.device), next(model.parameters()).dtype
            )
            with torch.inference_mode():
                for frame_index, start in enumerate(range(0, audio.size, frame_samples)):
                    chunk = audio[start : start + frame_samples]
                    frame = np.zeros(frame_samples, np.float32)
                    frame[: chunk.size] = chunk
                    bits, state = model.encode_source_stream(
                        torch.from_numpy(frame).view(1, 1, -1).to(args.device), state
                    )
                    sender.send(
                        RadioPacket(
                            mode,
                            frame_index & 0xFFF,
                            bits.reshape(-1),
                            16000,
                            time.time_ns(),
                            {},
                            ControlType.DATA,
                        )
                    )
        else:
            import opuslib

            encoder = opuslib.Encoder(16000, 1, opuslib.APPLICATION_VOIP)
            encoder.bitrate = args.bitrate
            encoder.vbr = False
            for frame_index, start in enumerate(range(0, audio.size, frame_samples)):
                chunk = audio[start : start + frame_samples]
                frame = np.zeros(frame_samples, np.float32)
                frame[: chunk.size] = chunk
                pcm = np.round(np.clip(frame, -1, 1) * 32767).astype("<i2").tobytes()
                encoded = encoder.encode(pcm, frame_samples)
                bits = np.unpackbits(np.frombuffer(encoded, np.uint8), bitorder="little")
                sender.send(
                    RadioPacket(
                        mode,
                        frame_index & 0xFFF,
                        bits,
                        16000,
                        time.time_ns(),
                        {"opus_bytes": len(encoded)},
                        ControlType.DATA,
                    )
                )

        _send_control(
            sender,
            mode,
            ControlType.END,
            args.control_repeats,
            args.control_interval_sec,
        )
        time.sleep(max(0.0, args.drain_sec))
    finally:
        sender.close()


if __name__ == "__main__":
    main()
