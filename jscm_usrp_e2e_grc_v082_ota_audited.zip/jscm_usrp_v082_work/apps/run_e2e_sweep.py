from __future__ import annotations

import argparse
import csv
import json
import math
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

import numpy as np
import soundfile as sf
import yaml

from jscm.objective_metrics import compute_objective_metrics


def launch(command, log_path, environment):
    handle = open(log_path, "w", encoding="utf-8")
    process = subprocess.Popen(
        command,
        stdout=handle,
        stderr=subprocess.STDOUT,
        env=environment,
        start_new_session=True,
    )
    return process, handle


def ensure_running(process, name):
    return_code = process.poll()
    if return_code is not None:
        raise RuntimeError(f"{name} exited during startup with code {return_code}")


def stop(process):
    if process is not None and process.poll() is None:
        os.killpg(process.pid, signal.SIGTERM)
        try:
            process.wait(timeout=8)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait(timeout=3)


def read_audio(path):
    waveform, sample_rate = sf.read(path, dtype="float32", always_2d=False)
    waveform = waveform.mean(axis=1) if waveform.ndim > 1 else waveform
    if sample_rate != 16000:
        raise ValueError(f"test audio must be 16 kHz, got {sample_rate}")
    if waveform.size == 0:
        raise ValueError("test audio is empty")
    return np.asarray(waveform, dtype=np.float32), sample_rate


def evaluate(reference_path, recovered_path):
    reference, _ = read_audio(reference_path)
    recovered, _ = read_audio(recovered_path)
    if recovered.size != reference.size:
        raise ValueError(
            f"recovered length {recovered.size} does not match reference length {reference.size}"
        )
    return compute_objective_metrics(recovered, reference)


def load_calibration(path):
    if not path:
        return None
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    slope = float(data["slope_db_per_gain_db"])
    intercept = float(data["intercept_db"])
    min_gain = float(data["min_gain_db"])
    max_gain = float(data["max_gain_db"])
    if abs(slope) < 1e-12:
        raise ValueError("calibration slope is zero")
    return slope, intercept, min_gain, max_gain


def resolve_gain(point, calibration):
    if "tx_gain_db" in point and point["tx_gain_db"] is not None:
        return float(point["tx_gain_db"])
    if calibration is None:
        raise ValueError("snr point has no tx_gain_db and no calibration_json is configured")
    target = float(point["target_snr_db"])
    slope, intercept, min_gain, max_gain = calibration
    return float(np.clip((target - intercept) / slope, min_gain, max_gain))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/e2e_x310.yaml")
    args = parser.parse_args()

    config_path = Path(args.config).resolve()
    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    project_root = Path.cwd().resolve()
    output_root = Path(config["output_root"]).resolve()
    output_root.mkdir(parents=True, exist_ok=True)

    test_audio = Path(config["test_audio"]).resolve()
    if not test_audio.is_file():
        raise FileNotFoundError(test_audio)
    reference_audio, _ = read_audio(test_audio)
    expected_samples = int(reference_audio.size)
    expected_frames = int(math.ceil(expected_samples / 320.0))

    environment = os.environ.copy()
    environment["PYTHONPATH"] = (
        str(project_root / "src")
        + os.pathsep
        + str(project_root)
        + os.pathsep
        + environment.get("PYTHONPATH", "")
    )

    calibration = load_calibration(config.get("calibration_json", ""))
    rows = []
    startup_rx_sec = float(config.get("startup_rx_sec", 3.0))
    startup_tx_sec = float(config.get("startup_tx_sec", 2.0))
    timeout_sec = float(config.get("run_timeout_sec", 180.0))

    for method in config["methods"]:
        checkpoint = config.get("checkpoints", {}).get(method, "")
        if method in ("jscm", "sscc") and not Path(checkpoint).is_file():
            raise FileNotFoundError(f"{method} checkpoint not found: {checkpoint}")

        for point in config["snr_points"]:
            target_snr = float(point["target_snr_db"])
            tx_gain = resolve_gain(point, calibration)

            for repeat in range(int(config.get("repeats", 1))):
                run_dir = (
                    output_root
                    / method
                    / ("target_%gdb" % target_snr)
                    / ("repeat_%02d" % repeat)
                )
                run_dir.mkdir(parents=True, exist_ok=True)
                processes = []
                handles = []
                row = {
                    "method": method,
                    "target_snr_db": target_snr,
                    "tx_gain_db": tx_gain,
                    "repeat": repeat,
                    "success": False,
                }

                try:
                    source_rx_command = [
                        sys.executable,
                        "-m",
                        "apps.source_rx",
                        "--method",
                        method,
                        "--output-dir",
                        str(run_dir),
                        "--endpoint",
                        "tcp://0.0.0.0:5556",
                        "--timeout-sec",
                        str(timeout_sec),
                        "--expected-frames",
                        str(expected_frames),
                        "--expected-samples",
                        str(expected_samples),
                    ]
                    if checkpoint:
                        source_rx_command += ["--checkpoint", checkpoint]
                    process, handle = launch(
                        source_rx_command, run_dir / "source_rx.log", environment
                    )
                    processes.append(process)
                    handles.append(handle)
                    time.sleep(1.0)
                    ensure_running(process, "source receiver")

                    build_dir = run_dir / "grc_build"
                    build_command = [
                        sys.executable,
                        "-m",
                        "apps.build_grc",
                        "--build-dir",
                        str(build_dir),
                        "--tx-ip",
                        str(config["usrp"]["tx_ip"]),
                        "--rx-ip",
                        str(config["usrp"]["rx_ip"]),
                        "--tx-gain",
                        str(tx_gain),
                        "--rx-gain",
                        str(config["usrp"]["rx_gain_db"]),
                        "--center-freq",
                        str(config["usrp"]["center_freq_hz"]),
                        "--sample-rate",
                        str(config["radio"]["sample_rate"]),
                        "--symbol-rate",
                        str(config["radio"]["symbol_rate"]),
                        "--rf-bandwidth",
                        str(
                            config["usrp"].get(
                                "rf_bandwidth_hz", config["radio"]["sample_rate"]
                            )
                        ),
                        "--timing-phase",
                        str(config["radio"].get("timing_phase", 0)),
                    ]
                    subprocess.run(build_command, env=environment, check=True)

                    rx_process, rx_handle = launch(
                        [sys.executable, str(build_dir / "e2e_rx.py")],
                        run_dir / "gr_rx.log",
                        environment,
                    )
                    processes.append(rx_process)
                    handles.append(rx_handle)
                    time.sleep(startup_rx_sec)
                    ensure_running(rx_process, "GNU Radio RX")

                    tx_process, tx_handle = launch(
                        [sys.executable, str(build_dir / "e2e_tx.py")],
                        run_dir / "gr_tx.log",
                        environment,
                    )
                    processes.append(tx_process)
                    handles.append(tx_handle)
                    time.sleep(startup_tx_sec)
                    ensure_running(tx_process, "GNU Radio TX")
                    ensure_running(rx_process, "GNU Radio RX")

                    source_tx_command = [
                        sys.executable,
                        "-m",
                        "apps.source_tx",
                        "--method",
                        method,
                        "--input",
                        str(test_audio),
                        "--endpoint",
                        "tcp://127.0.0.1:5555",
                        "--bitrate",
                        str(config.get("opus_bitrate", 6000)),
                        "--control-repeats",
                        str(config.get("control_repeats", 3)),
                        "--control-interval-sec",
                        str(config.get("control_interval_sec", 0.05)),
                        "--drain-sec",
                        str(config.get("tx_drain_sec", 1.0)),
                    ]
                    if checkpoint:
                        source_tx_command += ["--checkpoint", checkpoint]
                    with open(run_dir / "source_tx.log", "w", encoding="utf-8") as tx_log:
                        completed = subprocess.run(
                            source_tx_command,
                            stdout=tx_log,
                            stderr=subprocess.STDOUT,
                            env=environment,
                            timeout=timeout_sec,
                            check=False,
                        )
                    if completed.returncode != 0:
                        raise RuntimeError(f"source TX failed with code {completed.returncode}")

                    processes[0].wait(timeout=timeout_sec)
                    if processes[0].returncode != 0:
                        raise RuntimeError(
                            f"source RX failed with code {processes[0].returncode}; see source_rx.log"
                        )

                    metrics = evaluate(test_audio, run_dir / "recovered.wav")
                    link_metrics = json.loads(
                        (run_dir / "link_metrics.json").read_text(encoding="utf-8")
                    )
                    if not link_metrics.get("end_received", False):
                        raise RuntimeError("END control frame was not received")
                    measured_esn0 = link_metrics.get("mean_symbol_esn0_db")
                    if measured_esn0 is None or not math.isfinite(float(measured_esn0)):
                        raise RuntimeError("no finite symbol-domain Es/N0 measurement")

                    row.update(
                        {
                            "success": True,
                            "measured_esn0_db": float(measured_esn0),
                            **metrics,
                            **link_metrics,
                        }
                    )
                    (run_dir / "metrics.json").write_text(
                        json.dumps(row, indent=2), encoding="utf-8"
                    )
                    (run_dir / "status.json").write_text(
                        json.dumps({"success": True}, indent=2), encoding="utf-8"
                    )
                except Exception as exc:
                    row["error"] = str(exc)
                    (run_dir / "status.json").write_text(
                        json.dumps({"success": False, "error": str(exc)}, indent=2),
                        encoding="utf-8",
                    )
                finally:
                    for process in reversed(processes):
                        stop(process)
                    for handle in handles:
                        handle.close()
                    rows.append(row)

    fieldnames = sorted({key for row in rows for key in row})
    summary_path = output_root / "summary.csv"
    with summary_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    plot_completed = subprocess.run(
        [
            sys.executable,
            "-m",
            "apps.plot_e2e_results",
            "--csv",
            str(summary_path),
            "--output-dir",
            str(output_root / "figures"),
        ],
        env=environment,
        check=False,
    )
    if plot_completed.returncode != 0:
        raise RuntimeError("plot_e2e_results failed")


if __name__ == "__main__":
    main()
