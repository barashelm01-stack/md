from __future__ import annotations

import argparse
import shutil
import subprocess
from pathlib import Path
from typing import Any, Dict

import yaml


def _set_parameter(blocks: list, block_name: str, key: str, value: Any) -> None:
    for block in blocks:
        if block.get("name") == block_name:
            block.setdefault("parameters", {})[key] = str(value)
            return
    raise KeyError(f"GRC block not found: {block_name}")


def patch(
    source: Path,
    target: Path,
    project_root: Path,
    tx_ip: str,
    rx_ip: str,
    tx_gain: float,
    rx_gain: float,
    center_freq: float,
    sample_rate: float,
    symbol_rate: float,
    rf_bandwidth: float,
    timing_phase: int,
) -> None:
    data: Dict[str, Any] = yaml.safe_load(source.read_text(encoding="utf-8"))
    blocks = data.get("blocks", [])
    _set_parameter(blocks, "project_root", "value", repr(str(project_root)))
    _set_parameter(blocks, "samp_rate", "value", sample_rate)
    _set_parameter(blocks, "symbol_rate", "value", symbol_rate)
    if source.name == "e2e_tx.grc":
        _set_parameter(blocks, "usrp_sink", "dev_addr", f"addr={tx_ip},master_clock_rate=200e6")
        _set_parameter(blocks, "usrp_sink", "gain0", tx_gain)
        _set_parameter(blocks, "usrp_sink", "center_freq0", center_freq)
        _set_parameter(blocks, "usrp_sink", "bandwidth0", rf_bandwidth)
    else:
        _set_parameter(blocks, "usrp_source", "dev_addr", f"addr={rx_ip},master_clock_rate=200e6")
        _set_parameter(blocks, "usrp_source", "gain0", rx_gain)
        _set_parameter(blocks, "usrp_source", "center_freq0", center_freq)
        _set_parameter(blocks, "usrp_source", "bandwidth0", rf_bandwidth)
        _set_parameter(blocks, "timing_phase", "value", timing_phase)
    target.write_text(yaml.safe_dump(data, sort_keys=False), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description="Patch and compile the two unified GNU Radio GRC flowgraphs")
    parser.add_argument("--build-dir", required=True)
    parser.add_argument("--tx-ip", default="192.168.10.1")
    parser.add_argument("--rx-ip", default="192.168.10.2")
    parser.add_argument("--tx-gain", type=float, required=True)
    parser.add_argument("--rx-gain", type=float, default=20.0)
    parser.add_argument("--center-freq", type=float, default=2.45e9)
    parser.add_argument("--sample-rate", type=float, default=4e6)
    parser.add_argument("--symbol-rate", type=float, default=1e6)
    parser.add_argument("--rf-bandwidth", type=float, default=4e6)
    parser.add_argument("--timing-phase", type=int, default=0)
    args = parser.parse_args()

    if shutil.which("grcc") is None:
        raise RuntimeError("grcc is not installed or not on PATH")
    ratio = args.sample_rate / args.symbol_rate
    if abs(ratio - round(ratio)) > 1e-9 or round(ratio) < 2:
        raise ValueError("sample_rate/symbol_rate must be an integer SPS >= 2")
    sps = int(round(ratio))
    if not 0 <= args.timing_phase < sps:
        raise ValueError(f"timing_phase must be in [0, {sps - 1}]")

    root = Path.cwd().resolve()
    build = Path(args.build_dir).resolve()
    build.mkdir(parents=True, exist_ok=True)
    for name in ("e2e_tx.grc", "e2e_rx.grc"):
        patch(
            root / "gnuradio/grc" / name,
            build / name,
            root,
            args.tx_ip,
            args.rx_ip,
            args.tx_gain,
            args.rx_gain,
            args.center_freq,
            args.sample_rate,
            args.symbol_rate,
            args.rf_bandwidth,
            args.timing_phase,
        )
        completed = subprocess.run(
            ["grcc", "-d", str(build), str(build / name)],
            text=True,
            capture_output=True,
            check=False,
        )
        (build / f"{name}.grcc.log").write_text(
            completed.stdout + "\n" + completed.stderr, encoding="utf-8"
        )
        if completed.returncode != 0:
            raise RuntimeError(f"grcc failed for {name}; see {name}.grcc.log")
        generated = build / (Path(name).stem + ".py")
        if not generated.is_file():
            raise RuntimeError(f"grcc did not generate {generated}")


if __name__ == "__main__":
    main()
