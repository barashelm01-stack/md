from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np
import soundfile as sf
import torch

from jscm.experiment_utils import load_checkpoint
from jscm.models import JSCMSystem
from jscm.radio_ipc import PacketReceiver
from jscm.radio_protocol import ControlType
from jscm.sscc import SSCCSystem


def _load_model(cls, path, device):
    if not path:
        raise ValueError(f"checkpoint is required for {cls.__name__}")
    checkpoint = load_checkpoint(path, map_location=device)
    config = checkpoint.get("model_config", checkpoint.get("config", {}))
    kwargs = {key: value for key, value in config.items() if key in cls.__init__.__code__.co_varnames}
    model = cls(**kwargs)
    model.load_state_dict(checkpoint["model"])
    return model.to(device).eval()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--method", choices=["jscm", "sscc", "opus"], required=True)
    parser.add_argument("--checkpoint", default="")
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--endpoint", default="tcp://0.0.0.0:5556")
    parser.add_argument("--timeout-sec", type=float, default=120.0)
    parser.add_argument("--expected-frames", type=int, required=True)
    parser.add_argument("--expected-samples", type=int, required=True)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    receiver = PacketReceiver(
        args.endpoint,
        bind=True,
        high_water_mark=2000,
        timeout_ms=max(1, int(args.timeout_sec * 1000)),
    )

    audio_frames = []
    records = []
    seen_sequences = set()
    expected_sequence = 0
    started = False
    end_received = False
    start_packets = 0
    end_packets = 0
    duplicate_packets = 0
    out_of_order_packets = 0
    missing_packets = 0

    if args.method == "jscm":
        model = _load_model(JSCMSystem, args.checkpoint, args.device)
        state = model.init_decoder_stream_state(
            1, torch.device(args.device), next(model.parameters()).dtype
        )
        conceal_payload = np.zeros(model.payload_symbols_per_frame, dtype=np.float32)
    elif args.method == "sscc":
        model = _load_model(SSCCSystem, args.checkpoint, args.device)
        state = model.init_decoder_stream_state(
            1, torch.device(args.device), next(model.parameters()).dtype
        )
        conceal_payload = np.zeros(model.used_payload_bits_per_frame, dtype=np.uint8)
    else:
        import opuslib

        decoder = opuslib.Decoder(16000, 1)
        conceal_payload = None

    def decode_payload(payload, esn0_db=None, conceal=False):
        nonlocal state
        if args.method == "jscm":
            tensor = torch.from_numpy(np.asarray(payload, dtype=np.float32)).view(1, 1, -1).to(args.device)
            with torch.inference_mode():
                frame, state = model.decode_source_stream(tensor, state, esn0_db=esn0_db)
            return frame.squeeze().float().cpu().numpy()
        if args.method == "sscc":
            with torch.inference_mode():
                frame, state = model.decode_source_stream(np.asarray(payload, dtype=np.uint8), state)
            return frame.squeeze().float().cpu().numpy()
        if conceal:
            pcm = decoder.decode(b"", 320, decode_fec=False)
        else:
            bits = np.asarray(payload, np.uint8)
            raw = np.packbits(bits, bitorder="little").tobytes()
            try:
                pcm = decoder.decode(raw, 320, decode_fec=False)
            except Exception:
                pcm = decoder.decode(b"", 320, decode_fec=False)
        return np.frombuffer(pcm, dtype="<i2").astype(np.float32) / 32768.0

    try:
        while True:
            packet = receiver.recv()
            metadata = packet.metadata or {}
            record = {
                "sequence_id": packet.sequence_id,
                "control": int(packet.control),
                "symbol_esn0_db": metadata.get("symbol_esn0_db"),
                "sync_scale": metadata.get("sync_scale"),
                "sync_bias": metadata.get("sync_bias"),
                "accepted": False,
                "event": "",
            }

            if packet.control == ControlType.START:
                start_packets += 1
                started = True
                record["accepted"] = True
                record["event"] = "start"
                records.append(record)
                continue
            if packet.control == ControlType.END:
                end_packets += 1
                end_received = True
                record["accepted"] = True
                record["event"] = "end"
                records.append(record)
                break
            if not started:
                record["event"] = "data_before_start"
                records.append(record)
                continue

            sequence = int(packet.sequence_id) & 0xFFF
            if sequence in seen_sequences:
                duplicate_packets += 1
                record["event"] = "duplicate"
                records.append(record)
                continue

            forward_gap = (sequence - expected_sequence) & 0xFFF
            if forward_gap >= 2048:
                out_of_order_packets += 1
                record["event"] = "out_of_order"
                records.append(record)
                continue

            for _ in range(forward_gap):
                missing_packets += 1
                audio_frames.append(decode_payload(conceal_payload, conceal=True))
                expected_sequence = (expected_sequence + 1) & 0xFFF

            esn0 = metadata.get("symbol_esn0_db")
            esn0_value = float(esn0) if esn0 is not None and math.isfinite(float(esn0)) else None
            audio_frames.append(decode_payload(packet.payload, esn0_db=esn0_value))
            seen_sequences.add(sequence)
            expected_sequence = (sequence + 1) & 0xFFF
            record["accepted"] = True
            record["event"] = "data"
            records.append(record)
    finally:
        receiver.close()

    while len(audio_frames) < args.expected_frames:
        missing_packets += 1
        audio_frames.append(decode_payload(conceal_payload, conceal=True))

    audio_frames = audio_frames[: args.expected_frames]
    recovered = np.concatenate(audio_frames) if audio_frames else np.zeros(0, np.float32)
    recovered = recovered[: args.expected_samples]
    if recovered.size < args.expected_samples:
        recovered = np.pad(recovered, (0, args.expected_samples - recovered.size))
    sf.write(output_dir / "recovered.wav", recovered, 16000)

    fieldnames = [
        "sequence_id",
        "control",
        "symbol_esn0_db",
        "sync_scale",
        "sync_bias",
        "accepted",
        "event",
    ]
    with (output_dir / "frame_records.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(records)

    esn0_values = [
        float(record["symbol_esn0_db"])
        for record in records
        if record["accepted"]
        and record["event"] == "data"
        and record["symbol_esn0_db"] is not None
        and math.isfinite(float(record["symbol_esn0_db"]))
    ]
    received_data = sum(record["event"] == "data" and record["accepted"] for record in records)
    packet_success_rate = received_data / max(args.expected_frames, 1)
    link_metrics = {
        "expected_frames": int(args.expected_frames),
        "frames_received": int(received_data),
        "frames_missing": int(missing_packets),
        "duplicate_packets": int(duplicate_packets),
        "out_of_order_packets": int(out_of_order_packets),
        "start_packets_received": int(start_packets),
        "end_packets_received": int(end_packets),
        "end_received": bool(end_received),
        "packet_success_rate": float(packet_success_rate),
        "mean_symbol_esn0_db": float(np.mean(esn0_values)) if esn0_values else None,
        "std_symbol_esn0_db": float(np.std(esn0_values)) if esn0_values else None,
    }
    (output_dir / "link_metrics.json").write_text(
        json.dumps(link_metrics, indent=2), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
