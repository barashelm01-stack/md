from __future__ import annotations

import argparse
import importlib.util
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, List

import yaml

EXPECTED_GR_VERSION = "3.10.12.0"
EXPECTED_TX_IP = "192.168.10.1"
EXPECTED_RX_IP = "192.168.10.2"


def _run(command: List[str]) -> Dict[str, Any]:
    completed = subprocess.run(command, text=True, capture_output=True, check=False)
    return {
        "command": command,
        "returncode": completed.returncode,
        "stdout": completed.stdout.strip(),
        "stderr": completed.stderr.strip(),
    }


def _block_map(data: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    return {block["name"]: block for block in data.get("blocks", [])}


def validate_grc(root: Path) -> List[str]:
    errors: List[str] = []
    tx_path = root / "gnuradio/grc/e2e_tx.grc"
    rx_path = root / "gnuradio/grc/e2e_rx.grc"
    tx = yaml.safe_load(tx_path.read_text(encoding="utf-8"))
    rx = yaml.safe_load(rx_path.read_text(encoding="utf-8"))
    txb = _block_map(tx)
    rxb = _block_map(rx)

    required_tx = {"packet_source", "gaussian_interp", "fm_mod", "tx_amp", "usrp_sink"}
    required_rx = {"usrp_source", "quad_demod", "timing_skip", "matched_decim", "packet_sink"}
    errors.extend([f"TX GRC missing block: {name}" for name in sorted(required_tx - set(txb))])
    errors.extend([f"RX GRC missing block: {name}" for name in sorted(required_rx - set(rxb))])

    tx_addr = str(txb.get("usrp_sink", {}).get("parameters", {}).get("dev_addr", ""))
    rx_addr = str(rxb.get("usrp_source", {}).get("parameters", {}).get("dev_addr", ""))
    if f"addr={EXPECTED_TX_IP}" not in tx_addr:
        errors.append(f"TX device address is not {EXPECTED_TX_IP}: {tx_addr}")
    if f"addr={EXPECTED_RX_IP}" not in rx_addr:
        errors.append(f"RX device address is not {EXPECTED_RX_IP}: {rx_addr}")

    if txb.get("tx_gaussian_taps", {}).get("parameters", {}).get("value") != "firdes.gaussian(sps, sps, bt, 4*sps+1)":
        errors.append("TX Gaussian taps must use gain=sps to preserve symbol amplitude after interpolation")
    if rxb.get("rx_gaussian_taps", {}).get("parameters", {}).get("value") != "firdes.gaussian(1.0, sps, bt, 4*sps+1)":
        errors.append("RX Gaussian taps must use unit DC gain")

    tx_connections = {tuple(item) for item in tx.get("connections", [])}
    rx_connections = {tuple(item) for item in rx.get("connections", [])}
    expected_tx_connections = {
        ("packet_source", "0", "gaussian_interp", "0"),
        ("gaussian_interp", "0", "fm_mod", "0"),
        ("fm_mod", "0", "tx_amp", "0"),
        ("tx_amp", "0", "usrp_sink", "0"),
    }
    expected_rx_connections = {
        ("usrp_source", "0", "quad_demod", "0"),
        ("quad_demod", "0", "timing_skip", "0"),
        ("timing_skip", "0", "matched_decim", "0"),
        ("matched_decim", "0", "packet_sink", "0"),
    }
    errors.extend([f"TX GRC missing connection: {item}" for item in sorted(expected_tx_connections - tx_connections)])
    errors.extend([f"RX GRC missing connection: {item}" for item in sorted(expected_rx_connections - rx_connections)])

    if str(txb.get("packet_source", {}).get("parameters", {}).get("bind")) != "True":
        errors.append("TX GNU Radio packet source must bind the local PULL endpoint")
    if str(rxb.get("packet_sink", {}).get("parameters", {}).get("bind")) != "False":
        errors.append("RX GNU Radio packet sink must connect to the source decoder PUSH endpoint")
    return errors


def validate_python(root: Path) -> List[str]:
    errors: List[str] = []
    for path in root.rglob("*.py"):
        try:
            compile(path.read_text(encoding="utf-8"), str(path), "exec")
        except Exception as exc:
            errors.append(f"Python syntax error in {path.relative_to(root)}: {exc}")
    return errors


def main() -> None:
    parser = argparse.ArgumentParser(description="Static and optional runtime validation for GNU Radio/X310 link")
    parser.add_argument("--root", default=".")
    parser.add_argument("--runtime", action="store_true", help="Also run grcc and UHD discovery/probe commands")
    parser.add_argument("--build-dir", default="runs/usrp_link_validation")
    args = parser.parse_args()

    root = Path(args.root).resolve()
    errors = validate_python(root) + validate_grc(root)
    report: Dict[str, Any] = {"static_errors": errors, "runtime": {}}

    if args.runtime:
        tools = ["gnuradio-config-info", "grcc", "uhd_find_devices", "uhd_usrp_probe"]
        missing = [tool for tool in tools if shutil.which(tool) is None]
        if missing:
            errors.append("Missing runtime tools: " + ", ".join(missing))
        else:
            version = _run(["gnuradio-config-info", "--version"])
            report["runtime"]["gnuradio_version"] = version
            if EXPECTED_GR_VERSION not in version["stdout"]:
                errors.append(
                    f"GNU Radio version mismatch: expected {EXPECTED_GR_VERSION}, got {version['stdout']}"
                )
            report["runtime"]["uhd_find_devices"] = _run(["uhd_find_devices"])
            report["runtime"]["tx_probe"] = _run(
                ["uhd_usrp_probe", "--args", f"addr={EXPECTED_TX_IP}"]
            )
            report["runtime"]["rx_probe"] = _run(
                ["uhd_usrp_probe", "--args", f"addr={EXPECTED_RX_IP}"]
            )
            build_dir = root / args.build_dir
            build_dir.mkdir(parents=True, exist_ok=True)
            build = _run(
                [
                    sys.executable,
                    "-m",
                    "apps.build_grc",
                    "--build-dir",
                    str(build_dir),
                    "--tx-gain",
                    "10",
                    "--rx-gain",
                    "20",
                    "--timing-phase",
                    "0",
                ]
            )
            report["runtime"]["grcc_build"] = build
            if build["returncode"] != 0:
                errors.append("grcc build failed")

    report["success"] = not errors
    output = root / "runs/usrp_link_validation/report.yaml"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(yaml.safe_dump(report, sort_keys=False), encoding="utf-8")
    print(yaml.safe_dump(report, sort_keys=False))
    if errors:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
