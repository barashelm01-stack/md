from __future__ import annotations

import argparse
import csv
import math
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

METRICS = {
    "waveform_distance": "Waveform distance",
    "segsnr_db": "SegSNR (dB)",
    "pesq_wb": "PESQ-WB",
    "si_sdr_db": "SI-SDR (dB)",
    "stft_distance": "STFT distance",
    "stoi": "STOI",
}
LABELS = {"jscm": "JSCM", "sscc": "SSCC", "opus": "Opus"}


def to_float(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return float("nan")


def is_success(row):
    return str(row.get("success", "")).strip().lower() in {"true", "1", "yes"}


def aggregate_by_target(rows, method, metric):
    groups = {}
    for row in rows:
        if row.get("method") != method or not is_success(row):
            continue
        target = to_float(row.get("target_snr_db"))
        measured = to_float(row.get("measured_esn0_db"))
        value = to_float(row.get(metric))
        if all(math.isfinite(item) for item in (target, measured, value)):
            groups.setdefault(target, {"x": [], "y": []})
            groups[target]["x"].append(measured)
            groups[target]["y"].append(value)
    result = []
    for target in sorted(groups):
        x_values = np.asarray(groups[target]["x"], dtype=np.float64)
        y_values = np.asarray(groups[target]["y"], dtype=np.float64)
        result.append(
            {
                "target_snr_db": target,
                "x_mean": float(np.mean(x_values)),
                "x_std": float(np.std(x_values)),
                "y_mean": float(np.mean(y_values)),
                "y_std": float(np.std(y_values)),
                "count": int(y_values.size),
            }
        )
    return result


def aggregate_gain(rows):
    groups = {}
    for row in rows:
        if not is_success(row):
            continue
        gain = to_float(row.get("tx_gain_db"))
        measured = to_float(row.get("measured_esn0_db"))
        if math.isfinite(gain) and math.isfinite(measured):
            groups.setdefault(gain, []).append(measured)
    result = []
    for gain in sorted(groups):
        values = np.asarray(groups[gain], dtype=np.float64)
        result.append((gain, float(np.mean(values)), float(np.std(values)), int(values.size)))
    return result


def write_aggregate_csv(rows, output_path):
    records = []
    for method in LABELS:
        for metric in METRICS:
            for record in aggregate_by_target(rows, method, metric):
                records.append({"method": method, "metric": metric, **record})
    fieldnames = [
        "method",
        "metric",
        "target_snr_db",
        "x_mean",
        "x_std",
        "y_mean",
        "y_std",
        "count",
    ]
    with output_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(records)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--csv", required=True)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()

    with open(args.csv, encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    successful = [row for row in rows if is_success(row)]
    if not successful:
        raise RuntimeError("summary contains no successful end-to-end runs")

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    write_aggregate_csv(rows, output_dir / "aggregated_kpi.csv")

    figure = plt.figure(figsize=(15.5, 9.2), constrained_layout=True)
    grid = figure.add_gridspec(3, 3, width_ratios=[1.0, 1.0, 0.95])

    for index, (metric, ylabel) in enumerate(METRICS.items()):
        axis = figure.add_subplot(grid[index // 2, index % 2])
        plotted = False
        for method, label in LABELS.items():
            records = aggregate_by_target(rows, method, metric)
            if not records:
                continue
            x = [record["x_mean"] for record in records]
            xerr = [record["x_std"] for record in records]
            y = [record["y_mean"] for record in records]
            yerr = [record["y_std"] for record in records]
            axis.errorbar(
                x,
                y,
                xerr=xerr,
                yerr=yerr,
                marker="o",
                linewidth=1.6,
                capsize=3,
                label=label,
            )
            plotted = True
        axis.set_xlabel("Measured $E_s/N_0$ (dB)")
        axis.set_ylabel(ylabel)
        axis.grid(True, alpha=0.3)
        if plotted:
            axis.legend(fontsize=8)

    right_grid = grid[:, 2].subgridspec(2, 1, hspace=0.32)

    gain_axis = figure.add_subplot(right_grid[0])
    gain_records = aggregate_gain(rows)
    if gain_records:
        gain = [record[0] for record in gain_records]
        esn0 = [record[1] for record in gain_records]
        esn0_std = [record[2] for record in gain_records]
        gain_axis.errorbar(gain, esn0, yerr=esn0_std, marker="s", capsize=3)
        if len(set(gain)) >= 2:
            coefficient = np.polyfit(gain, esn0, 1)
            fitted_x = np.linspace(min(gain), max(gain), 100)
            gain_axis.plot(fitted_x, coefficient[0] * fitted_x + coefficient[1])
    gain_axis.set_xlabel("TX gain (dB)")
    gain_axis.set_ylabel("Measured $E_s/N_0$ (dB)")
    gain_axis.set_title("TX gain calibration")
    gain_axis.grid(True, alpha=0.3)

    link_axis = figure.add_subplot(right_grid[1])
    plotted = False
    for method, label in LABELS.items():
        records = aggregate_by_target(rows, method, "packet_success_rate")
        if not records:
            continue
        x = [record["x_mean"] for record in records]
        xerr = [record["x_std"] for record in records]
        y = [record["y_mean"] for record in records]
        yerr = [record["y_std"] for record in records]
        link_axis.errorbar(
            x,
            y,
            xerr=xerr,
            yerr=yerr,
            marker="o",
            capsize=3,
            label=label,
        )
        plotted = True
    link_axis.set_xlabel("Measured $E_s/N_0$ (dB)")
    link_axis.set_ylabel("Packet success rate")
    link_axis.set_ylim(-0.03, 1.03)
    link_axis.set_title("End-to-end packet delivery")
    link_axis.grid(True, alpha=0.3)
    if plotted:
        link_axis.legend(fontsize=8)

    figure.suptitle("End-to-End KPI vs Measured SNR")
    figure.savefig(output_dir / "kpi_vs_snr_dashboard.png", dpi=220)
    figure.savefig(output_dir / "kpi_vs_snr_dashboard.pdf")
    plt.close(figure)


if __name__ == "__main__":
    main()
