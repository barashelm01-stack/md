# V0.8.0 Validation Report

## Implemented

- Unified prototype frame for JSCM, SSCC and Opus.
- 8-bit preamble, 32-bit access address and 32-bit real header.
- No CRC and no whitening.
- START, DATA and END control frames.
- Only two GRC files: `e2e_tx.grc` and `e2e_rx.grc`.
- Dynamic JSCM/SSCC/Opus dispatch through one TX and one RX flowgraph.
- GRC-based execution: each sweep point patches the TX gain and invokes `grcc`.
- Unified source TX/RX adapters.
- Automatic method × SNR × repeat controller.
- Objective KPI aggregation and dashboard plotting.

## Static validation completed

- Python source compilation.
- Unified protocol unit tests: 4/4 passed.
- Three modes tested through sync search and real header parsing.
- Affine sync amplitude/bias recovery tested.
- RadioPacket control-field serialization tested.
- GRC YAML files parsed successfully.
- Confirmed exactly two `.grc` files remain.

## Not hardware validated here

GNU Radio, UHD and X310 were not available in this execution environment. Runtime `grcc`, UHD device access, RF transmission, timing recovery and OTA KPI results must be validated on the specified host.
