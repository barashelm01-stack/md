# v0.8.1 USRP Link Audit

## Audit scope

- GNU Radio target: 3.10.12.0
- USRP: two X310 devices, UHD type x300, FPGA image HG
- TX address: 192.168.10.1
- RX address: 192.168.10.2
- Sample rate: 4 MS/s
- Symbol rate: 1 Msymbol/s
- SPS: 4
- BT: 0.5
- Modulation index: 0.5

## Corrected issues

### 1. TX interpolation gain

The prior TX Gaussian taps were normalized to a sum of one. An interpolator inserts three zeros for SPS=4, so a unit-sum filter reduces the steady symbol amplitude by approximately four. The revised TX taps use Gaussian-filter gain equal to SPS. The RX filter uses unit gain.

### 2. Missing RX timing phase in GRC

The executable reference flowgraph had a timing-phase skip block, but the GRC receiver did not. The GRC now includes a `timing_phase` variable and `Skip Head` before decimation. Valid values are 0, 1, 2 and 3 for SPS=4.

### 3. Build-time validation

`apps/build_grc.py` now validates integer SPS, timing-phase range, grcc availability, grcc return status and generated Python files. It also patches both X310 addresses and all critical RF/rate parameters.

### 4. Runtime validation

`apps/validate_usrp_link.py --runtime` checks GNU Radio version, UHD discovery, both UHD probes and grcc generation. It writes `runs/usrp_link_validation/report.yaml`.

## Static validation performed in the artifact environment

- Python syntax validation: passed.
- GRC YAML loading: passed.
- Required block and connection audit: passed.
- X310 address audit: passed.
- TX/RX Gaussian gain audit: passed.
- ZeroMQ bind/connect audit: passed.
- Unified framing tests: 4/4 passed.

## Not verifiable in the artifact environment

GNU Radio, UHD and X310 hardware are unavailable in the artifact container. Consequently, the following require execution on the target host:

- grcc compilation under GNU Radio 3.10.12.0;
- loading custom GRC block definitions;
- UHD discovery and device probing;
- daughterboard/subdevice and antenna validation;
- actual timing-phase selection;
- RF loopback, underflow/overflow and clipping checks;
- measured Gain-to-SNR calibration.

The runtime validator is provided to perform these checks on the target system. A successful static audit is not a substitute for the runtime report.
