# v0.8.2 OTA Path and Automated Plot Audit

## Scope

This audit reviews the real over-the-air path and the automatic method/SNR sweep for JSCM, SSCC, and Opus. The prototype remains BLE-inspired only and does not implement CRC or whitening.

## OTA-path corrections

1. **Bias-tolerant sync search**
   - Sync detection now fits every candidate window to `y = a*x + b` before hard comparison.
   - This prevents discriminator DC bias or residual CFO from shifting all sync symbols across the zero threshold.

2. **Bounded payload parsing**
   - `UnifiedPacketSink` now rejects headers whose payload length exceeds `max_payload_symbols`.
   - Default: 8192 symbols.
   - This prevents a corrupted header from making the receiver wait indefinitely for an implausibly large payload.

3. **Reliable ZeroMQ shutdown**
   - TX uses a finite positive linger time rather than `linger=0`.
   - START and END controls are repeated three times by default.
   - A configurable drain interval is applied before the source transmitter closes.

4. **RX timeout**
   - `PacketReceiver` supports `RCVTIMEO`.
   - A lost END frame no longer leaves the source receiver blocked forever.

5. **Sequence-aware loss handling**
   - The source receiver detects missing, duplicate, and out-of-order DATA packets.
   - Missing JSCM/SSCC packets are concealed with zero codewords/bits while preserving decoder state progression.
   - Missing Opus packets use decoder packet-loss concealment.
   - Recovered audio is trimmed/padded to the exact reference length.

6. **Actual link delivery metrics**
   - Added expected frames, received frames, missing frames, duplicates, out-of-order packets, END status, and packet success rate.

7. **Controller health checks**
   - Detects early source RX, GNU Radio RX, or GNU Radio TX termination.
   - Requires a finite measured symbol-domain Es/N0 and a received END control frame.
   - Uses nonzero exit status on plotting failure.

## Plotting corrections

1. Repeats are grouped by `(method, target_snr_db)`, not rounded measured SNR.
2. The x-coordinate is the mean measured Es/N0 of each target-SNR group.
3. Horizontal error bars show measured-Es/N0 standard deviation.
4. Vertical error bars show KPI standard deviation.
5. The TX-gain panel aggregates duplicate method/repeat observations at each gain.
6. The lower-right panel plots packet success rate rather than raw frame count.
7. Failed runs are excluded from KPI aggregation.
8. `aggregated_kpi.csv` is generated beside the dashboard.

## Validation performed in the available environment

- Python syntax compilation of modified controller, TX/RX adapters, plotter, IPC, framing, and custom GNU Radio block: passed.
- Unified prototype framing tests: 4/4 passed.
- Bias/gain-aware sync path: covered by framing tests.
- GRC/static link validator: passed with no static errors.
- Synthetic three-method, three-SNR, two-repeat plotting smoke test: passed.
- Dashboard PNG and aggregated CSV generation: passed.

## Runtime limitations

The current environment does not contain GNU Radio 3.10.12, UHD, or the two X310 devices. Therefore the following still require execution on the target host:

- `grcc` generation using the installed GNU Radio version;
- loading custom blocks in GRC;
- UHD probing of 192.168.10.1 and 192.168.10.2;
- RF daughterboard/antenna verification;
- timing-phase selection;
- real underflow/overflow observation;
- measured TX-gain-to-Es/N0 calibration;
- complete OTA KPI sweep.
