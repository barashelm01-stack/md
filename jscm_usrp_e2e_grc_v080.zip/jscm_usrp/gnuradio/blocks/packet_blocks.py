"""GNU Radio 3.10 custom blocks for the unified prototype frame path."""
from __future__ import annotations
import time
from pathlib import Path
import sys
import numpy as np
from gnuradio import gr
_ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(_ROOT/'src'))
from jscm.radio_ipc import PacketReceiver, PacketSender
from jscm.radio_protocol import RadioMode, RadioPacket, ControlType as IPCControl
from jscm.prototype_framing import PrototypeMode, ControlType, SYNC_BITS, HEADER_BITS, frame_symbols, find_sync, parse_header, affine_sync_normalize

_MODE_TO_PROTO={RadioMode.JSCM_CONTINUOUS:PrototypeMode.JSCM,RadioMode.SSCC_BITS:PrototypeMode.SSCC,RadioMode.OPUS_BYTES:PrototypeMode.OPUS}
_PROTO_TO_MODE={v:k for k,v in _MODE_TO_PROTO.items()}
_CONTROL_TO_PROTO={IPCControl.DATA:ControlType.DATA,IPCControl.START:ControlType.START,IPCControl.END:ControlType.END}
_PROTO_TO_CONTROL={v:k for k,v in _CONTROL_TO_PROTO.items()}

class UnifiedPacketSource(gr.sync_block):
    def __init__(self, endpoint='tcp://127.0.0.1:5555', bind=True, idle_symbols=64):
        gr.sync_block.__init__(self,name='Unified Packet Source',in_sig=None,out_sig=[np.float32])
        self.receiver=PacketReceiver(endpoint=endpoint,bind=bool(bind),high_water_mark=1000)
        self.idle_symbols=max(int(idle_symbols),0)
        self._queue=np.zeros(self.idle_symbols,dtype=np.float32); self._offset=0
    def _load(self):
        packet=self.receiver.recv_nonblocking()
        if packet is None: return False
        framed=frame_symbols(_MODE_TO_PROTO[packet.mode],_CONTROL_TO_PROTO[packet.control],packet.sequence_id,packet.payload)
        self._queue=np.concatenate([framed,np.zeros(self.idle_symbols,np.float32)]) if self.idle_symbols else framed
        self._offset=0; return True
    def work(self,input_items,output_items):
        out=output_items[0]; made=0
        while made<out.size:
            if self._offset>=self._queue.size and not self._load():
                out[made:]=0; return out.size
            n=min(out.size-made,self._queue.size-self._offset)
            out[made:made+n]=self._queue[self._offset:self._offset+n]; made+=n; self._offset+=n
        return made
    def stop(self): self.receiver.close(); return True

class UnifiedPacketSink(gr.sync_block):
    def __init__(self,endpoint='tcp://127.0.0.1:5556',bind=False,max_sync_errors=4,max_buffer_symbols=262144,sample_rate=16000):
        gr.sync_block.__init__(self,name='Unified Packet Sink',in_sig=[np.float32],out_sig=None)
        self.sender=PacketSender(endpoint=endpoint,bind=bool(bind),high_water_mark=1000)
        self.max_sync_errors=max(int(max_sync_errors),0); self.max_buffer_symbols=max(int(max_buffer_symbols),1024); self.sample_rate=int(sample_rate)
        self._buffer=np.empty(0,np.float32); self.frames_ok=0; self.frames_rejected=0
    def _consume(self):
        minimum=SYNC_BITS+HEADER_BITS
        while True:
            start=find_sync(self._buffer,self.max_sync_errors)
            if start is None:
                keep=min(self._buffer.size,SYNC_BITS-1); self._buffer=self._buffer[-keep:] if keep else np.empty(0,np.float32); return
            if start: self._buffer=self._buffer[start:]
            if self._buffer.size<minimum: return
            try:
                prefix,scale,bias,esn0=affine_sync_normalize(self._buffer[:minimum]); header=parse_header(prefix[SYNC_BITS:minimum])
            except Exception:
                self.frames_rejected+=1; self._buffer=self._buffer[1:]; continue
            total=minimum+header.payload_length
            if total>self.max_buffer_symbols:
                self.frames_rejected+=1; self._buffer=self._buffer[1:]; continue
            if self._buffer.size<total: return
            raw=self._buffer[:total]; self._buffer=self._buffer[total:]
            try:
                normalized,scale,bias,esn0=affine_sync_normalize(raw)
                payload=normalized[minimum:].copy()
                mode=_PROTO_TO_MODE[header.mode]
                if mode!=RadioMode.JSCM_CONTINUOUS: payload=(payload>=0).astype(np.uint8)
                packet=RadioPacket(mode=mode,sequence_id=header.sequence_id,payload=payload,sample_rate=self.sample_rate,timestamp_ns=time.time_ns(),metadata={'symbol_esn0_db':esn0,'sync_scale':scale,'sync_bias':bias,'receiver':'gnu_radio_3.10.12'},control=_PROTO_TO_CONTROL[header.control])
                self.sender.send(packet); self.frames_ok+=1
            except Exception: self.frames_rejected+=1
    def work(self,input_items,output_items):
        x=np.asarray(input_items[0],np.float32)
        if x.size:
            self._buffer=np.concatenate([self._buffer,x])
            if self._buffer.size>self.max_buffer_symbols: self._buffer=self._buffer[-self.max_buffer_symbols:]
            self._consume()
        return x.size
    def stop(self): self.sender.close(); return True
