"""Unified prototype framing for JSCM, SSCC and Opus.

BLE-inspired only: 8-bit preamble + 32-bit access address + 32-bit header.
No CRC, whitening, hopping or BLE link-layer behavior.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum
from typing import Optional, Tuple

import numpy as np

PREAMBLE = 0xAA
ACCESS_ADDRESS = 0x8E89BED6
SYNC_BITS = 40
HEADER_BITS = 32
MAX_PAYLOAD = 0xFFFF


class PrototypeMode(IntEnum):
    JSCM = 0
    SSCC = 1
    OPUS = 2


class ControlType(IntEnum):
    DATA = 0
    START = 1
    END = 2


def _int_bits_lsb(value: int, width: int) -> np.ndarray:
    return ((int(value) >> np.arange(width, dtype=np.uint64)) & 1).astype(np.uint8)


def _bits_int_lsb(bits: np.ndarray) -> int:
    bits = np.asarray(bits, dtype=np.uint8).reshape(-1)
    return int(np.sum(bits.astype(np.uint64) << np.arange(bits.size, dtype=np.uint64)))


def sync_bits() -> np.ndarray:
    return np.concatenate([_int_bits_lsb(PREAMBLE, 8), _int_bits_lsb(ACCESS_ADDRESS, 32)])


SYNC = sync_bits()
SYNC_BIPOLAR = SYNC.astype(np.float32) * 2.0 - 1.0


@dataclass(frozen=True)
class FrameHeader:
    mode: PrototypeMode
    control: ControlType
    sequence_id: int
    payload_length: int


def build_header(mode: PrototypeMode, control: ControlType, sequence_id: int, payload_length: int) -> np.ndarray:
    if not 0 <= int(sequence_id) <= 0xFFF:
        raise ValueError("sequence_id must fit 12 bits")
    if not 0 <= int(payload_length) <= MAX_PAYLOAD:
        raise ValueError("payload_length must fit 16 bits")
    return np.concatenate([
        _int_bits_lsb(int(mode), 2),
        _int_bits_lsb(int(control), 2),
        _int_bits_lsb(int(sequence_id), 12),
        _int_bits_lsb(int(payload_length), 16),
    ])


def parse_header(symbols: np.ndarray) -> FrameHeader:
    bits = (np.asarray(symbols).reshape(-1)[:HEADER_BITS] >= 0).astype(np.uint8)
    if bits.size != HEADER_BITS:
        raise ValueError("truncated header")
    return FrameHeader(
        mode=PrototypeMode(_bits_int_lsb(bits[0:2])),
        control=ControlType(_bits_int_lsb(bits[2:4])),
        sequence_id=_bits_int_lsb(bits[4:16]),
        payload_length=_bits_int_lsb(bits[16:32]),
    )


def frame_symbols(mode: PrototypeMode, control: ControlType, sequence_id: int, payload: np.ndarray) -> np.ndarray:
    payload = np.asarray(payload).reshape(-1)
    if control != ControlType.DATA:
        payload = np.empty(0, dtype=np.float32)
    if mode == PrototypeMode.JSCM:
        mapped = payload.astype(np.float32, copy=False)
    else:
        bits = payload.astype(np.uint8, copy=False)
        if np.any((bits != 0) & (bits != 1)):
            raise ValueError("digital payload must contain 0/1")
        mapped = bits.astype(np.float32) * 2.0 - 1.0
    header = build_header(mode, control, sequence_id, mapped.size)
    return np.concatenate([SYNC_BIPOLAR, header.astype(np.float32) * 2.0 - 1.0, mapped])


def find_sync(buffer: np.ndarray, max_errors: int) -> Optional[int]:
    hard = (np.asarray(buffer).reshape(-1) >= 0).astype(np.uint8)
    if hard.size < SYNC_BITS:
        return None
    best_start, best_errors = None, SYNC_BITS + 1
    for start in range(hard.size - SYNC_BITS + 1):
        errors = int(np.count_nonzero(hard[start:start + SYNC_BITS] != SYNC))
        if errors < best_errors:
            best_start, best_errors = start, errors
            if errors == 0:
                break
    return best_start if best_errors <= int(max_errors) else None


def affine_sync_normalize(frame: np.ndarray) -> Tuple[np.ndarray, float, float, float]:
    observed = np.asarray(frame[:SYNC_BITS], dtype=np.float64)
    matrix = np.column_stack([SYNC_BIPOLAR.astype(np.float64), np.ones(SYNC_BITS)])
    scale, bias = np.linalg.lstsq(matrix, observed, rcond=None)[0]
    if abs(scale) < 1e-8:
        raise ValueError("invalid sync scale")
    normalized = (np.asarray(frame, dtype=np.float64) - bias) / scale
    residual = normalized[:SYNC_BITS] - SYNC_BIPOLAR
    signal_power = float(np.mean(SYNC_BIPOLAR.astype(np.float64) ** 2))
    noise_power = max(float(np.mean(residual ** 2)), 1e-12)
    esn0_db = 10.0 * np.log10(signal_power / noise_power)
    return normalized.astype(np.float32), float(scale), float(bias), float(esn0_db)
