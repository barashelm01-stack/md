from __future__ import annotations
import argparse,subprocess
from pathlib import Path
import yaml

def patch(source:Path,target:Path,tx_gain=None,rx_gain=None,center_freq=None):
    data=yaml.safe_load(source.read_text())
    for block in data.get('blocks',[]):
        if block.get('name')=='usrp_sink' and tx_gain is not None: block['parameters']['gain0']=str(tx_gain)
        if block.get('name')=='usrp_source' and rx_gain is not None: block['parameters']['gain0']=str(rx_gain)
        if block.get('name') in {'usrp_sink','usrp_source'} and center_freq is not None: block['parameters']['center_freq0']=str(center_freq)
        if block.get('name')=='project_root': block['parameters']['value']=repr(str(Path.cwd()))
    target.write_text(yaml.safe_dump(data,sort_keys=False))
def main():
    p=argparse.ArgumentParser();p.add_argument('--build-dir',required=True);p.add_argument('--tx-gain',type=float,required=True);p.add_argument('--rx-gain',type=float,default=20);p.add_argument('--center-freq',type=float,default=2.45e9);a=p.parse_args()
    build=Path(a.build_dir);build.mkdir(parents=True,exist_ok=True)
    patch(Path('gnuradio/grc/e2e_tx.grc'),build/'e2e_tx.grc',tx_gain=a.tx_gain,center_freq=a.center_freq)
    patch(Path('gnuradio/grc/e2e_rx.grc'),build/'e2e_rx.grc',rx_gain=a.rx_gain,center_freq=a.center_freq)
    for name in ('e2e_tx.grc','e2e_rx.grc'):
        subprocess.run(['grcc','-d',str(build),str(build/name)],check=True)
if __name__=='__main__':main()
