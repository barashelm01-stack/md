from __future__ import annotations
import argparse,csv,json
from pathlib import Path
import numpy as np,soundfile as sf,torch
from jscm.experiment_utils import load_checkpoint
from jscm.models import JSCMSystem
from jscm.sscc import SSCCSystem
from jscm.radio_ipc import PacketReceiver
from jscm.radio_protocol import RadioMode,ControlType

def _load_model(cls,path,device):
    ck=load_checkpoint(path,map_location=device); cfg=ck.get('model_config',ck.get('config',{})); model=cls(**{k:v for k,v in cfg.items() if k in cls.__init__.__code__.co_varnames}); model.load_state_dict(ck['model']); return model.to(device).eval()
def main():
    p=argparse.ArgumentParser(); p.add_argument('--method',choices=['jscm','sscc','opus'],required=True); p.add_argument('--checkpoint',default=''); p.add_argument('--output-dir',required=True); p.add_argument('--endpoint',default='tcp://0.0.0.0:5556'); p.add_argument('--timeout-sec',type=int,default=120); p.add_argument('--device',default='cuda' if torch.cuda.is_available() else 'cpu'); a=p.parse_args()
    out=Path(a.output_dir); out.mkdir(parents=True,exist_ok=True); receiver=PacketReceiver(a.endpoint,bind=True); audio=[]; records=[]; expected_seq=0; started=False
    if a.method=='jscm': model=_load_model(JSCMSystem,a.checkpoint,a.device); state=model.init_decoder_stream_state(1,torch.device(a.device),next(model.parameters()).dtype)
    elif a.method=='sscc': model=_load_model(SSCCSystem,a.checkpoint,a.device); state=model.init_decoder_stream_state(1,torch.device(a.device),next(model.parameters()).dtype)
    else:
        import opuslib; decoder=opuslib.Decoder(16000,1)
    try:
        while True:
            packet=receiver.recv(); meta=packet.metadata or {}; records.append({'sequence_id':packet.sequence_id,'control':int(packet.control),'symbol_esn0_db':meta.get('symbol_esn0_db'),'sync_scale':meta.get('sync_scale'),'sync_bias':meta.get('sync_bias')})
            if packet.control==ControlType.START: started=True; continue
            if packet.control==ControlType.END: break
            if not started or packet.sequence_id!=expected_seq: expected_seq=packet.sequence_id
            valid=int(meta.get('valid_audio_samples',320))
            if a.method=='jscm':
                with torch.inference_mode(): frame,state=model.decode_source_stream(torch.from_numpy(packet.payload).view(1,1,-1).to(a.device),state); y=frame.squeeze().float().cpu().numpy()
            elif a.method=='sscc':
                with torch.inference_mode(): frame,state=model.decode_source_stream(packet.payload,state); y=frame.squeeze().float().cpu().numpy()
            else:
                bits=np.asarray(packet.payload,np.uint8); raw=np.packbits(bits,bitorder='little').tobytes()
                try: pcm=decoder.decode(raw,320,decode_fec=False)
                except Exception: pcm=decoder.decode(b'',320,decode_fec=False)
                y=np.frombuffer(pcm,dtype='<i2').astype(np.float32)/32768.0
            audio.append(y[:valid]); expected_seq=packet.sequence_id+1
    finally: receiver.close()
    recovered=np.concatenate(audio) if audio else np.zeros(0,np.float32); sf.write(out/'recovered.wav',recovered,16000)
    with (out/'frame_records.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=['sequence_id','control','symbol_esn0_db','sync_scale','sync_bias']); w.writeheader(); w.writerows(records)
    es=[float(r['symbol_esn0_db']) for r in records if r['symbol_esn0_db'] is not None]
    (out/'link_metrics.json').write_text(json.dumps({'frames_received':len(audio),'mean_symbol_esn0_db':float(np.mean(es)) if es else None,'std_symbol_esn0_db':float(np.std(es)) if es else None},indent=2))
if __name__=='__main__': main()
