from __future__ import annotations
import argparse,csv,json,os,signal,subprocess,sys,time
from pathlib import Path
import numpy as np,soundfile as sf,yaml
from jscm.objective_metrics import compute_objective_metrics

def launch(cmd,log,env):
    handle=open(log,'w',encoding='utf-8'); process=subprocess.Popen(cmd,stdout=handle,stderr=subprocess.STDOUT,env=env,start_new_session=True); return process,handle
def stop(proc):
    if proc and proc.poll() is None:
        os.killpg(proc.pid,signal.SIGTERM)
        try: proc.wait(timeout=8)
        except subprocess.TimeoutExpired: os.killpg(proc.pid,signal.SIGKILL)
def evaluate(reference,recovered):
    x,sr=sf.read(reference,dtype='float32'); y,sr2=sf.read(recovered,dtype='float32'); n=min(len(x),len(y)); return compute_objective_metrics(np.asarray(y[:n]),np.asarray(x[:n]))
def main():
    p=argparse.ArgumentParser(); p.add_argument('--config',default='configs/e2e_x310.yaml'); a=p.parse_args(); cfg=yaml.safe_load(Path(a.config).read_text())
    root=Path(cfg['output_root']); root.mkdir(parents=True,exist_ok=True); env=os.environ.copy(); env['PYTHONPATH']=str(Path.cwd()/'src')+os.pathsep+env.get('PYTHONPATH','')
    rows=[]
    for method in cfg['methods']:
      checkpoint=cfg.get('checkpoints',{}).get(method,'')
      for point in cfg['snr_points']:
       target=float(point['target_snr_db']); gain=float(point['tx_gain_db'])
       for repeat in range(int(cfg.get('repeats',1))):
        run=root/method/('target_%gdb'%target)/('repeat_%02d'%repeat); run.mkdir(parents=True,exist_ok=True)
        procs=[]; handles=[]
        try:
          source_rx=[sys.executable,'-m','apps.source_rx','--method',method,'--output-dir',str(run),'--endpoint','tcp://0.0.0.0:5556']
          if checkpoint: source_rx += ['--checkpoint',checkpoint]
          pr,h=launch(source_rx,run/'source_rx.log',env); procs.append(pr); handles.append(h); time.sleep(1)
          build_dir=run/'grc_build'
          subprocess.run([sys.executable,'-m','apps.build_grc','--build-dir',str(build_dir),'--tx-gain',str(gain),'--rx-gain',str(cfg['usrp']['rx_gain_db']),'--center-freq',str(cfg['usrp']['center_freq_hz'])],env=env,check=True)
          rx=[sys.executable,str(build_dir/'e2e_rx.py')]
          pr,h=launch(rx,run/'gr_rx.log',env); procs.append(pr); handles.append(h); time.sleep(2)
          tx=[sys.executable,str(build_dir/'e2e_tx.py')]
          pr,h=launch(tx,run/'gr_tx.log',env); procs.append(pr); handles.append(h); time.sleep(2)
          source_tx=[sys.executable,'-m','apps.source_tx','--method',method,'--input',cfg['test_audio'],'--endpoint','tcp://127.0.0.1:5555','--bitrate',str(cfg.get('opus_bitrate',6000))]
          if checkpoint: source_tx += ['--checkpoint',checkpoint]
          completed=subprocess.run(source_tx,stdout=open(run/'source_tx.log','w'),stderr=subprocess.STDOUT,env=env,timeout=cfg.get('run_timeout_sec',180))
          if completed.returncode: raise RuntimeError('source TX failed')
          procs[0].wait(timeout=cfg.get('run_timeout_sec',180))
          metrics=evaluate(cfg['test_audio'],run/'recovered.wav'); link=json.loads((run/'link_metrics.json').read_text())
          row={'method':method,'target_snr_db':target,'tx_gain_db':gain,'repeat':repeat,'measured_esn0_db':link.get('mean_symbol_esn0_db'),**metrics,**link}; rows.append(row)
          (run/'metrics.json').write_text(json.dumps(row,indent=2))
        except Exception as exc:
          (run/'status.json').write_text(json.dumps({'success':False,'error':str(exc)},indent=2)); rows.append({'method':method,'target_snr_db':target,'tx_gain_db':gain,'repeat':repeat,'error':str(exc)})
        finally:
          for proc in reversed(procs): stop(proc)
          for h in handles: h.close()
    keys=sorted({k for row in rows for k in row});
    with (root/'summary.csv').open('w',newline='',encoding='utf-8') as f: w=csv.DictWriter(f,fieldnames=keys); w.writeheader(); w.writerows(rows)
    subprocess.run([sys.executable,'-m','apps.plot_e2e_results','--csv',str(root/'summary.csv'),'--output-dir',str(root/'figures')],env=env,check=False)
if __name__=='__main__': main()
