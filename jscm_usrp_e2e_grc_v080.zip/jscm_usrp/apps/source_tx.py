from __future__ import annotations
import argparse,time
from pathlib import Path
import numpy as np, soundfile as sf, torch
from jscm.experiment_utils import load_checkpoint
from jscm.models import JSCMSystem
from jscm.sscc import SSCCSystem
from jscm.radio_ipc import PacketSender
from jscm.radio_protocol import RadioMode,RadioPacket,ControlType

def _load_model(cls,path,device):
    ck=load_checkpoint(path,map_location=device); cfg=ck.get('model_config',ck.get('config',{})); model=cls(**{k:v for k,v in cfg.items() if k in cls.__init__.__code__.co_varnames}); model.load_state_dict(ck['model']); return model.to(device).eval()
def main():
    p=argparse.ArgumentParser(); p.add_argument('--method',choices=['jscm','sscc','opus'],required=True); p.add_argument('--checkpoint',default=''); p.add_argument('--input',required=True); p.add_argument('--endpoint',default='tcp://127.0.0.1:5555'); p.add_argument('--bitrate',type=int,default=6000); p.add_argument('--device',default='cuda' if torch.cuda.is_available() else 'cpu'); a=p.parse_args()
    audio,sr=sf.read(a.input,dtype='float32',always_2d=False); audio=audio.mean(1) if audio.ndim>1 else audio
    if sr!=16000: raise ValueError('input must be 16 kHz')
    sender=PacketSender(a.endpoint,bind=False); mode={'jscm':RadioMode.JSCM_CONTINUOUS,'sscc':RadioMode.SSCC_BITS,'opus':RadioMode.OPUS_BYTES}[a.method]
    sender.send(RadioPacket(mode,0,np.empty(0,np.float32 if a.method=='jscm' else np.uint8),16000,time.time_ns(),{'audio_samples':int(audio.size)},ControlType.START))
    frame_samples=320
    try:
        if a.method=='jscm':
            model=_load_model(JSCMSystem,a.checkpoint,a.device); state=model.init_encoder_stream_state(1,torch.device(a.device),next(model.parameters()).dtype)
            with torch.inference_mode():
                for seq,start in enumerate(range(0,audio.size,frame_samples)):
                    chunk=audio[start:start+frame_samples]; frame=np.zeros(frame_samples,np.float32); frame[:chunk.size]=chunk
                    z,state=model.encode_source_stream(torch.from_numpy(frame).view(1,1,-1).to(a.device),state); payload=z.squeeze().float().cpu().numpy()
                    sender.send(RadioPacket(mode,seq,payload,16000,time.time_ns(),{'valid_audio_samples':int(chunk.size)},ControlType.DATA))
        elif a.method=='sscc':
            model=_load_model(SSCCSystem,a.checkpoint,a.device); state=model.init_encoder_stream_state(1,torch.device(a.device),next(model.parameters()).dtype)
            with torch.inference_mode():
                for seq,start in enumerate(range(0,audio.size,frame_samples)):
                    chunk=audio[start:start+frame_samples]; frame=np.zeros(frame_samples,np.float32); frame[:chunk.size]=chunk
                    bits,state=model.encode_source_stream(torch.from_numpy(frame).view(1,1,-1).to(a.device),state)
                    sender.send(RadioPacket(mode,seq,bits.reshape(-1),16000,time.time_ns(),{'valid_audio_samples':int(chunk.size)},ControlType.DATA))
        else:
            import opuslib
            enc=opuslib.Encoder(16000,1,opuslib.APPLICATION_VOIP); enc.bitrate=a.bitrate; enc.vbr=False
            for seq,start in enumerate(range(0,audio.size,frame_samples)):
                chunk=audio[start:start+frame_samples]; frame=np.zeros(frame_samples,np.float32); frame[:chunk.size]=chunk
                pcm=np.round(np.clip(frame,-1,1)*32767).astype('<i2').tobytes(); packet=enc.encode(pcm,frame_samples); bits=np.unpackbits(np.frombuffer(packet,np.uint8),bitorder='little')
                sender.send(RadioPacket(mode,seq,bits,16000,time.time_ns(),{'valid_audio_samples':int(chunk.size),'opus_bytes':len(packet)},ControlType.DATA))
        sender.send(RadioPacket(mode,0,np.empty(0,np.float32 if a.method=='jscm' else np.uint8),16000,time.time_ns(),{},ControlType.END))
    finally: sender.close()
if __name__=='__main__': main()
