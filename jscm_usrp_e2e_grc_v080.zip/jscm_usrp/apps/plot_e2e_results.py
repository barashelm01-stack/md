from __future__ import annotations
import argparse,csv,math
from pathlib import Path
import numpy as np,matplotlib.pyplot as plt
METRICS={'waveform_distance':'Waveform distance','segsnr_db':'SegSNR (dB)','pesq_wb':'PESQ-WB','si_sdr_db':'SI-SDR (dB)','stft_distance':'STFT distance','stoi':'STOI'}
LABELS={'jscm':'JSCM','sscc':'SSCC','opus':'Opus'}
def f(x):
 try:return float(x)
 except:return float('nan')
def main():
 p=argparse.ArgumentParser();p.add_argument('--csv',required=True);p.add_argument('--output-dir',required=True);a=p.parse_args();rows=list(csv.DictReader(open(a.csv)));out=Path(a.output_dir);out.mkdir(parents=True,exist_ok=True)
 fig=plt.figure(figsize=(15.5,9.2),constrained_layout=True);grid=fig.add_gridspec(3,3,width_ratios=[1,1,.95]);
 for i,(metric,ylabel) in enumerate(METRICS.items()):
  ax=fig.add_subplot(grid[i//2,i%2])
  for method,label in LABELS.items():
   groups={}
   for r in rows:
    if r.get('method')!=method:continue
    x=f(r.get('measured_esn0_db'));y=f(r.get(metric))
    if math.isfinite(x) and math.isfinite(y): groups.setdefault(round(x,1),[]).append(y)
   if groups:
    xs=sorted(groups);means=[np.mean(groups[x]) for x in xs];std=[np.std(groups[x]) for x in xs];ax.errorbar(xs,means,yerr=std,marker='o',label=label,capsize=3)
  ax.set_xlabel('Measured $E_s/N_0$ (dB)');ax.set_ylabel(ylabel);ax.grid(True,alpha=.3);ax.legend(fontsize=8)
 right=grid[:,2].subgridspec(2,1)
 ax=fig.add_subplot(right[0]);
 pts=[(f(r.get('tx_gain_db')),f(r.get('measured_esn0_db'))) for r in rows];pts=[p for p in pts if all(map(math.isfinite,p))]
 if pts: x,y=zip(*sorted(pts));ax.scatter(x,y);coef=np.polyfit(x,y,1);xx=np.linspace(min(x),max(x),100);ax.plot(xx,coef[0]*xx+coef[1])
 ax.set_xlabel('TX gain (dB)');ax.set_ylabel('Measured $E_s/N_0$ (dB)');ax.grid(True,alpha=.3)
 ax2=fig.add_subplot(right[1]);
 for method,label in LABELS.items():
  pts=[(f(r.get('measured_esn0_db')),f(r.get('frames_received'))) for r in rows if r.get('method')==method];pts=[p for p in pts if all(map(math.isfinite,p))]
  if pts:x,y=zip(*sorted(pts));ax2.plot(x,y,marker='o',label=label)
 ax2.set_xlabel('Measured $E_s/N_0$ (dB)');ax2.set_ylabel('Frames received');ax2.grid(True,alpha=.3);ax2.legend(fontsize=8)
 fig.suptitle('End-to-End KPI vs Measured SNR');fig.savefig(out/'kpi_vs_snr_dashboard.png',dpi=220);fig.savefig(out/'kpi_vs_snr_dashboard.pdf');plt.close(fig)
if __name__=='__main__':main()
